/*
 * main.h
 *
 *  Created on: 14 de ago de 2016
 *      Author: Marcos
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f1xx_hal.h"
#include "fatfs.h"

extern FATFS FatFs;
extern FIL fil;
extern FRESULT res;
extern UINT br, bw; /* File read/write count */
extern DWORD PointerFile;
extern DWORD SizeFile;
extern DAC_HandleTypeDef hdac;


#endif /* MAIN_H_ */
