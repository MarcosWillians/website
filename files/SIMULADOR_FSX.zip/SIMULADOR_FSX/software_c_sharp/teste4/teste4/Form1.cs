﻿




using System; 
using System.Collections.Generic; 
using System.ComponentModel; 
using System.Data; 
using System.Drawing; 
using System.Text; 
using System.Windows.Forms; 

// Biblioteca do Simmconnect
using Microsoft.FlightSimulator.SimConnect; 
using System.Runtime.InteropServices; 

namespace teste4
{ 
    public partial class Form1 : Form 
    { 
                
        const int WM_USER_SIMCONNECT = 0x0402; 

        // Objeto simmconnect 
        SimConnect simconnect = null;

        int samplecont = 0;

        Boolean serialportPICenabled = false;
        Boolean serialportARDenabled = false;


        int anguloataqueant = 0;
        int angulolateralant = 0;

        enum DATASETS 
        { 
            Struct1, 
            StDatasetLights,
        } 

        enum DATA 
        { 
            REQUEST_1, 
            DATASET_LIGHTS,
        };


        // Estrutura do dataset da telemetria do avião
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        struct Struct1
        {
            // this is how you declare a fixed size string 
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public String title;
            public double latitude;
            public double longitude;
            public double altitude;
            public double anguloataque;
            public double angulolateral;
            public Int32 LIGHT_NAV_ON;
        };
        

        // Estrutura do dataset das luzes do avião
        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi, Pack = 1)]
        struct StDatasetLights
        {
            // this is how you declare a fixed size string 
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)]
            public String title;
            public Int32 LIGHT_NAV_ON;
            public Int32 LIGHT_BEACON_ON;
            public Int32 LIGHT_LANDING_ON;
            public Int32 LIGHT_TAXI_ON;
          //  public int LIGHT_STROBE_ON;
          //  public int LIGHT_PANEL_ON;
          //  public int LIGHT_RECOGNITION_ON;
          //  public int LIGHT_WING_ON;
          //  public int LIGHT_LOGO_ON;
          //  public int LIGHT_CABIN_ON;
        }; 

       

        public Form1() 
        { 
            InitializeComponent(); 

            
        } 

         private void Form1_Load(object sender, EventArgs e)
        {

        }

       
        // Máquina de recepção e envio de dados do Simconnect processado em sua thread principal
        protected override void DefWndProc(ref Message m) 
        { 
            if (m.Msg == WM_USER_SIMCONNECT) 
            { 
                if (simconnect != null) 
                { 
                    simconnect.ReceiveMessage(); 
                } 
            } 
            else 
            { 
                base.DefWndProc(ref m); 
            } 
        } 

      

        private void closeConnection() 
        { 
            if (simconnect != null) 
            { 
                // Dispose serves the same purpose as SimConnect_Close() 
                simconnect.Dispose(); 
                simconnect = null; 
                displayText("Connection closed"); 
            } 
        } 

        // Configura os dados relacionados ao simconnect e os manipuladores de resposta 
        private void initDataRequest() 
        { 
            try 
            { 
                // Registra a função de evento de conexão
                simconnect.OnRecvOpen += new SimConnect.RecvOpenEventHandler(simconnect_OnRecvOpen); 
                
                // Registra a função de evento de saída
                simconnect.OnRecvQuit += new SimConnect.RecvQuitEventHandler(simconnect_OnRecvQuit); 

                // Registra a função de recepção de falhas 
                simconnect.OnRecvException += new SimConnect.RecvExceptionEventHandler(simconnect_OnRecvException);
                                
                // Define a estrutura das luzes do avião
                simconnect.AddToDataDefinition(DATASETS.StDatasetLights, "Title", null, SIMCONNECT_DATATYPE.STRING256, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.StDatasetLights, "LIGHT ON STATES", null, SIMCONNECT_DATATYPE.INT32, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.StDatasetLights, "LIGHT BEACON ON", null, SIMCONNECT_DATATYPE.INT32, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.StDatasetLights, "LIGHT LANDING ON", null, SIMCONNECT_DATATYPE.INT32, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.StDatasetLights, "LIGH TAXI ON", null, SIMCONNECT_DATATYPE.INT32, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                
                // Registra o dataset de luzes do avião
                simconnect.RegisterDataDefineStruct<StDatasetLights>(DATASETS.StDatasetLights); 
                
                // Define a estrutura de dados de telemetria
                simconnect.AddToDataDefinition(DATASETS.Struct1, "Title", null, SIMCONNECT_DATATYPE.STRING256, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.Struct1, "Plane Latitude", "degrees", SIMCONNECT_DATATYPE.FLOAT64, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.Struct1, "Plane Longitude", "degrees", SIMCONNECT_DATATYPE.FLOAT64, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.Struct1, "Plane Altitude", "feet", SIMCONNECT_DATATYPE.FLOAT64, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.Struct1, "ATTITUDE INDICATOR PITCH DEGREES", "radians", SIMCONNECT_DATATYPE.FLOAT64, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.Struct1, "ATTITUDE INDICATOR BANK DEGREES", "radians", SIMCONNECT_DATATYPE.FLOAT64, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                simconnect.AddToDataDefinition(DATASETS.Struct1, "LIGHT ON STATES", null, SIMCONNECT_DATATYPE.INT32, 0.0f, SimConnect.SIMCONNECT_UNUSED);
                


                // Registra a estrutura de dados de telemetria
                simconnect.RegisterDataDefineStruct<Struct1>(DATASETS.Struct1); 

                // Registra a função que recebe os datasets do avião 
                simconnect.OnRecvSimobjectDataBytype += new SimConnect.RecvSimobjectDataBytypeEventHandler(simconnect_OnRecvSimobjectDataBytype); 
            } 
            catch (COMException ex) 
            { 
                displayText(ex.Message); 
            } 
        } 

        void simconnect_OnRecvOpen(SimConnect sender, SIMCONNECT_RECV_OPEN data) 
        { 
            displayText("Conectado ao Flight Simulator"); 
        } 

       
        void simconnect_OnRecvQuit(SimConnect sender, SIMCONNECT_RECV data) 
        { 
            displayText("O Flight Simulator foi fechado."); 
            closeConnection(); 
        } 

        void simconnect_OnRecvException(SimConnect sender, SIMCONNECT_RECV_EXCEPTION data) 
        { 
            displayText("Erro registrado: " + data.dwException); 
        } 

       private void Form1_FormClosed(object sender, FormClosedEventArgs e) 
        { 
            closeConnection(); 
        } 


        // Recebe os dados de telemetria do avião
        void simconnect_OnRecvSimobjectDataBytype(SimConnect sender, SIMCONNECT_RECV_SIMOBJECT_DATA_BYTYPE data) 
        {

            switch ((DATA)data.dwRequestID) 
            {
                case DATA.REQUEST_1:
                    {
                        Struct1 s1 = (Struct1)data.dwData[0];

                        listBox1.Items.Clear();

                        displayText("Title: " + s1.title);
                        displayText("Lat:   " + s1.latitude);
                        displayText("Lon:   " + s1.longitude);
                        displayText("Alt:   " + s1.altitude);
                        displayText("Ângulo ataque:   " + s1.anguloataque * 57.3);
                        displayText("Ângulo lateral:   " + s1.angulolateral * 57.3);
                        displayText("LIGHT ON STATES = " + s1.LIGHT_NAV_ON);



                        int altitude;

                        altitude = (int)s1.altitude;

                        //Só envia os dados pelas seriais se elas estiverem habilitadas
                        if (serialportPICenabled == true)
                        {
                            // Envia o pacote do ângulo de ataque do avião pela serial
                            sendanguloataque((int)((s1.anguloataque * 57.3) + 85));

                            // Envia o pacote do ângulo lateral do aviao pela serial
                            sendangulolateral((int)(-(s1.angulolateral * 57.3) + 85));

                            // Envia o pacote da altitude pela serial já transformando de pés para metro
                            sendaltitude((int)(s1.altitude * 0.3048));

                            
                            
                        }

                        if (serialportARDenabled == true)
                        {
                            // Envia as informações de lâmpadas do avião para o Arduino
                            sendlamps(s1.LIGHT_NAV_ON);
                        }


                        // Dispara uma nova captura de grandezas
                        timer1.Enabled = true;

                        break;
                    }
                    

                case DATA.DATASET_LIGHTS:
                    {
                        StDatasetLights s2 = (StDatasetLights)data.dwData[0];

                        listBox1.Items.Clear();

                        displayText("Title: " + s2.title);
                        displayText("Nav Light " + s2.LIGHT_NAV_ON.ToString());
                        displayText("Beacon Light " + s2.LIGHT_BEACON_ON);
                        displayText("Landing Light " + s2.LIGHT_LANDING_ON);
                        displayText("Taxi Light " + s2.LIGHT_TAXI_ON);


                        displayText("Sample: " + samplecont++);
                        


                        break;
                    }


                default: 
                    displayText("Id de estrutura de dados não reconhecido: " + data.dwRequestID); 
                    break; 
            } 
        } 
     

     
        void displayText(string s) 
        {
            listBox1.Items.Add(s);
        }

        private void button1_Click(object sender, EventArgs e)
        {          
            if (simconnect == null)
            {
                try
                {
                    // Instancia o objeto Simconnect para o uso 
                    simconnect = new SimConnect("Managed Data Request", this.Handle, WM_USER_SIMCONNECT, null, 0);


                    // Configura os dados relacionados ao simconnect e os manipuladores de resposta
                    initDataRequest();


                    // Só abre as portas seriais as portas com estiverem selecionadas
                    if (comboBox2.Text != "")
                    {
                        serialPort2.Open();

                        serialportARDenabled = true;
                    }
                    else
                    {
                        serialportARDenabled = false;
                    }


                    // Só abre as portas seriais as portas com estiverem selecionadas
                    if (comboBox1.Text != "")
                    {
                        serialPort1.Open();

                        serialportPICenabled = true;
                    }
                    else
                    {
                        serialportPICenabled = false;
                    }

                    Atualiza.Enabled = true;
                    Desconecta.Enabled = true;

                }
                catch (COMException ex)
                {
                    displayText("Impossível conectar ao Flight Simulator.");
                    Atualiza.Enabled = false;
                    Desconecta.Enabled = false;
                    timer1.Enabled = false;

                }
            }
            else
            {
                displayText("Erro conexão já foi aberta! Tente novamente.");

                simconnect = null;

                closeConnection();

              
                serialPort1.Close();

                serialPort2.Close();

                serialportPICenabled = false;

                serialportARDenabled = false;
                
                Atualiza.Enabled = false;

                Desconecta.Enabled = false;
            } 
        }

        private void Desconecta_Click(object sender, EventArgs e)
        {
            closeConnection();
         
            serialPort1.Close();

            serialPort2.Close();

            serialportPICenabled = false;

            serialportARDenabled = false;
        }

        private void Atualiza_Click(object sender, EventArgs e)
        {
            // Requisita o dataset de telemetria do avião            
            //simconnect.RequestDataOnSimObjectType(DATA.REQUEST_1, DATASETS.Struct1, 0, SIMCONNECT_SIMOBJECT_TYPE.USER);

            // Requisita o dataset das luzes do avião 
            // simconnect.RequestDataOnSimObjectType(DATA.DATASET_LIGHTS, DATASETS.StDatasetLights, 0, SIMCONNECT_SIMOBJECT_TYPE.USER);
                       

            timer1.Enabled = true;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
          
        }



        // Timer de requisição periódica de datasets grandezas
        private void timer1_Tick(object sender, EventArgs e)
        {
            // Requisita o dataset de telemetria do avião
            simconnect.RequestDataOnSimObjectType(DATA.REQUEST_1, DATASETS.Struct1, 0, SIMCONNECT_SIMOBJECT_TYPE.USER);

            // Requisita o dataset das luzes do avião
            //simconnect.RequestDataOnSimObjectType(DATA.DATASET_LIGHTS, DATASETS.StDatasetLights, 0, SIMCONNECT_SIMOBJECT_TYPE.USER);
            
            
            displayText("Requisição enviada...");
            timer1.Enabled = false;
        }


        // Preenche o pacote de altitude e envia
        void sendaltitude(int altitude)
        {
            Byte [] VectTx = new Byte[10];
            Byte checksum;

            // Início do pacote com STX
            VectTx[0] = (Byte)0x02; 
            checksum = VectTx[0];

            // Tamanho do pacote de dados de altitude (3 bytes)
            VectTx[1] = (Byte)0x03; 
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[1]);

            // ID do pacote de altitude (0x01) 
            VectTx[2] = (Byte)0x01; 
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[2]);

            // Byte mais significativo da altitude
            VectTx[3] = (Byte)(altitude >> 8 & (Byte)0xFF);
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[3]);

            // Byte menos significativo da altitude
            VectTx[4] = (Byte)(altitude & (Byte)0xFF); 
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[4]);

            // Checagem de soma para a confirmação do pacote no receptor
            VectTx[5] = checksum;

            // Dispara o envio do pacote
            serialPort1.Write(VectTx, 0, 6);

        }


        // Preenche o pacote de ângulo de ataque e envia
        void sendanguloataque(int angulo)
        {
            Byte[] VectTx = new Byte[10];
            Byte checksum;

            

            // Só envia se houver mudança
            if (anguloataqueant != angulo)
            {
                anguloataqueant = angulo;

                // Início do pacote com STX
                VectTx[0] = (Byte)0x02;
                checksum = VectTx[0];

                // Tamanho do pacote de dados (2 bytes)
                VectTx[1] = (Byte)0x02;
                checksum = (Byte)((Byte)checksum + (Byte)VectTx[1]);

                // ID do pacote de ângulo de ataque
                VectTx[2] = (Byte)0x02;
                checksum = (Byte)((Byte)checksum + (Byte)VectTx[2]);

                // Ângulo de ataque
                VectTx[3] = (Byte)(angulo & (Byte)0xFF);
                checksum = (Byte)((Byte)checksum + (Byte)VectTx[3]);

                // Checagem de soma para a confirmação do pacote no receptor
                VectTx[4] = checksum;

                // Dispara o envio do pacote
                serialPort1.Write(VectTx, 0, 6);
            }

        }


        // Preenche o pacote de ângulo de laterail e envia
        void sendangulolateral(int angulo)
        {
           
            Byte[] VectTx = new Byte[10];
            Byte checksum;

            // Só envia se houver mudança
            if (angulolateralant != angulo)
            {

                angulolateralant = angulo;

                // Início do pacote com STX
                VectTx[0] = (Byte)0x02;
                checksum = VectTx[0];

                // Tamanho do pacote de dados (2 bytes)
                VectTx[1] = (Byte)0x02;
                checksum = (Byte)((Byte)checksum + (Byte)VectTx[1]);

                // ID do pacote de ângulo de ataque
                VectTx[2] = (Byte)0x04;
                checksum = (Byte)((Byte)checksum + (Byte)VectTx[2]);

                // Ângulo de ataque
                VectTx[3] = (Byte)(angulo & (Byte)0xFF);
                checksum = (Byte)((Byte)checksum + (Byte)VectTx[3]);

                // Checagem de soma para a confirmação do pacote no receptor
                VectTx[4] = checksum;

                // Dispara o envio do pacote
                serialPort1.Write(VectTx, 0, 6);
            }
        }





        // Preenche o pacote de ângulo de lampadas
        void sendlamps(int lampmask)
        {
            Byte[] VectTx = new Byte[10];
            Byte checksum;

            // Início do pacote com STX
            VectTx[0] = (Byte)0x02;
            checksum = VectTx[0];

            // Tamanho do pacote de dados (2 bytes)
            VectTx[1] = (Byte)0x02;
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[1]);

            // ID do pacote de ângulo de ataque
            VectTx[2] = (Byte)0x03;
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[2]);

            // mascara de lampadas
            VectTx[3] = (Byte)(lampmask & (Byte)0xFF);
            checksum = (Byte)((Byte)checksum + (Byte)VectTx[3]);

            // Checagem de soma para a confirmação do pacote no receptor
            VectTx[4] = checksum;

            // Dispara o envio do pacote
            serialPort2.Write(VectTx, 0, 6);

        }




        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort1.PortName = comboBox1.Text;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            serialPort2.PortName = comboBox2.Text;
        }       
    } 
} 
 