#include "C:\marcos\puc\2015\semestre 2\tai\altimetro\main.h"




#define DISP_TOP_ON output_low(PIN_C3)
#define DISP_TOP_OFF output_high(PIN_C3)

#define DISP_LEFT_TOP_ON output_low(PIN_C2)
#define DISP_LEFT_TOP_OFF output_high(PIN_C2)

#define DISP_RIGHT_TOP_ON output_low(PIN_A0)
#define DISP_RIGHT_TOP_OFF output_high(PIN_A0)

#define DISP_MIDDLE_ON output_low(PIN_C1)
#define DISP_MIDDLE_OFF output_high(PIN_C1)

#define DISP_BOTTON_ON output_low(PIN_C5)
#define DISP_BOTTON_OFF output_high(PIN_C5)

#define DISP_BOTTON_LEFT_ON output_low(PIN_C0)
#define DISP_BOTTON_LEFT_OFF output_high(PIN_C0)

#define DISP_BOTTON_RIGHT_ON output_low(PIN_C4)
#define DISP_BOTTON_RIGHT_OFF output_high(PIN_C4)

#define X1_ON output_high(PIN_B0)
#define X1_OFF output_low(PIN_B0)

#define X10_ON output_high(PIN_B1)
#define X10_OFF output_low(PIN_B1)

#define X100_ON output_high(PIN_B2)
#define X100_OFF output_low(PIN_B2)

#define X1000_ON output_high(PIN_B3)
#define X1000_OFF output_low(PIN_B3)


// Prot�tipos
void selectline(int line);
void selectnumber(int num);
int convertascint(char c);
void convertdisplaynumber();
void UartRx();
void DisplayData();
void ProcessPacketRx();

int selectlinecount;
int divtime;
int numberx1;
int numberx10;
int numberx100;
int numberx1000;
long numdisplay = 0;
char c;

#define EST_RX_STX      0x00
#define EST_RX_SIZE     0x01
#define EST_RX_DATA     0x02
#define EST_RX_CHECKSUM 0x03

int estrx = EST_RX_STX;
int rxsize;
int checksumreceived;
int rxcount;

#define RX_MAX_SIZE 20
char datarx[RX_MAX_SIZE];



void main()
{

   port_b_pullups(TRUE);
   setup_adc_ports(NO_ANALOGS);
   setup_adc(ADC_OFF);
   setup_spi(SPI_SS_DISABLED);
   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_DISABLED);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);

   
   numdisplay = 0;
		  	
	convertdisplaynumber();
   
   

	while(1)
	{
		UartRx();   
	
		DisplayData();
	}


}

void DisplayData()
{
	if(divtime++ == 255)
	{
	  		divtime = 0;
		  		
	  		if(selectlinecount++ >= 4)
	  		{
	  		   selectlinecount = 0;
	  		   
	  		    
	  		}
		  		
	  		selectline(selectlinecount);
		  	
	  		   
	}
}




void UartRx()
{	
	if(kbhit())
	{
		c = getc();
		  		
		switch(estrx)
		{
			case EST_RX_STX:
			{
				if(c == 0x02)
				{
					checksumreceived = 0x02;
					
					estrx = EST_RX_SIZE;						
				}
			break;
			}
		
			case EST_RX_SIZE:
			{
				rxsize = c;
				
				checksumreceived = checksumreceived + rxsize;
				
				if((rxsize > RX_MAX_SIZE)||(rxsize == 0))
				{
					estrx = EST_RX_STX;    
				}
				else
				{
					rxcount = 0;
					estrx = EST_RX_DATA; 
				}
				
			break;
			}
		
			case EST_RX_DATA:
			{
			  datarx[rxcount++] = c;
			  
			  checksumreceived = checksumreceived + c; 
			  
			  if(rxcount == rxsize)
			  {
			  		estrx = EST_RX_CHECKSUM; 	
			  }

			break;
			}
			
			case EST_RX_CHECKSUM:
			{				
				if(checksumreceived == c)
				{
					ProcessPacketRx();
				}
							
				estrx = EST_RX_STX;
			break;
			}
			
			default:
			{
			   estrx = EST_RX_STX;   
			}
		}
	}
}


void ProcessPacketRx()
{
	if(datarx[0] == 0x01)
	{
		numdisplay = datarx[1] << 8;
		
		numdisplay = numdisplay | datarx[2]; 
		  	
	  	convertdisplaynumber(); 	  
	}
}



void selectnumber(int num)
{
	switch(num)
	{
		case 0:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_ON; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_OFF;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_ON;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		case 1:
		{
			DISP_TOP_OFF;
			DISP_LEFT_TOP_OFF; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_OFF;
			DISP_BOTTON_OFF;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		case 2:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_OFF; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_ON;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_ON;
			DISP_BOTTON_RIGHT_OFF;
		break;
		}
		
		case 3:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_OFF; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_ON;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		case 4:
		{
			DISP_TOP_OFF;
			DISP_LEFT_TOP_ON; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_ON;
			DISP_BOTTON_OFF;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		case 5:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_ON; 
			DISP_RIGHT_TOP_OFF;
			DISP_MIDDLE_ON;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
				
		case 6:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_ON; 
			DISP_RIGHT_TOP_OFF;
			DISP_MIDDLE_ON;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_ON;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
				
		case 7:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_OFF; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_OFF;
			DISP_BOTTON_OFF;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		case 8:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_ON; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_ON;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_ON;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		case 9:
		{
			DISP_TOP_ON;
			DISP_LEFT_TOP_ON; 
			DISP_RIGHT_TOP_ON;
			DISP_MIDDLE_ON;
			DISP_BOTTON_ON;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_ON;
		break;
		}
		
		default:
		{
			DISP_TOP_OFF;
			DISP_LEFT_TOP_OFF; 
			DISP_RIGHT_TOP_OFF;
			DISP_MIDDLE_OFF;
			DISP_BOTTON_OFF;
			DISP_BOTTON_LEFT_OFF;
			DISP_BOTTON_RIGHT_OFF;
		}
	}
}



void selectline(int line)
{
	switch(line)
	{
		case 0:
		{
		  	X1_ON;
			X10_OFF;
			X100_OFF;
			X1000_OFF; 
			selectnumber(numberx1);			
		break;
		}
		
		case 1:
		{
		  	X1_OFF;
			X10_ON;
			X100_OFF;
			X1000_OFF;  
			selectnumber(numberx10);
		break;
		}
		
		case 2:
		{
		  	X1_OFF;
			X10_OFF;
			X100_ON;
			X1000_OFF;  
		   selectnumber(numberx100);
		break;
		}
		
		case 3:
		{
		  	X1_OFF;
			X10_OFF;
			X100_OFF;
			X1000_ON;  
			selectnumber(numberx1000);
		break;
		}
		
		default:
		{
			X1_OFF;
			X10_OFF;
			X100_OFF;
			X1000_OFF;
		}
	}
}


void convertdisplaynumber()
{
	char vect[5];
	
	sprintf(vect,"%04lu",numdisplay);

	numberx1 = convertascint(vect[3]);
	
	numberx10 = convertascint(vect[2]);
	
	numberx100 = convertascint(vect[1]);
	
	numberx1000 = convertascint(vect[0]);
}

int convertascint(char c)
{
	switch(c)
	{
		case '0':
		{
			return(0);
		}
		
		case '1':
		{
			return(1);
		}
		
		case '2':
		{
			return(2);
		}
		
		case '3':
		{
			return(3);
		}
		
		case '4':
		{
			return(4);
		}
		
		case '5':
		{
			return(5);
		}
		
		case '6':
		{
			return(6);
		}
		
		case '7':
		{
			return(7);
		}
		
		case '8':
		{
			return(8);
		}
		
		case '9':
		{
			return(9);
		}		
	}
	
	return(255);
}
