#include "C:\marcos\puc\2015\semestre 2\tai\atuador\main.h"


int servowave;
unsigned long servotimervalue;
char c;

#define RX_MAX_SIZE 20
char datarx[RX_MAX_SIZE];

#define EST_RX_STX      0x00
#define EST_RX_SIZE     0x01
#define EST_RX_DATA     0x02
#define EST_RX_CHECKSUM 0x03

int estrx = EST_RX_STX;
int rxsize;
int checksumreceived;
int rxcount;



void ServoSet(unsigned int value);
void UartRx();
void ProcessPacketRx();

#int_TIMER1
void  TIMER1_isr(void) 
{
	
	//set_timer1(0xFFFE);
	
	
	if(servowave)
	{
		servowave = 0;
		
		output_low(PIN_B3);
	
		// Referente a 20ms
		set_timer1(40329);
		
	
	}
	else
	{
		servowave = 1;
		
		output_high(PIN_B3);
		
		set_timer1(servotimervalue);
		
	}
	
}



void main()
{

   setup_timer_0(RTCC_INTERNAL|RTCC_DIV_1);
   setup_timer_1(T1_INTERNAL|T1_DIV_BY_2);
   setup_timer_2(T2_DISABLED,0,1);
   setup_comparator(NC_NC_NC_NC);
   setup_vref(FALSE);
   enable_interrupts(INT_TIMER1);
   enable_interrupts(GLOBAL);
//Setup_Oscillator parameter not selected from Intr Oscillotar Config tab

   // TODO: USER CODE!!
   
   ServoSet(90);
   
   while(1)
  	{
  		
  		//servotimervalue = 63640;
  		//ServoSet(90);
  		
  		//delay_ms(2000);
  		
  		//ServoSet(180);
  	
  		//servotimervalue = 64662;
  	
  		//delay_ms(2000);
  	
  		//ServoSet(0);
  	
  		//servotimervalue = 62636;
  	
  		//delay_ms(2000);
  		
  		UartRx(); 
  	
  	}
  

}



void ServoSet(unsigned int value)
{
	int aux;
	
	servotimervalue = 64652;
	
	
	// Multiplica��o for�ada pois a porcaria do compilador nao consegu fazer!
	while(value--)
	{
		servotimervalue = servotimervalue - 12;
	}
	
		
	
}





void ProcessPacketRx()
{
	if(datarx[0] == 0x04)
	{
	   ServoSet(datarx[1]); 	   
	}
}




void UartRx()
{	
	if(kbhit())
	{
		c = getc();
		  		
		switch(estrx)
		{
			case EST_RX_STX:
			{
				if(c == 0x02)
				{
					checksumreceived = 0x02;
					
					estrx = EST_RX_SIZE;						
				}
			break;
			}
		
			case EST_RX_SIZE:
			{
				rxsize = c;
				
				checksumreceived = checksumreceived + rxsize;
				
				if((rxsize > RX_MAX_SIZE)||(rxsize == 0))
				{
					estrx = EST_RX_STX;    
				}
				else
				{
					rxcount = 0;
					estrx = EST_RX_DATA; 
				}
				
			break;
			}
		
			case EST_RX_DATA:
			{
			  datarx[rxcount++] = c;
			  
			  checksumreceived = checksumreceived + c; 
			  
			  if(rxcount == rxsize)
			  {
			  		estrx = EST_RX_CHECKSUM; 	
			  }

			break;
			}
			
			case EST_RX_CHECKSUM:
			{				
				if(checksumreceived == c)
				{
					ProcessPacketRx();
				}
							
				estrx = EST_RX_STX;
			break;
			}
			
			default:
			{
			   estrx = EST_RX_STX;   
			}
		}
	}
}

