﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ControleDigital
{
    public partial class Form1 : Form
    {
        float processout = 0;

       

        int HeightOut;
        int PowerProp;

        // VariÃ¡veis 
        float[]e = new float[3];  // Vetor de erro
	    float[]m = new float[2]; // Vetor de saÃ­das do controlador
        float[]a = new float[3]; // Vetor dos coeficientes do controlador
        
	    float b1;   // Bias da porÃ§Ã£o incremental
	    int T;   // PerÃ­odo de amostragem  
	    float c;    // VariÃ¡vel de processo c[k]
	    float r;    // Setpoint r[k]
        int passo;
       

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs ed)
        {
            passo = 1;

            DrawScene();

            timer2.Enabled = true;
        }

        private void timer1_Tick(object sender, EventArgs ed)
        {
            
            switch (passo)
            {
                // Inicializar as variáveis 
                case 1:
                    {
                        m[1] = 0.5F; // m(-1) = 50(50%)

                        e[1] = 0;   // e(-1) = 0

                        e[2] = 0;   // e(-2) = 0 

                        timer1.Interval = 1; // Recarrega imediatamente

                        passo = 2; // Próximo passo

                        break;
                    }


                // Inicializar os parÃ¢metros
                case 2:
                    {
                        a[0] = 0.2F;    // a0 depende do projeto

                        a[1] = 0.05F;   // a1 depende do projeto   

                        a[2] = 0.02F;  // a2 depende do projeto  

                        b1 = 1;        // bias da porção incremental

                        T = 20;       // PerÃ­odo de amostragem (dependente da cte de tempo do processo) no caso 500ms

                        r = 0;       // Setpoint, no caso um sistema regulatÃ³rio

                        timer1.Interval = 1; // Recarrega imediatamente
                        
                        passo = 3;     // Próximo passo

                        break;
                    }


                // Amostrar a variável de processo e calcular o erro
                case 3:
                    {
                        c = ReadADC(); // Amostra a variável de processo

                        e[0] = r - c;  // Calcula o erro e[k] OBS: Inverte, o erro nesse caso a© entrada menos a saí­da

                        timer1.Interval = 1; // Recarrega imediatamente

                        passo = 4;     // Próximo passo

                        break;
                    }


                // Calcula a correção m(k)
                case 4:
                    {
                        // m(k) = a0*e(k)+a1*e(k-1)+a2*e(k-2)+b1*m(k-1)
                        m[0] = a[0] * e[0] + a[1] * e[1] + a[2] * e[2] + b1 * m[1];

                        // Limita a saí­da do controlador
                        if (m[0] > 1)
                        {
                            m[0] = 1;
                        }
                        else
                        {
                            if (m[0] < 0)
                            {
                                m[0] = 0;
                            }
                        }

                        // Imprime a saí­da do processo c[k] e a saida do controlador m[k] para plotar o gráfico  
                        //  os_printf("\n");
                        // printFloat(c);
                        //  printFloat(m[0]);
                        //  os_printf("\n");

                        timer1.Interval = 1; // Recarrega imediatamente

                        passo = 5; // Próximo passo

                        break;
                    }

                // Faz o passado
                case 5:
                    {
                        // Faz o passado do erro
                        e[2] = e[1];
                        e[1] = e[0];

                        // Faz o passado da correção do controlador
                        m[1] = m[0];

                        timer1.Interval = 1; // Recarrega imediatamente
                        
                        passo = 6; // Próximo passo			

                        break;
                    }

                // Escreve no conversor D/A(hold de ordem zero)
                case 6:
                    {
                        // Escreve no conversor D/A (hold de ordem zero)
                        WriteDAC(m[0]);

                        timer1.Interval = T; // Espera o processo responder dentro do tempo de amostragem

                        passo = 3; // Retorna ao 3o passo e fica em loop

                        break;
                    }
            }
        }

         // Processo da planta (simulado)
        private void Processo(float valuehold)
        {
		     // Função arbitrária do processo simulado
	         processout = processout + valuehold / 100 - processout / 200 ;

             // Atualiza a variável de desenho da potência do propulsor do foguete
             PowerProp = (int)(valuehold * 100);  
  
             // Atualiza a variável de desenho da posição do foguete    
             HeightOut = (int)(processout * 100);
        }

        // Le a variável de processo
        private float ReadADC()
        {
	        return processout;	
        }

        // Escreve no hold
        private void WriteDAC(float value)
        {
	        // Apresenta a mudanÃ§a ao processo
	        Processo(value);
        }	


        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            DrawScene();

            timer2.Enabled = true;
        }

        private void DrawScene()
        {
            // Apaga a tela
            Bitmap bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);//Cria um novo bitmap com as dimensões de um pictureBox que existe no form, obeserver que pode ser qualquer controle, inclusive o próprio form
            Graphics graphics = Graphics.FromImage(bitmap);//Cria um objeto Graphics, esse objeto é usado para desenhar e pintar no bitmap
            graphics.FillRectangle(Brushes.Black, 0, 0, bitmap.Width, bitmap.Height);
            pictureBox1.Image = bitmap;//faz com que o bitmap seja desenhado no pictureBox, se fosse outro controle a propriedade seria BackgroundImage.

            // Desenha o foguete
            DrawRocket(HeightOut, PowerProp);          

        }

       
        // Desenha o foguete
        private void DrawRocket(int Height,int Power)
        {
            int x, y;
            int Pw2, Pw1;

            if (Height < 12)
            {
                Height = 12;
            }

            x = pictureBox1.Width / 2;
            y = pictureBox1.Height - ((pictureBox1.Height * Height) / 100);

            Pw1 = (Power * 55) / 100;

            Pw2 = (Power * 35) / 100;


            SolidBrush myBrush = new SolidBrush(Color.Red);
            Pen myPen = new Pen(myBrush);

            myPen.Width = 3;
            myPen.Color = Color.Lime;

            SolidBrush myBrush1 = new SolidBrush(Color.Red);
            Pen myPenFire = new Pen(myBrush1);

            myPenFire.Width = 3;
            myPenFire.Color = Color.Red;

            Graphics graphics = Graphics.FromImage(pictureBox1.Image);

            graphics.DrawLine(myPen,x,y,x,y+60);

            graphics.DrawLine(myPen, x,y,x+10,y-20);

            graphics.DrawLine(myPen, x + 10, y - 20, x + 20, y);
           
            graphics.DrawLine(myPen, x, y + 58, x-15, y + 58);

            graphics.DrawLine(myPen, x - 15, y + 58, x, y + 38);

            graphics.DrawLine(myPen, x + 20, y, x + 20, y + 60);

            graphics.DrawLine(myPen, x + 20, y + 58, x + 35, y + 58);

            graphics.DrawLine(myPen, x + 35, y + 58, x + 20, y + 38);


            graphics.DrawLine(myPenFire, x + 10, y + 60, x + 10,y + 60 + Pw1);

            graphics.DrawLine(myPenFire, x + 5, y + 60, x + 5, y + 60 + Pw2);

            graphics.DrawLine(myPenFire, x + 15, y + 60, x + 15, y + 60 + Pw2);
        
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            DrawScene();
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void trackBar1_ValueChanged(object sender, EventArgs e)
        {
            int setpoint;

            setpoint = trackBar1.Value;
            
            r = (float)setpoint/100;
        }

    }
}








   
