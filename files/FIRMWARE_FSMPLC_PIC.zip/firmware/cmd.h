#ifndef CMD_H
#define CMD_H

void CmdProcess(unsigned char* Data, unsigned char Size);

// Ids de comando
#define CMD_SET_NET_NAME_DEVICE 0x01 // Recebe o nome do dispositivo na rede
#define CMD_SET_NET_SSID        0x02 // Recebe o SSID da rede ao qual o dispositivo ir� se conectar
#define CMD_SET_NET_PASSWORD    0x03 // Recebe o password da rede Wifi
#define CMD_SET_NET_PORT        0x04 // Recebe a porta usada para a conex�o UDP com o dispositivo
#define CMD_SAVE_NETWORK_CONFIG 0x05 // Recebe as configura��es de Nome do dispositivo, SSID e pasword da rede salvando em tabela
#define CMD_SAVE_IR_CODE        0x06 // Aciona a captura de um c�digo IR para a sua c�pia, gravando-o na posi��o especificada na tabela
#define CMD_DEL_IR_CODE         0x07 // Apaga uma regi�o de mem�ria da tabela referente a um c�digo IR cujo ID � passado
#define CMD_PLAY_IR_CODE        0x08 // Executa um c�digo IR para acionar uma fun��o do aparelho controlado
#define CMD_SAVE_MACRO_SCENE    0x09 // Salva uma macro de comandos 
#define CMD_DEL_MACRO_SCENE     0x0A // Apaga uma macro de comandos 
#define CMD_PLAY_MACRO_SCENE    0x0B // Reproduz uma macro associada a uma cena
#define CMD_EXIT_PROGRAM_MODE   0x0C // Sai do modo de programa��o para entrar no modo de opera��o
#define CMD_GET_MAC_IP          0x0D // Envia o MAC e o IP da interface station para o solicitante



#endif