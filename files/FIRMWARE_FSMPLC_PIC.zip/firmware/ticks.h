#ifndef TICKS_H
#define TICKS_H

void TimerInterruptOFF();
void TimerInterruptON();
void TimerInit();
void TxStart(unsigned char* Data, unsigned char size);
unsigned char TxBufferEmptyVerify();
unsigned char RxVerifyBytesReceived();
void RxFlush();
unsigned char RxGet(unsigned char* Data);
void UARTInterruptOFF();
void UARTInterruptON();
extern unsigned long ticks;

#endif