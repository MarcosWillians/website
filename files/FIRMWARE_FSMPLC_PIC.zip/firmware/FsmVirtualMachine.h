#ifndef FSM_VIRTUAL_MACHINE
#define FSM_VIRTUAL_MACHINE


// Sa�das do FSM-PLC
extern unsigned char Outputs[6];

// Entradas do FSM-PLC
extern unsigned char Inputs[6];

// Timers do FSM-PLC            
extern unsigned char Timers[16];

// Timer Enable do FSM-PLC
extern unsigned char TimerEnable[16];

// Contadores do FSM-PLC;
extern unsigned char Counters[16];

// Mem�rias do FSM-PLC
extern unsigned char Memorys[16];

// Estados do FSM-PLC
extern unsigned char States[50];


// Estrutura do bloco Entry
typedef struct
{
	unsigned char DataEntry[20];
}
StFsmSubStateEntry;

// Estrutura do bloco Repeat
typedef struct
{
	unsigned char DataRepeat[60];
}
StFsmSubStateRepeat;

// Estrutura do bloco Exit
typedef struct
{
	unsigned char DataExit[20];
}
StFsmSubStateExit;

typedef struct
{
	unsigned char StatesSubstate[50];
}
StStatesSubstate;

// Prot�tipos
void FsmVirtualMachineInit();
void FsmDefaultDataBank();
void FsmDefaultDataBank();

#endif