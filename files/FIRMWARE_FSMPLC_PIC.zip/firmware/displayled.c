

void diplaygeneralfail()
{
}


void leddisplayerror()
{
}