#ifndef MACROSCENE_H
#define MACROSCENE_H

void macroscenesinit();

void macroscenesdefaulttable();

void macrosceneplay(unsigned char scene);

void macroscenedel(unsigned char scene);

void macroscenesave(unsigned char *pData);

void macroscenesprocess();



#endif