// Autor : Marcos Willians    email : marcosfpga@gmail.com
#include<p18f452.h>
#include "FsmVirtualMachine.h"
#include "FsmIO.h"

void FsmIOInit()
{
	unsigned char teste;

	// Inicializa as portas de entrada do FSM-PLC	
	TRISAbits.TRISA1 = 1;
	TRISAbits.TRISA2 = 1;
	TRISAbits.TRISA3 = 1;
	TRISAbits.TRISA4 = 1;
	TRISAbits.TRISA5 = 1;
	TRISEbits.TRISE1 = 1;

	// Inicializa as portas de sa�da do FSM-PLC
	TRISDbits.TRISD2 = 0;
	TRISDbits.TRISD3 = 0;
	TRISDbits.TRISD4 = 0;
	TRISDbits.TRISD5 = 0;
	TRISDbits.TRISD6 = 0;
	TRISDbits.TRISD7 = 0;

	// Inicializa a entrada de indica��o de Programa��o/Execu��o
	TRISBbits.TRISB5 = 1;

	// Inicializa a saida de indica��o de Programa��o/Execu��o
	TRISEbits.TRISE0 = 0;

	// Programa as portas n�o usadas transformando-as em saidas
	TRISDbits.TRISD6 = 0;
	TRISDbits.TRISD7 = 0;
	
	TRISBbits.TRISB0 = 0;
	TRISBbits.TRISB1 = 0;
	TRISBbits.TRISB2 = 0;
	TRISBbits.TRISB3 = 0;
	TRISBbits.TRISB4 = 0;
	
	TRISAbits.TRISA0 = 0;


	// Habilita os pinos com a fun��o digital ao inves de analogica
	ADCON1 = 0x07;

	teste = ADCON1;
}


// Processa as portas de I/0
void FsmIOProcess()
{
	// Atualiza a sa�da o0 
	if(Outputs[0]==1)
	{
		PORTDbits.RD2 = 1;
	}
	else
	{
		PORTDbits.RD2 = 0;
	}

	
	// Atualiza a sa�da o1 
	if(Outputs[1]==1)
	{
		PORTDbits.RD3 = 1;
	}
	else
	{
		PORTDbits.RD3 = 0;
	}


	// Atualiza a sa�da o2 
	if(Outputs[2]==1)
	{
		PORTDbits.RD4 = 1;
	}
	else
	{
		PORTDbits.RD4 = 0;
	}


	// Atualiza a sa�da o3 
	if(Outputs[3]==1)
	{
		PORTDbits.RD5 = 1;
	}
	else
	{
		PORTDbits.RD5 = 0;
	}


	// Atualiza a sa�da o4 
	if(Outputs[4]==1)
	{
		PORTDbits.RD6 = 1;
	}
	else
	{
		PORTDbits.RD6 = 0;
	}

	
	// Atualiza a sa�da o4 
	if(Outputs[5]==1)
	{
		PORTDbits.RD7 = 1;
	}
	else
	{
		PORTDbits.RD7 = 0;
	}





	// Faz a amostragem da entrada 0
	if(PORTAbits.RA1 == 1)
	{
		Inputs[5] = 1;
	}
	else
	{
		Inputs[5] = 0;
	}

	// Faz a amostragem da entrada 1
	if(PORTAbits.RA2 == 1)
	{
		Inputs[4] = 1;
	}
	else
	{
		Inputs[4] = 0;
	}

	// Faz a amostragem da entrada 2
	if(PORTAbits.RA3 == 1)
	{
		Inputs[3] = 1;
	}
	else
	{
		Inputs[3] = 0;
	}
	
	// Faz a amostragem da entrada 3
	if(PORTAbits.RA4 == 1)
	{
		Inputs[2] = 1;
	}
	else
	{
		Inputs[2] = 0;
	}
	

	// Faz a amostragem da entrada 4
	if(PORTAbits.RA5 == 1)
	{
		Inputs[1] = 1;
	}
	else
	{
		Inputs[1] = 0;
	}

	
	// Faz a amostragem da entrada 5
	if(PORTEbits.RE1 == 1)
	{
		Inputs[0] = 1;
	}
	else
	{
		Inputs[0] = 0;
	}




}

