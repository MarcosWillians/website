#ifndef FSM_TASK_MANAGER_H
#define FSM_TASK_MANAGER_H

// Modos de opera��o do FSM-PLC
#define PLC_OPERATION_RUN_MODE   0x00  
#define PLC_OPERATION_PROG_MODE  0x01  

extern unsigned char FsmPlcOperationMode;

extern unsigned char oldreadswich;

void TaskManager();


#endif