#ifndef FSMPROTOCOL_H
#define FSMPROTOCOL_H


void FsmProtocolInit();
void FsmProtocolRefresh();


#endif