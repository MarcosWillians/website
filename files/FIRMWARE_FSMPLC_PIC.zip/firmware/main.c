// Autor : Marcos Willians    email : marcosfpga@gmail.com
//#pragma config DEBUG = ON     // MPLAB is supposed to manage this bit automatically 
#pragma config PWRT=ON          // Power up timer off (can interfere with the debugger synchronising with the debug executive)
#pragma config OSC = HSPLL
#pragma config WDT = ON        // Watchdog Timer disabled (control is placed on the SWDTEN bit) 
#pragma config LVP = OFF        // Single-Supply ICSP disabled 
#pragma config WDTPS = 64

#include<p18f452.h>
#include "ticks.h"
#include "databank.h"
#include "FsmVirtualMachine.h"
#include "FsmIO.h"
#include "main.h"
#include "FsmProtocol.h"
#include "FsmTaskManager.h"
#include "FsmElipse.h"




void main()
{	
	// Inicializa o servi�o de banco de dados
	DataBankInit();
	
	// Inicializa as portas de I/O do FSM-PLC
	FsmIOInit();

	// Inicializa a porta de comunica��o serial
	UARTInit();

	// Inicializa os timer do FSM-PLC
	TimerInit();

	// Inicializa o protocolo de comunica��es com a IDE no PC
	FsmProtocolInit();

	// Inicializa o protocolo de comunica��es com o supervis�rio Elipse	
	FsmElipseInit();

	// Inicializa a m�quina virtual do FSM-PLC
	FsmVirtualMachineInit();

	// Processa as tarefas do FSM-PLC
	TaskManager();


}


void ClearWatchdog()
{
	_asm
		clrwdt
	_endasm
}

void ResetPLC()
{
	_asm
		reset
	_endasm
}