#ifndef DATABANK_H
#define DATABANK_H


#define MAGICNUMBER_TABLE_ID   0x00
#define FSM_SUBSTATE_ENTRY_ID  0x01
#define FSM_SUBSTATE_REPEAT_ID 0x02
#define FSM_SUBSTATE_EXIT_ID   0x03
#define FSM_STATE_SUBSTATE_ID  0x04


void DataBankWrite(unsigned char TableId,unsigned int TableElementId,unsigned char* Data);
void DataBankRead(unsigned char TableId,unsigned int TableElementId,unsigned char* Data);
void DataBankReadOptimized(unsigned char TableId,unsigned int TableElementId,unsigned char* Data);

void DataBankInit(void);

#endif