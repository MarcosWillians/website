// Autor : Marcos Willians    email : marcosfpga@gmail.com
#include<p18f452.h>
#include "FsmVirtualMachine.h"
#include "FsmIO.h"
#include "main.h"
#include "FsmProtocol.h"
#include "FsmTaskManager.h"
#include "FsmElipse.h"

unsigned char FsmPlcOperationMode;

unsigned char oldreadswich;


void TaskManager()
{
	// Verifica o estado da chave de sele��o do modo se opera��o
	// Se estiver liberada (nivel 1) o FSM-PLC entra em modo de execu��o (nesse modo o FSM-PLC poder� entrar em modo de programa��o via comando na porta serial)
	// Se estiver travada (n�vel 0) o FSM-PLC ficar� em modo de programa��o (com a chave nessa posi��o n�o � poss�vel ir para o modo de execu��o)
	if(PORTBbits.RB5)
	{
		oldreadswich = 0;

		FsmPlcOperationMode = PLC_OPERATION_PROG_MODE;	
	}
	else
	{
		oldreadswich = 1;

		FsmPlcOperationMode = PLC_OPERATION_RUN_MODE;	
	}


	while(1)
	{
		if(FsmPlcOperationMode == PLC_OPERATION_RUN_MODE)
		{
			// Tarefa da m�quina virtual FSM
			FsmVirtualMachineRefresh();

			// Tarefa de comunica��o com o software supervis�rio Elipse	
			FsmElipseRefresh();
			
		}	
		else
		{	
			// Tarefa do protocolo de comunica��o com a IDE FSM-PLC no PC
			FsmProtocolRefresh();
		}

		// Reinicia o timer do watchdog
		ClearWatchdog();

	}

}
