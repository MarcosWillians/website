#ifndef FSM_IO
#define FSM_IO

void FsmIOInit();
void FsmIOProcess();

#endif