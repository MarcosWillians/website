#ifndef IRCONTROL_H
#define IRCONTROL_H


// Estrutura de configura��o
typedef struct
{
	unsigned char Name[24];          // Nome do dispositivo utilizado para separar os pacotes broadcast UPD
	unsigned char SSID[32];       // Nome da rede do Access Point ao qual o m�dulo ira se conectar
	unsigned char Netpassword[24];   // Senha da rede ao qual o o m�dulo ir� se conectar
	unsigned int UdpPort;            // Porta UDP a qual o m�dulo ficar� ouvindo
}
StConfigNetWorkData;


extern StConfigNetWorkData ConfigNetWorkData;
extern unsigned char progmode;

void IrControlTableDefault();
void EnterStationMode();
void IrControlInit();
void GetMacIpStation();

#endif