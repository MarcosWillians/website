

#include "ircontrol.h"
#include "databank.h"
#include "infrared.h"
#include "cmd.h"




// Prot�tipos
unsigned char CmdVerifyAddress(unsigned char* Data);



void CmdProcess(unsigned char* Data, unsigned char Size)
{
	unsigned char cmd;
	unsigned char* pData;
	unsigned char sizedatacmd;
	unsigned char idcmd;

	// Aponta para a �rea de dados	
	pData = Data;

	// O tamanho da area de dados do comando � o tamanho do pacote menos o byte de id de comando
	sizedatacmd = Size - 1;

	// Salva o id do comando
	idcmd = *pData++;


	#if 0
	switch(idcmd)
	{
		case CMD_SAVE_IR_CODE:
		{
			IrSave(pData);

			break;
		}
	
		case CMD_DEL_IR_CODE:
		{
			IrDel(*pData);
			break;
		}

		case CMD_PLAY_IR_CODE:
		{
			// Carrega o c�digo IR da EEPROM e toca 
			IrLoadandPlay(*pData);

			break;
		}

		case CMD_SAVE_MACRO_SCENE:
		{
			// Salva a macro de comandos
			macroscenesave(pData);

			break;
		}

		case CMD_DEL_MACRO_SCENE:
		{
			// Apaga uma macro/cena
			macroscenedel(*pData);				

			break;
		}

		case CMD_PLAY_MACRO_SCENE:
		{
			// Reproduz a macro/cena
			macrosceneplay(*pData);				

			break;
		}

		case CMD_EXIT_PROGRAM_MODE:
		{
			// Sai do modo AP para o modo station
			EnterStationMode();
			break;
		}

		case CMD_SAVE_NETWORK_CONFIG:
		{	
			DataBankWrite(WIFI_NETWORK_CFG_ID,0,&ConfigNetWorkData);
		
			break;
		}

		case CMD_SET_NET_NAME_DEVICE:
		{
			memcpy(&ConfigNetWorkData.Name,pData,24);

			break;
		}

		case CMD_SET_NET_SSID:
		{			
			memcpy(&ConfigNetWorkData.SSID,pData,32);

			break;
		}

		case CMD_SET_NET_PASSWORD:
		{
			memcpy(&ConfigNetWorkData.Netpassword,pData,24);				

			break;
		}
	
		case CMD_SET_NET_PORT:
		{
			memcpy(&ConfigNetWorkData.UdpPort,pData,2);

			break;
		}

		case CMD_GET_MAC_IP:
		{	
			// Aciona a m�quina que faz a leitura
			// do ip e mac do station e informa a resposta 
			// ao solicitante
			GetMacIpStation();
			break;
		} 


	}

	#endif

}

