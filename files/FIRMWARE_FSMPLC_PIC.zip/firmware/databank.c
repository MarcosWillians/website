// Autor : Marcos Willians    email : marcosfpga@gmail.com
// Implementa uma estrutura de armazenamento de dados em uma mem�ria eeprom externa
#include<p18f452.h>
#include "databank.h"
#include "GenericTypeDefs.h"
#include "FsmVirtualMachine.h"

// Numero m�gico que define se as tabelas dever�o ser formatadas, ou n�o
#define DATABANK_MAGIC_NUMBER 45



#define EEPROM_SPICON1     (SSPCON1)
#define EEPROM_CS_IO       (PORTDbits.RD0)
#define EEPROM_SSPBUF      (SSPBUF)
#define EEPROM_SPI_IF      (PIR1bits.SSPIF)
#define EEPROM_CS_TRIS     (TRISDbits.TRISD0)
#define EEPROM_SCK_TRIS    (TRISCbits.TRISC3)
#define EEPROM_SDI_TRIS    (TRISCbits.TRISC4)
#define EEPROM_SDO_TRIS    (TRISCbits.TRISC5)
#define EEPROM_SPISTATbits (SSPSTATbits)


#define PROPER_SPICON1	(0x21)
								
typedef struct
{
	unsigned char  TableId;
	DWORD TableAddress;
	unsigned char  SizeElement;
	unsigned int   NumElement;
}
StDataBank;	



// Tamanhos das tabelas
#define MAGICNUMBER_TABLE_SIZE 1
#define FSM_SUBSTATE_ENTRY_SIZE sizeof(StFsmSubStateEntry)
#define FSM_SUBSTATE_REPEAT_SIZE sizeof(StFsmSubStateRepeat)
#define FSM_SUBSTATE_EXIT_SIZE sizeof(StFsmSubStateExit)
#define FSM_STATE_SUBSTATE_SIZE sizeof(StStatesSubstate)


// Numero de elementos das tabelas
#define MAGICNUMBER_TABLE_NUM     1
#define FSM_SUBSTATE_ENTRY_NUM    50
#define FSM_SUBSTATE_REPEAT_NUM   50
#define FSM_SUBSTATE_EXIT_NUM     50
#define FSM_STATE_SUBSTATE_NUM    1


// Endere�os das tabelas na mem�ria eeprom		
#define MAGICNUMBER_TABLE_ADDRESS  0            
#define FSM_SUBSTATE_ENTRY_ADDRESS MAGICNUMBER_TABLE_ADDRESS + MAGICNUMBER_TABLE_SIZE * MAGICNUMBER_TABLE_NUM	
#define FSM_SUBSTATE_REPEAT_ADDRESS FSM_SUBSTATE_ENTRY_ADDRESS + FSM_SUBSTATE_ENTRY_SIZE * FSM_SUBSTATE_ENTRY_NUM
#define FSM_SUBSTATE_EXIT_ADDRESS FSM_SUBSTATE_REPEAT_ADDRESS + FSM_SUBSTATE_REPEAT_SIZE * FSM_SUBSTATE_REPEAT_NUM
#define FSM_STATE_SUBSTATE_ADDRESS FSM_SUBSTATE_EXIT_ADDRESS + FSM_SUBSTATE_EXIT_SIZE * FSM_SUBSTATE_EXIT_NUM

	
#define EEPROM_BUFFER_SIZE    			(1) 

// EEPROM SPI opcodes
#define READ	0x03	// Read data from memory array beginning at selected address
#define WRITE	0x02	// Write data to memory array beginning at selected address
#define WRDI	0x04	// Reset the write enable latch (disable write operations)
#define WREN	0x06	// Set the write enable latch (enable write operations)
#define RDSR	0x05	// Read Status register
#define WRSR	0x01	// Write Status register

#define EEPROM_MAX_SPI_FREQ		(10000000ul)	// Hz

static DWORD EEPROMAddress;
static BYTE EEPROMBuffer[EEPROM_BUFFER_SIZE];
static BYTE *EEPROMBufferPtr;

// Endere�os das tabelas
#define MAGICNUMBER_TABLE_ADDRESS  0            
#define FSM_SUBSTATE_ENTRY_ADDRESS MAGICNUMBER_TABLE_ADDRESS + MAGICNUMBER_TABLE_SIZE * MAGICNUMBER_TABLE_NUM	
#define FSM_SUBSTATE_REPEAT_ADDRESS FSM_SUBSTATE_ENTRY_ADDRESS + FSM_SUBSTATE_ENTRY_SIZE * FSM_SUBSTATE_ENTRY_NUM
#define FSM_SUBSTATE_EXIT_ADDRESS FSM_SUBSTATE_REPEAT_ADDRESS + FSM_SUBSTATE_REPEAT_SIZE * FSM_SUBSTATE_REPEAT_NUM
#define FSM_STATE_SUBSTATE_ADDRESS FSM_SUBSTATE_EXIT_ADDRESS + FSM_SUBSTATE_EXIT_SIZE * FSM_SUBSTATE_EXIT_NUM

		
// Estrutura de organiza��o das tabelas
const StDataBank TableList[] = {{MAGICNUMBER_TABLE_ID,MAGICNUMBER_TABLE_ADDRESS,MAGICNUMBER_TABLE_SIZE,MAGICNUMBER_TABLE_NUM},
								{FSM_SUBSTATE_ENTRY_ID,FSM_SUBSTATE_ENTRY_ADDRESS,FSM_SUBSTATE_ENTRY_SIZE,FSM_SUBSTATE_ENTRY_NUM},
								{FSM_SUBSTATE_REPEAT_ID,FSM_SUBSTATE_REPEAT_ADDRESS,FSM_SUBSTATE_REPEAT_SIZE,FSM_SUBSTATE_REPEAT_NUM},
								{FSM_SUBSTATE_EXIT_ID,FSM_SUBSTATE_EXIT_ADDRESS,FSM_SUBSTATE_EXIT_SIZE,FSM_SUBSTATE_EXIT_NUM},
								{FSM_STATE_SUBSTATE_ID,FSM_STATE_SUBSTATE_ADDRESS,FSM_STATE_SUBSTATE_SIZE,FSM_STATE_SUBSTATE_NUM},
								{0xFF          , 0 , 0               ,0  }};

// Prototipos
BOOL XEEIsBusy(void);
void XEEEndWrite(void);
void XEEBeginWrite(DWORD address);
unsigned char XEERead(void);
void XEEReadArray(DWORD address,BYTE *buffer,BYTE length);
void XEEBeginRead(DWORD address);
void XEEWrite(BYTE val);
static void DoWrite(void);

void XEEBeginRead(DWORD address)
{
	// Save the address and emptry the contents of our local buffer
	EEPROMAddress = address;
	EEPROMBufferPtr = EEPROMBuffer + EEPROM_BUFFER_SIZE;
}


void XEEReadArray(DWORD address,
                        BYTE *buffer,
                        BYTE length)
{
	BYTE Dummy;
	#if defined(__18CXX)
	BYTE SPICON1Save;
	#elif defined(__C30__)
	WORD SPICON1Save;
	#else
	DWORD SPICON1Save;
	#endif	

	// Save SPI state (clock speed)
	SPICON1Save = EEPROM_SPICON1;
	EEPROM_SPICON1 = PROPER_SPICON1;

	EEPROM_CS_IO = 0;

	// Send READ opcode
	EEPROM_SSPBUF = READ;
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	
	// Send address
	#if defined(USE_EEPROM_25LC1024)
	EEPROM_SSPBUF = ((DWORD_VAL*)&address)->v[2];
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	#endif
	EEPROM_SSPBUF = ((DWORD_VAL*)&address)->v[1];
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	EEPROM_SSPBUF = ((DWORD_VAL*)&address)->v[0];
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	
	while(length--)
	{
		EEPROM_SSPBUF = 0;
		while(!EEPROM_SPI_IF);
		if(buffer != (void*)0)
			*buffer++ = EEPROM_SSPBUF;
		EEPROM_SPI_IF = 0;
	};
	
	EEPROM_CS_IO = 1;

	// Restore SPI state
	EEPROM_SPICON1 = SPICON1Save;	
}


unsigned char XEERead(void)
{
	// Check if no more bytes are left in our local buffer
	if( EEPROMBufferPtr == EEPROMBuffer + EEPROM_BUFFER_SIZE )
	{ 
		// Get a new set of bytes
		XEEReadArray(EEPROMAddress, EEPROMBuffer, EEPROM_BUFFER_SIZE);
		EEPROMAddress += EEPROM_BUFFER_SIZE;
		EEPROMBufferPtr = EEPROMBuffer;	
	}

	// Return a byte from our local buffer
	return *EEPROMBufferPtr++;
}

void XEEWrite(BYTE val)
{
	*EEPROMBufferPtr++ = val;
	if(EEPROMBufferPtr == EEPROMBuffer + EEPROM_BUFFER_SIZE)
    {
		DoWrite();
    }   
}


void XEEBeginWrite(DWORD address)
{
	EEPROMAddress = address;
	EEPROMBufferPtr = EEPROMBuffer;
}

static void DoWrite(void)
{
	BYTE Dummy;
	BYTE BytesToWrite;
	#if defined(__18CXX)
	BYTE SPICON1Save;
	#elif defined(__C30__)
	WORD SPICON1Save;
	#else
	DWORD SPICON1Save;
	#endif	

	// Save SPI state (clock speed)
	SPICON1Save = EEPROM_SPICON1;
	EEPROM_SPICON1 = PROPER_SPICON1;
	
	// Set the Write Enable latch
	EEPROM_CS_IO = 0;
	EEPROM_SSPBUF = WREN;
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	EEPROM_CS_IO = 1;
	
	// Send WRITE opcode
	EEPROM_CS_IO = 0;
	EEPROM_SSPBUF = WRITE;
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	
	// Send address
	#if defined(USE_EEPROM_25LC1024)
	EEPROM_SSPBUF = ((DWORD_VAL*)&EEPROMAddress)->v[2];
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	#endif
	EEPROM_SSPBUF = ((DWORD_VAL*)&EEPROMAddress)->v[1];
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	EEPROM_SSPBUF = ((DWORD_VAL*)&EEPROMAddress)->v[0];
	while(!EEPROM_SPI_IF);
	Dummy = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	
	BytesToWrite = (BYTE)(EEPROMBufferPtr - EEPROMBuffer);
	
	EEPROMAddress += BytesToWrite;
	EEPROMBufferPtr = EEPROMBuffer;

	while(BytesToWrite--)
	{
		// Send the byte to write
		EEPROM_SSPBUF = *EEPROMBufferPtr++;
		while(!EEPROM_SPI_IF);
		Dummy = EEPROM_SSPBUF;
		EEPROM_SPI_IF = 0;
		ClrWdt();
	}

	// Begin the write
	EEPROM_CS_IO = 1;

	EEPROMBufferPtr = EEPROMBuffer;

	// Restore SPI State
	EEPROM_SPICON1 = SPICON1Save;

	// Wait for write to complete
	while( XEEIsBusy() );

	ClrWdt();
}


void XEEEndWrite(void)
{
	if( EEPROMBufferPtr != EEPROMBuffer )
    {
		DoWrite();
    }
}


BOOL XEEIsBusy(void)
{
	BYTE_VAL result;
	#if defined(__18CXX)
	BYTE SPICON1Save;
	#elif defined(__C30__)
	WORD SPICON1Save;
	#else
	DWORD SPICON1Save;
	#endif	

	// Save SPI state (clock speed)
	SPICON1Save = EEPROM_SPICON1;
	EEPROM_SPICON1 = PROPER_SPICON1;

	EEPROM_CS_IO = 0;
	// Send RDSR - Read Status Register opcode
	EEPROM_SSPBUF = RDSR;
	while(!EEPROM_SPI_IF);
	result.Val = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	
	// Get register contents
	EEPROM_SSPBUF = 0;
	while(!EEPROM_SPI_IF);
	result.Val = EEPROM_SSPBUF;
	EEPROM_SPI_IF = 0;
	EEPROM_CS_IO = 1;

	// Restore SPI State
	EEPROM_SPICON1 = SPICON1Save;

	return result.bits.b0;
}




void DataBankInit(void)
{
	static unsigned char magicnumber;

	EEPROM_CS_IO = 1;
	EEPROM_CS_TRIS = 0;		// Drive SPI EEPROM chip select pin

	EEPROM_SCK_TRIS = 0;	// Set SCK pin as an output
	EEPROM_SDI_TRIS = 1;	// Make sure SDI pin is an input
	EEPROM_SDO_TRIS = 0;	// Set SDO pin as an output


	EEPROM_SPICON1 = PROPER_SPICON1; // See PROPER_SPICON1 definition above
	EEPROM_SPI_IF = 0;
	EEPROM_SPISTATbits.CKE = 1; 	// Transmit data on rising edge of clock
	EEPROM_SPISTATbits.SMP = 0;		// Input sampled at middle of data output time


	DataBankRead(MAGICNUMBER_TABLE_ID,0,&magicnumber);


	// Verifica se a formata��o das tabelas � necess�ria
	if(magicnumber != DATABANK_MAGIC_NUMBER)
	{
		// Outras funcoes de formata��o de tabelas
		
		// Preenche a tabela de estados do FSM-PLC
		FsmDefaultDataBank();

		// Salva o novo magic number para evitar a reformata��o das tabelas no proximo boot
		magicnumber = DATABANK_MAGIC_NUMBER;
		DataBankWrite(MAGICNUMBER_TABLE_ID,0,&magicnumber);
	}	
}								
								


void DataBankWrite(unsigned char TableId,unsigned int TableElementId,unsigned char* Data)
{
	auto unsigned char i,j;
	
	static DWORD aux;
	unsigned char res;	
	unsigned int aux2;

	//Procura pela tabela requisitada
	for(i=0;i<255;i++)
	{
		if(TableId == TableList[i].TableId)
		{	
			if(TableElementId < TableList[i].NumElement)
			{
				aux = TableList[i].TableAddress + TableList[i].SizeElement * TableElementId;
		
			    XEEBeginWrite(aux);
					
				for(j=0;j<TableList[i].SizeElement;j++)
				{
					res = *Data;					

					XEEWrite(*Data);
					Data++;
				}			
		
				XEEEndWrite();
			}
		break;
		}
	}
}



void DataBankRead(unsigned char TableId,unsigned int TableElementId,unsigned char* Data)
{
	auto unsigned char i;
	auto unsigned char size;

	//Procura pela tabela requisitada
	for(i=0;i<255;i++)
	{
		if(TableId == TableList[i].TableId)
		{	
			if(TableElementId < TableList[i].NumElement)
			{
				XEEBeginRead(TableList[i].TableAddress + TableList[i].SizeElement * TableElementId);

				size = 	TableList[i].SizeElement;
				
				while(size)
				{
					*Data = XEERead();				
					Data++;
					size--;
				}
							//XEEReadArray(TableList[i].TableAddress + TableList[i].SizeElement * TableElementId,Data,TableList[i].SizeElement);
			}
		break;
		}
	}
}



void DataBankReadOptimized(unsigned char TableId,unsigned int TableElementId,unsigned char* Data)
{
	auto unsigned char i;
	auto unsigned char size;
	BYTE Dummy;
	BYTE SPICON1Save;
	
	//Procura pela tabela requisitada
	for(i=0;i<255;i++)
	{
		if(TableId == TableList[i].TableId)
		{	
			if(TableElementId < TableList[i].NumElement)
			{
				// Calcula a posi��o de leitura
				EEPROMAddress = TableList[i].TableAddress + TableList[i].SizeElement * TableElementId;
				EEPROMBufferPtr = EEPROMBuffer + EEPROM_BUFFER_SIZE;			
				size = 	TableList[i].SizeElement;
						
			
				// Configura a interface SPI e seleciona a mem�ria externa
				SPICON1Save = EEPROM_SPICON1;
				EEPROM_SPICON1 = PROPER_SPICON1;
				EEPROM_CS_IO = 0;
			
				// Envia o comando de leitura
				EEPROM_SSPBUF = READ;
				while(!EEPROM_SPI_IF);
				Dummy = EEPROM_SSPBUF;
				EEPROM_SPI_IF = 0;
				
				// Envia o byte mais significativo do endere�o
				EEPROM_SSPBUF = ((DWORD_VAL*)&EEPROMAddress)->v[1];
				while(!EEPROM_SPI_IF);
			
				Dummy = EEPROM_SSPBUF;
				
				// Envia o byte menos significativo do endere�o
				EEPROM_SPI_IF = 0;
				EEPROM_SSPBUF = ((DWORD_VAL*)&EEPROMAddress)->v[0];
				
				while(!EEPROM_SPI_IF);
				Dummy = EEPROM_SSPBUF;
				EEPROM_SPI_IF = 0;
				
				while(size--)
				{
					EEPROM_SSPBUF = 0;
					while(!EEPROM_SPI_IF);
					*Data = EEPROM_SSPBUF;
					
					if(*Data == 255)
					{	
						size = 0;
					}					

					Data++;
					EEPROM_SPI_IF = 0;
								
				}
				
				// Libera a mem�ria
				EEPROM_CS_IO = 1;
			
				// Restore SPI state
				EEPROM_SPICON1 = SPICON1Save;

			}
		break;
		}
	}
}

	