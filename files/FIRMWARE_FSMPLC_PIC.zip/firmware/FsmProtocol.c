// Autor : Marcos Willians    email : marcosfpga@gmail.com
#include "ticks.h"
#include "databank.h"
#include "FsmIO.h"

unsigned char bouncereceivebytes;
unsigned char oldcountreceivebytes;

#define FSM_PROTOCOL_BUFFER_SIZE 70

unsigned char FsmProtBuffer[FSM_PROTOCOL_BUFFER_SIZE];

// Prot�tipos
void FsmProtocolProcessPacket();
void FsmProtCmdWriteEntryBlock(unsigned char *pdata);
void FsmProtCmdWriteRepeatBlock(unsigned char *pdata);
void FsmProtCmdWriteExitBlock(unsigned char *pdata);
void FsmProtCmdWriteStatesBlock(unsigned char *pdata);
void FsmProtCmdReadEntryBlock(unsigned char block);
void FsmProtCmdReadRepeatBlock(unsigned char block);
void FsmProtCmdReadExitBlock(unsigned char block);
void FsmProtCmdReadStatesBlock();
void FsmReset();
void FsmAck();

void FsmProtocolInit()
{
	bouncereceivebytes = 0;
	oldcountreceivebytes = 0;
}

void FsmProtocolRefresh()
{
	// Verifica se existem bytes a serem recebidos
	if(RxVerifyBytesReceived())
	{
		if(oldcountreceivebytes == RxVerifyBytesReceived())
		{
			bouncereceivebytes++;

			// Se a quantidade de bytes recebidos se estabilizou, processa o pacote recebido
			if(bouncereceivebytes == 200)
			{
				FsmProtocolProcessPacket();
				
				bouncereceivebytes = 0;
				
				oldcountreceivebytes = 0;
			}

		}
		else
		{
			oldcountreceivebytes = RxVerifyBytesReceived();

			bouncereceivebytes = 0;
		}
	}
}


void FsmProtocolProcessPacket()
{

	// Formato do pacote STX + CMD + SIZEPACKET + DATAPACKET[n] + CHECKSUM + ETX

	unsigned char bytesreceived;
	unsigned char cmd;
	unsigned char i;
	unsigned char sizedata;
	unsigned char checksumcalc;
	unsigned char *pdatapacket;

	// Recebe o pacote
	bytesreceived = RxGet(FsmProtBuffer);

	// Verifica o STX
	if(FsmProtBuffer[0] != 0x02)
	{
		// Erro
		return;
	}

	// Salva o comando
	cmd = FsmProtBuffer[1];

	// Verifica o tamanho da �rea de dados do pacote
	sizedata = FsmProtBuffer[2];
	if(sizedata > FSM_PROTOCOL_BUFFER_SIZE - 5)
	{
		// Erro
		return;
	}
	
	// Calcula o checksum
	checksumcalc = 0x02 + cmd + sizedata;

	// Se o pacote tem dados, calcula o checksum da �rea de dados	
	if(sizedata)
	{	
		for(i=3;i<sizedata+3;i++)
		{
			checksumcalc = checksumcalc + FsmProtBuffer[i];
		}
		
		// Se o pacote tem dados, aponta para essa �rea para que a execu��o do comando possa utiliza-los
		pdatapacket = &FsmProtBuffer[3];
	}


	// Verifica o checksum
	if(checksumcalc != FsmProtBuffer[sizedata+3])
	{	
		// Erro
		return;
	}

	// Verifica o ETX
	if(FsmProtBuffer[sizedata+4] != 0x03)
	{
		// Erro
		return;
	}


	// Comandos do protocolo
	#define  FSM_PROT_CMD_WRITE_ENTRY_BLOCK        0x00
	#define  FSM_PROT_CMD_WRITE_REPEAT_BLOCK       0x01
	#define  FSM_PROT_CMD_WRITE_EXIT_BLOCK         0x02
	#define  FSM_PROT_CMD_WRITE_STATES_BLOCK       0x03
	#define  FSM_PROT_CMD_READ_ENTRY_BLOCK         0x04
	#define  FSM_PROT_CMD_READ_REPEAT_BLOCK        0x05
	#define  FSM_PROT_CMD_READ_EXIT_BLOCK          0x06
	#define  FSM_PROT_CMD_READ_STATES_BLOCK        0x07
	#define  FSM_PROT_CMD_READ_REPLY_ENTRY_BLOCK   0x08
	#define  FSM_PROT_CMD_READ_REPLY_REPEAT_BLOCK  0x09
	#define  FSM_PROT_CMD_READ_REPLY_EXIT_BLOCK    0x0A
	#define  FSM_PROT_CMD_READ_REPLY_STATES_BLOCK  0x0B
	#define  FSM_PROT_CMD_RESET                    0x0C
	#define  FSM_PROT_ACK                          0x0D
	#define  FSM_PROT_ACK_REPLY                    0x0E


	// Executa os comandos
	switch(cmd)
	{
		case FSM_PROT_CMD_WRITE_ENTRY_BLOCK:
		{
			FsmProtCmdWriteEntryBlock(pdatapacket);
		break;
		}

		case FSM_PROT_CMD_WRITE_REPEAT_BLOCK:
		{
			FsmProtCmdWriteRepeatBlock(pdatapacket);
		break;
		}

		case FSM_PROT_CMD_WRITE_EXIT_BLOCK:
		{
			FsmProtCmdWriteExitBlock(pdatapacket);
		break;
		}	

		case FSM_PROT_CMD_WRITE_STATES_BLOCK:
		{
			FsmProtCmdWriteStatesBlock(pdatapacket);
		break;
		}

		case FSM_PROT_CMD_READ_ENTRY_BLOCK:
		{
			FsmProtCmdReadEntryBlock(*pdatapacket);
			break;
		}

		case FSM_PROT_CMD_READ_REPEAT_BLOCK:
		{
			FsmProtCmdReadRepeatBlock(*pdatapacket);
			break;
		}

		case FSM_PROT_CMD_READ_EXIT_BLOCK:
		{
			FsmProtCmdReadExitBlock(*pdatapacket);
			break;
		}

		case FSM_PROT_CMD_READ_STATES_BLOCK:
		{
			FsmProtCmdReadStatesBlock();
			break;
		}

		case FSM_PROT_CMD_RESET:
		{
			FsmReset();
			break;
		}


		case FSM_PROT_ACK:
		{
			FsmAck();
			break;
		}

			
	} 
}



// Reinicia o FSM-PLC
void FsmReset()
{
	// Espera pelo reset por watchdog
	while(1)
	{
	}
}



void FsmAck()
{
	unsigned char checksumcalc;
	unsigned char cmd;

	
	// Formato do pacote STX + CMD + SIZEPACKET + DATAPACKET[n] + CHECKSUM + ETX

	// Preenche o pacote de resposta
	FsmProtBuffer[0] = 0x02;

	// Coloca o comando
	cmd = FSM_PROT_ACK_REPLY;
	FsmProtBuffer[1] = cmd;
	
	// Coloca o tamanho da �rea de dados do pacote
	FsmProtBuffer[2] = 0;

	// Calcula o checksum	
	checksumcalc = 0x02 + cmd;

	// Coloca o checksum
	FsmProtBuffer[3] = checksumcalc;

	// Coloca o ETX
	FsmProtBuffer[4] = 0x03;		

	// Transmite o pacote
	TxStart(FsmProtBuffer, 5);
}


void FsmProtCmdReadEntryBlock(unsigned char block)
{
	unsigned char *pdata;
	unsigned char checksumcalc;
	unsigned char i;
	unsigned char sizedata;
	unsigned char cmd;

	
	// Formato do pacote STX + CMD + SIZEPACKET + DATAPACKET[n] + CHECKSUM + ETX

	// Preenche o pacote de resposta
	FsmProtBuffer[0] = 0x02;

	// Coloca o comando
	cmd = FSM_PROT_CMD_READ_REPLY_ENTRY_BLOCK;
	FsmProtBuffer[1] = cmd;
	
	// Coloca o tamanho da �rea de dados do pacote
	sizedata = 20;
	FsmProtBuffer[2] = sizedata;

	// Aponta para a �rea de dados do buffer
	pdata = &FsmProtBuffer[3];

	// Copia o bloco requisitado no pacote de resposta
	DataBankRead(FSM_SUBSTATE_ENTRY_ID,block,(unsigned char*) pdata);

	// Calcula o checksum	
	checksumcalc = 0x02 + cmd + sizedata;

	for(i=3;i<sizedata+3;i++)
	{
		checksumcalc = checksumcalc + FsmProtBuffer[i];
	}

	// Coloca o checksum
	FsmProtBuffer[sizedata+3] = checksumcalc;

	// Coloca o ETX
	FsmProtBuffer[sizedata+4] = 0x03;		

	// Transmite o pacote
	TxStart(FsmProtBuffer, 5 + sizedata);

}


void FsmProtCmdReadRepeatBlock(unsigned char block)
{
	unsigned char *pdata;
	unsigned char checksumcalc;
	unsigned char i;
	unsigned char sizedata;
	unsigned char cmd;

	
	// Formato do pacote STX + CMD + SIZEPACKET + DATAPACKET[n] + CHECKSUM + ETX

	// Preenche o pacote de resposta
	FsmProtBuffer[0] = 0x02;

	// Coloca o comando
	cmd = FSM_PROT_CMD_READ_REPLY_REPEAT_BLOCK;
	FsmProtBuffer[1] = cmd;
	
	// Coloca o tamanho da �rea de dados do pacote
	sizedata = 60;
	FsmProtBuffer[2] = sizedata;

	// Aponta para a �rea de dados do buffer
	pdata = &FsmProtBuffer[3];

	// Copia o bloco requisitado no pacote de resposta
	DataBankRead(FSM_SUBSTATE_REPEAT_ID,block,(unsigned char*) pdata);

	// Calcula o checksum	
	checksumcalc = 0x02 + cmd + sizedata;

	for(i=3;i<sizedata+3;i++)
	{
		checksumcalc = checksumcalc + FsmProtBuffer[i];
	}

	// Coloca o checksum
	FsmProtBuffer[sizedata+3] = checksumcalc;

	// Coloca o ETX
	FsmProtBuffer[sizedata+4] = 0x03;	

	// Transmite o pacote
	TxStart(FsmProtBuffer, 5 + sizedata);	

}


void FsmProtCmdReadExitBlock(unsigned char block)
{
	unsigned char *pdata;
	unsigned char checksumcalc;
	unsigned char i;
	unsigned char sizedata;
	unsigned char cmd;

	
	// Formato do pacote STX + CMD + SIZEPACKET + DATAPACKET[n] + CHECKSUM + ETX

	// Preenche o pacote de resposta
	FsmProtBuffer[0] = 0x02;

	// Coloca o comando
	cmd = FSM_PROT_CMD_READ_REPLY_EXIT_BLOCK;
	FsmProtBuffer[1] = cmd;
	
	// Coloca o tamanho da �rea de dados do pacote
	sizedata = 20;
	FsmProtBuffer[2] = sizedata;

	// Aponta para a �rea de dados do buffer
	pdata = &FsmProtBuffer[3];

	// Copia o bloco requisitado no pacote de resposta
	DataBankRead(FSM_SUBSTATE_EXIT_ID,block,(unsigned char*) pdata);

	// Calcula o checksum	
	checksumcalc = 0x02 + cmd + sizedata;

	for(i=3;i<sizedata+3;i++)
	{
		checksumcalc = checksumcalc + FsmProtBuffer[i];
	}

	// Coloca o checksum
	FsmProtBuffer[sizedata+3] = checksumcalc;

	// Coloca o ETX
	FsmProtBuffer[sizedata+4] = 0x03;		

	// Transmite o pacote
	TxStart(FsmProtBuffer, 5 + sizedata);

}


void FsmProtCmdReadStatesBlock()
{
	unsigned char *pdata;
	unsigned char checksumcalc;
	unsigned char i;
	unsigned char sizedata;
	unsigned char cmd;

	
	// Formato do pacote STX + CMD + SIZEPACKET + DATAPACKET[n] + CHECKSUM + ETX

	// Preenche o pacote de resposta
	FsmProtBuffer[0] = 0x02;

	// Coloca o comando
	cmd = FSM_PROT_CMD_READ_REPLY_STATES_BLOCK;
	FsmProtBuffer[1] = cmd;
	
	// Coloca o tamanho da �rea de dados do pacote
	sizedata = 50;
	FsmProtBuffer[2] = sizedata;

	// Aponta para a �rea de dados do buffer
	pdata = &FsmProtBuffer[3];

	// Copia o bloco requisitado no pacote de resposta
	DataBankRead(FSM_STATE_SUBSTATE_ID,0,(unsigned char*) pdata);

	// Calcula o checksum	
	checksumcalc = 0x02 + cmd + sizedata;

	for(i=3;i<sizedata+3;i++)
	{
		checksumcalc = checksumcalc + FsmProtBuffer[i];
	}

	// Coloca o checksum
	FsmProtBuffer[sizedata+3] = checksumcalc;

	// Coloca o ETX
	FsmProtBuffer[sizedata+4] = 0x03;		

	// Transmite o pacote
	TxStart(FsmProtBuffer, 5 + sizedata);

}










void FsmProtCmdWriteEntryBlock(unsigned char *pdata)
{
	unsigned char element;
	
	// Recebe o indice do elemento na tabela
	element = *pdata;

	// Passa para a �rea de dados da tabela
	pdata++;
	
	// Grava o registro na tabela
	DataBankWrite(FSM_SUBSTATE_ENTRY_ID,element,pdata);
	
}


void FsmProtCmdWriteRepeatBlock(unsigned char *pdata)
{
	unsigned char element;

	// Recebe o indice do elemento na tabela
	element = *pdata;

	// Passa para a �rea de dados da tabela
	pdata++; 

	// Grava o registro na tabela
	DataBankWrite(FSM_SUBSTATE_REPEAT_ID,element,pdata);
}



void FsmProtCmdWriteExitBlock(unsigned char *pdata)
{
	unsigned char element;

	// Recebe o indice do elemento na tabela
	element = *pdata;

	// Passa para a �rea de dados da tabela
	pdata++; 

	// Grava o registro na tabela
	DataBankWrite(FSM_SUBSTATE_EXIT_ID,element,pdata);
}


void FsmProtCmdWriteStatesBlock(unsigned char *pdata)
{
	unsigned char element;

	// Grava o registro na tabela
	DataBankWrite(FSM_STATE_SUBSTATE_ID,0,pdata);
}