#include "databank.h"
#include "infrared.h"

unsigned char macrocmds[32]; // Mem�ria para uma sequencia de 15 c�digos e 15 esperas, o penultimo
							 // byte � o finalizador 255 e o �ltimo � o c�digo da cena
unsigned char playmacro;

void macroscenesinit()
{
	playmacro = 0;
}

void macroscenesdefaulttable()
{
	unsigned char i;

	// Preenche o valor de cena invalido
	macrocmds[31] = 255;

	for(i=0;i<10;i++)
	{
		// Dispara a grava��o		
		DataBankWrite(MACRO_SCENE_TABLE_ID,i,macrocmds);
	}
}

// Procura pelo c�digo da cena passada na tabela 
void macrosceneplay(unsigned char scene)
{
	unsigned char i;

	for(i=0;i<10;i++)
	{
		DataBankRead(MACRO_SCENE_TABLE_ID,i,macrocmds);
		
		// Verifica o byte que identifica a cena
		if(macrocmds[31] == scene)
		{
			// Indica que a macro deve ser tocada
			playmacro = 1;
			break;
		}
	}
}


// Apaga uma macro de cena da tabela
void macroscenedel(unsigned char scene)
{
	unsigned char i;

	// Procura pela cena que deve ser apagada
	for(i=0;i<10;i++)
	{
		DataBankRead(MACRO_SCENE_TABLE_ID,i,macrocmds);
		
		// Verifica o byte que identifica a cena
		if(macrocmds[31] == scene)
		{
			// Indica que a cena est� desativada
			macrocmds[31] = 255;
			
			DataBankWrite(MACRO_SCENE_TABLE_ID,i,macrocmds);
			
			break;
		}
	}
}


// Salva uma macro/cena na tabela
void macroscenesave(unsigned char *pData)
{
	unsigned char i;
	unsigned char scene;

	// Salva o id na nova cena
	scene = *pData++;

	// Procura pela cena que deve ser apagada
	for(i=0;i<10;i++)
	{
		DataBankRead(MACRO_SCENE_TABLE_ID,i,macrocmds);
		
		// Procura por um slot livre
		if(macrocmds[31] == 255)
		{
			// Indica que a cena est� desativada
			macrocmds[31] = scene;
			
			// Copia os dados da macro/cena
			memcpy(macrocmds,pData,31);
			
			DataBankWrite(MACRO_SCENE_TABLE_ID,i,macrocmds);

			break;
		}
	}
}







void macroscenesprocess()
{
	static unsigned char est = 0;
	static unsigned char macroindex = 0;
	static unsigned long Timer = 0;

	#define MACRO_SCENE_IDLE      0x00
	#define MACRO_SCENE_PLAY_IR   0x01
	#define MACRO_SCENE_WAIT_TIME 0x02
	
	switch(est)
	{
		case MACRO_SCENE_IDLE:
		{
			if(playmacro)
			{
				macroindex = 0;

				est = MACRO_SCENE_PLAY_IR;
			}
			return;
		}

		case MACRO_SCENE_PLAY_IR:
		{
			// Verifica se � o final da sequencia
			if(macrocmds[macroindex] != 255)			
			{
				// Executa o comando IR
				IrLoadandPlay(macrocmds[macroindex++]);

				// Carrega o tempo de execu��o da macro
				Timer = TimerSet(macrocmds[macroindex++]);

				// Espera pelo tempo de execu��o da macro
				est = MACRO_SCENE_WAIT_TIME;
			}
			else
			{
				playmacro = 0;	

				est = MACRO_SCENE_IDLE;
			}

			break;
		}

		case MACRO_SCENE_WAIT_TIME:
		{
			if(TimerVerify(Timer))
			{
				est = MACRO_SCENE_PLAY_IR;
			}			

			break;
		}

		default:
		{
			playmacro = 0;
	
			est = MACRO_SCENE_IDLE;
		}	
	} 
}