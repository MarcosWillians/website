// Autor : Marcos Willians    email : marcosfpga@gmail.com
#include "ticks.h"
#include "FsmIO.h"
#include "FsmVirtualMachine.h"
#include "FsmtaskManager.h"


unsigned char FsmElipseBufferIn[5];
unsigned char FsmElipseBytesReceived;



void FsmElipseInit()
{

}


void FsmElipseRefresh()
{
	// Verifica se existe uma quantidade suficiente de 
	// bytes para representar um comando do Elipse
	// ou o comando de chaveamento para o modo de 
	// programa��o, enviado pela IDE do FSM-PLC 
	if(RxVerifyBytesReceived()>2)
	{
		// Verifica a quantidade de bytes recebidos
		FsmElipseBytesReceived = RxVerifyBytesReceived();

		// Verifica se a quantidade de bytes recebidos cabe no buffer de leitura
		if(FsmElipseBytesReceived == 3)
		{
			// Recebe os bytes dispon�veis
			RxGet(FsmElipseBufferIn);

			switch(FsmElipseBufferIn[0])
			{
				// Verifica se � o comando para colocar o FSM-PLC em modo de programa��o
				case 'P':
				{
					if((FsmElipseBufferIn[1]=='R') && (FsmElipseBufferIn[2]=='G'))
					{
						// Coloca o FSM-PLC em modo de programa��o
						FsmPlcOperationMode = PLC_OPERATION_PROG_MODE;

						// Desliga todas as sa�das
						Outputs[0] = 0;
						Outputs[1] = 0;
						Outputs[2] = 0;
						Outputs[3] = 0;
						Outputs[4] = 0;
						Outputs[5] = 0;
						Outputs[6] = 0;
						Outputs[7] = 0;
						FsmIOProcess();				

					}
					break;
				}

			
				// Recebe o valor de uma mem�ria conforme o indice e atualiza no vetor de mem�rias
				case 'm':
				{
					// Confirma se o indice e o valor est�o dentro dos valores esperados 
					if((FsmElipseBufferIn[1] <= 15) && (FsmElipseBufferIn[2] <= 1))
					{ 
						// Escreve na mem�ria
						Memorys[FsmElipseBufferIn[1]] = FsmElipseBufferIn[2];
					}
				}

				
				// Comandos para o PLC em modo de execu��o
				case 'C': 
				{
					// Verifica qual � o tipo de comando
					switch(FsmElipseBufferIn[1])
					{
						// Transmite o valor atual das entradas digitais conforme o �ndice
						case 'I':
						{
							// Captura o valor da entrada, dado o �ndice
							FsmElipseBufferIn[0] = Inputs[FsmElipseBufferIn[2]];

							// Retorna a resposta
							TxStart(FsmElipseBufferIn, 1);
						break;
						}
						
						// Transmite o valor atual das sa�da digital conforme o �ndice			
						case 'O':
						{
							// Captura o valor da sa�da, dado o �ndice
							FsmElipseBufferIn[0] = Outputs[FsmElipseBufferIn[2]];

							// Retorna a resposta
							TxStart(FsmElipseBufferIn, 1);
						break;
						}

						// Recebe o valor das mem�rias de 8 a 15 e atualiza o vetor de mem�rias				
						case 'g':
						{									
							if(FsmElipseBufferIn[2] & 0x01)
							{
								Memorys[8] = 1;
							}
							else
							{
								Memorys[8] = 0;
							}

							if(FsmElipseBufferIn[2] & 0x02)
							{
								Memorys[9] = 1;
							}
							else
							{
								Memorys[9] = 0;
							}

							if(FsmElipseBufferIn[2] & 0x04)
							{
								Memorys[10] = 1;
							}
							else
							{
								Memorys[10] = 0;
							}

							if(FsmElipseBufferIn[2] & 0x08)
							{
								Memorys[11] = 1;
							}
							else
							{
								Memorys[11] = 0;
							}	

							if(FsmElipseBufferIn[2] & 0x10)
							{
								Memorys[12] = 1;
							}
							else
							{
								Memorys[12] = 0;
							}

							if(FsmElipseBufferIn[2] & 0x20)
							{
								Memorys[13] = 1;
							}
							else
							{
								Memorys[13] = 0;
							}

							if(FsmElipseBufferIn[2] & 0x40)
							{
								Memorys[14] = 1;
							}
							else
							{
								Memorys[14] = 0;
							}

							if(FsmElipseBufferIn[2] & 0x80)
							{
								Memorys[15] = 1;
							}
							else
							{
								Memorys[15] = 0;
							}

						break;		
						}
						
						// Transmite o valor da mem�ria conforme o �ndice
						case 'M':
						{
							// Captura o valor da mem�ria, dado o �ndice
							FsmElipseBufferIn[0] = Memorys[FsmElipseBufferIn[2]];

							// Retorna a resposta
							TxStart(FsmElipseBufferIn, 1);
						break;
						}

						// Transmite o valor do contador conforme o �ndice
						case 'C':
						{
							// Captura o valor do contador, dado o �ndice
							FsmElipseBufferIn[0] = Counters[FsmElipseBufferIn[2]];

							// Retorna a resposta
							TxStart(FsmElipseBufferIn, 1);
						break;
						}

						// Transmite o valor do timer conforme o �ndice
						case 'T':
						{
							// Captura o valor do timer, dado o �ndice
							FsmElipseBufferIn[0] = Timers[FsmElipseBufferIn[2]];

							// Retorna a resposta
							TxStart(FsmElipseBufferIn, 1);
						break;
						}

						// Transmite o valor do estado conforme o �ndice
						case 'S':
						{
							// Captura o valor do estado, dado o �ndice
							FsmElipseBufferIn[0] = States[FsmElipseBufferIn[2]];

							// Retorna a resposta
							TxStart(FsmElipseBufferIn, 1);
						break;
						}
					}
				}	

				default:
				{
					// Erro de rece��o. Limpa o buffer
					RxFlush();
				}	
			}

		}
		else
		{
			// A quantidade de bytes recebidos � grande demais para o buffer de entrada, 
			// descarta o que recebeu pela porta serial
			RxFlush();		
		}
	}

}