#ifndef DISPLAYLED_H
#define DISPLAYLED_H

void diplaygeneralfail();

void leddisplayerror();



#endif