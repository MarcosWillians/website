#ifndef FSM_ELIPSE_H
#define FSM_ELIPSE_H

void FsmElipseInit();

void FsmElipseRefresh();


#endif