#include<p18f452.h>

// Provoca um atraso de 1/38kHz/25 = 658us
void delay_tcarrier_ir()
{
	unsigned char t;

	PORTAbits.RA1 = 0;

	for(t=0;t<200;t++)
	{
	}

	PORTAbits.RA1 =1;

	for(t=0;t<200;t++)
	{
	}
}