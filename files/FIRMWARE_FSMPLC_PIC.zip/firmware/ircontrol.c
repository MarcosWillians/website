#include<p18f452.h>
#include "ticks.h"
#include "ircontrol.h"
#include "cmd.h"
#include "databank.h"



#define IR_BUFFER_SIZE 80
unsigned char irbuffer[IR_BUFFER_SIZE];


unsigned char retrycmd;
unsigned char progmode;
unsigned char resetmachinestationmode;
unsigned char resetmachineapmode;

unsigned char macstring[18];
unsigned char ipstring[16];

// Estados de opera��o
#define IR_EST_STATION_MODE 0x00
#define IR_EST_AP_MODE      0x01
#define IR_EST_RECEIVE      0x02


// Estados das m�quinas de estados de execu��o de comando AT
#define EST_AT_RUNNING 0
#define EST_AT_OK      1
#define EST_AT_ERROR   2

// Porta padr�o quando em modo de programa��o (Access Point)
#define IR_CONTROL_PROGRAM_MODE_PORT_TCP 681




// Estados da m�quina ircontrol
#define IR_EST_STATION_MODE         0x00
#define IR_EST_AP_STATION_MODE      0x01
#define IR_EST_RECEIVE              0x02
#define IR_EST_RETURN_NETWORK_DATA  0x03

unsigned char estircontrolmachine = IR_EST_STATION_MODE;



// Prot�tipos
unsigned char ATVerify();
unsigned char ATCWMODE(unsigned char mode);
unsigned char ATCWJAP(unsigned char* SSID, unsigned char* Password);
unsigned char ATCIPMUX(unsigned char mode);
unsigned char ATCIPSTARTUDP(unsigned int port);
unsigned char ATRST();
unsigned char ATCIPSERVER(unsigned int port);
unsigned char InitProgramMode();
unsigned char InitStationMode();
void ReceivePackets();
unsigned char VerifySwitchProg();
void EnterApMode();
unsigned char IrReturnNetworkData();
void fillirbuffer();
unsigned char SendNetworkData();
unsigned char ATCIFSR();

// Estrutura de dados de configura��o
StConfigNetWorkData ConfigNetWorkData;

// Inicializa��o do m�dulo
void IrControlInit()
{
	// Chave prog
	TRISAbits.TRISA4 = 1;

	// Carrega as configura��es da tabela
	DataBankRead(WIFI_NETWORK_CFG_ID,0,&ConfigNetWorkData); 
	ConfigNetWorkData.UdpPort = 681; // colocado na marra so pra testar, tira essa merda depois

	// Reseta as m�quinas
	resetmachinestationmode = 1;
    resetmachineapmode = 1;

	estircontrolmachine = IR_EST_AP_STATION_MODE;

	// Inicializa o contador de tentativas de envio de comando zerado 
	retrycmd = 0;

}

void fillirbuffer()
{
	unsigned char i;

	for(i=0;i<IR_BUFFER_SIZE;i++)
	{
		irbuffer[i] = '-';
	}
}



// Preenchimento da tabela de configura��s dos dados de rede do modulo
void IrControlTableDefault()
{
	// S� para testes depois usar uma leitura da tabela para resgatar esses dados
	sprintf(ConfigNetWorkData.Name, (const rom far char *) "IrControl\0");
	sprintf(ConfigNetWorkData.SSID, (const rom far char *) "ARBUS\0");
    sprintf(ConfigNetWorkData.Netpassword, (const rom far char *) "marcoswi\0");
    ConfigNetWorkData.UdpPort = IR_CONTROL_PROGRAM_MODE_PORT_TCP;

	DataBankWrite(WIFI_NETWORK_CFG_ID,0,&ConfigNetWorkData);
}

void EnterStationMode()
{
	resetmachinestationmode = 1;
	estircontrolmachine = IR_EST_STATION_MODE;
}

void EnterApMode()
{
	resetmachineapmode = 1;
	estircontrolmachine = IR_EST_AP_STATION_MODE;;
}

void GetMacIpStation()
{
	estircontrolmachine = IR_EST_RETURN_NETWORK_DATA;
}




// M�quina de estados principal de opera��o do
// IRcontrol
void IrControlProcess()
{
	static unsigned char resp;

	switch(estircontrolmachine)
	{
		// Espera por pacotes
		case IR_EST_RECEIVE:
		{
			ReceivePackets();
	
			break;
		}
		
		// Entra no modo de opera��o
		case IR_EST_STATION_MODE:
		{
			if(InitStationMode() == EST_AT_OK)
			{
				estircontrolmachine = IR_EST_RECEIVE;			
			}

			break;
		}

		// Entra no modo de programa��o
		case IR_EST_AP_STATION_MODE:
		{
			if(InitProgramMode() == EST_AT_OK)
			{
				estircontrolmachine = IR_EST_RECEIVE;				
			}
			break;
		}

		// Requisita as informa��es de rede do m�dulo e guarda o endere�o ip e mac do station
		// assim que tem o endere�o ip e mac do station, envia a resposta para o �ltimo ip que se conectou
		case IR_EST_RETURN_NETWORK_DATA:
		{			
			resp = 	IrReturnNetworkData();	
	
			// Se conseguiu enviar os dados sem problema volta a ficar em idle esperando comandos
			// Se ocorrer algum erro, volta tamb�m
			if(resp != EST_AT_RUNNING)
			{
				estircontrolmachine = IR_EST_RECEIVE;				
			}
		
			break;
		}
		
		
		default:
		{
			estircontrolmachine = IR_EST_STATION_MODE;
		}
	}
}


// Maquina de requisi��o de ip e mac ao qual o station est� conectado
// Uma vez requisitado, retorna esses dados ao dispositivo que solititou
unsigned char IrReturnNetworkData()
{
	static unsigned char est = 0;
	unsigned char resp;


	switch(est)
	{
		case 0:
		{			
			// Envia o comando que captura o IP e o MAC
			resp =  ATCIFSR();

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{				
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					est = 0;
					retrycmd = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}

		case 1:
		{
			// Dispara o pacote de dados de IP e MAC para o solicitante
			resp = SendNetworkData();

			// Envia os dados de reposta para o solicitante		
			if(resp == EST_AT_OK)
			{
				est = 0;
				retrycmd = 0;
				return (EST_AT_OK);
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					est = 0;
					retrycmd = 0;
					return (EST_AT_ERROR);
				}
			}

		break;
		}

		default:
		{	
			est = 0;
			retrycmd = 0;
			return (EST_AT_ERROR);
		}
	}

	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}



// AT+CIPSEND=0,8 (envia o comando para enviar dados no id 0 com 8 caracteres, instantes depois o modulo responde com o caractere ">"
// a partir dessa resposta basta transmitir o dado, que no caso do reste foi "marcos+(0x0d)+(0x0a)")

unsigned char SendNetworkData()
{
	static unsigned char est = 0;
	static unsigned long Timer;


	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CIPSEND=0,41\r\n\0");
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 3000ms
			Timer = TimerSet(30);
			
			// Passa para o estado de espera pela resposta
			est++;

		break;
		}

		case 1:
		{
			// Aguarda pela resposta
			if(TimerVerify(Timer))
			{
				// Define a string que ser� comparada para encontrar o caractere que indica que podemos transmitir o pacote
				sprintf(irbuffer, (const rom far char *) ">\0");
				
				// Procura a string de resposta
				if(RxSeekString(irbuffer) != 255)
				{
					// Limpa o buffer pois o tamanho da string final � vari�vel de acordo com o n�meo de d�gitos totais do IP
					// e ser�o transmitidos sempre 41 bytes, que � o tamanho m�ximo esperado 
					fillirbuffer();

					// Transmite o pacote de dados com os dados do mac e ip do station
					sprintf(&irbuffer[2], (const rom far char *) "MAC(%s)IP(%s)\0",macstring,ipstring); 
					
					// Preenche com algum valor para calcular o tamanho certo da string a ser tranmitida
					irbuffer[0] = 1;
					irbuffer[1] = 1;

					// Coloca o tamanho do pacote
					irbuffer[0] = strlen(irbuffer);
					
					// Apaga o \0 do final da string colocando um -
					irbuffer[irbuffer[0]] = '-';

					// Coloca um \0 no final para delimitar o tamenho da string para a trnasmissao
					irbuffer[41] = 0;				

					// Coloca o ID do comando
					irbuffer[1] = CMD_GET_MAC_IP;

					// Dispara a transmiss�o dos dados do buffer
					TxString(irbuffer);
									
					est++;

					// Aguarda transmitir os dados antes de voltar
					Timer = TimerSet(10);
				}
				else
				{
					est = 0;
					retrycmd = 0;
					return (EST_AT_ERROR);
				}
			}
			break;
		}

		case 2:
		{
			// Aguarda pelo tempo de transmiss�o
			if(TimerVerify(Timer))
			{
				est = 0;
				retrycmd = 0;
				return (EST_AT_OK);
			}

			break;
		}

		default:
		{
			est = 0;
			retrycmd = 0;
			return (EST_AT_ERROR);
		}

	}

	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
} 




// Retorna as informa��es de conex�o do m�dulo (IP e MAC) do station e do Ap
unsigned char ATCIFSR()
{
	#define AT_ATCIFSR_MAX_RETRY_CMD 3

	static unsigned char est = 0;
	static unsigned long Timer;
	unsigned char pointerresp;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CIFSR\r\n\0");
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 3000ms
			Timer = TimerSet(4);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda pela resposta
			if(TimerVerify(Timer))
			{
				// Define a string que ser� comparada para encontrar o mac
				sprintf(irbuffer, (const rom far char *) "+CIFSR:STAMAC,\"\0");
				
				// Procura a string de resposta
				pointerresp = RxSeekString(irbuffer);

				// Verifica se a string foi encontrada
				if(pointerresp != 255)
				{	
					// Verifica se os caracteres delimitadores do mac foram encontrados, se sim salva				
					if(RxCopyTo(pointerresp, '"',18,macstring)!=255)	
					{						
						// Define a string que ser� comparada
						sprintf(irbuffer, (const rom far char *) "+CIFSR:STAIP,\"\0");
				
					    // Procura a string de resposta
						pointerresp = RxSeekString(irbuffer);	

						// Verifica se a string foi encontrada
						if(pointerresp != 255)
						{
							// Verifica se os caracteres delimitadores do ip foram encontrados, se sim salva				
							if(RxCopyTo(pointerresp, '"',16,ipstring)!=255)	
							{
								// Ip e mac encontrados, retorna sucesso
								est = 0;
								return(EST_AT_OK);
							}
						}
					}
				}		
							
				retrycmd++;

				est = 0;
		
				if(retrycmd >=AT_ATCIFSR_MAX_RETRY_CMD)
				{
					return(EST_AT_ERROR);
				}
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}

	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);

}







// Verifica se a chave de programa��o foi ativada
unsigned char VerifySwitchProg()
{
	static unsigned char SwitchProgBounce = 0;
	static unsigned long Timer = 0;
	static unsigned char est = 0;
	
	switch(est)
	{
		case 0:
		{
			if(!PORTAbits.RA4)
			{
				Timer = TimerSet(1);
			
				est = 1;

				SwitchProgBounce++;

				// Se a chave prog foi apartada, reinicia o m�dulo ircontrol no modo AP
				if(SwitchProgBounce>4)
				{
					SwitchProgBounce = 0;
			
					// Aguarda o bot�o ser liberado
					est = 2;

					return 1;					
				}
			}
			else
			{
				SwitchProgBounce = 0;
			}
		break;
		}
		
		case 1:
		{
			// Se passou o tempo, volta para testar novamente
			if(TimerVerify(Timer))
			{
				est = 0;
			}
		break;
		}

		case 2:
		{
			// Aguarda o bot�o ser liberado para voltar ao estado inicial
			if(PORTAbits.RA4)
			{	
				est = 0;
			}
			break;
		}

		default:
		{
			est = 0;
		break;
		}
	}

	return 0;
}



// M�quina de recep��o de pacotes
void ReceivePackets()
{
	static unsigned char est = 0;
	static unsigned char sizereceived;
	static unsigned long Timer = 0;


	switch(est)
	{
		case 0:
		{
			// Verifica se existem bytes na serial
			sizereceived = RxVerifyBytesReceived();
			if(sizereceived > 0)
			{
				// Registra um timer para saber se a quantidade de bytes recebidos
				// � est�vel, o que indica o fim da transmiss�o
				Timer = TimerSet(1);
			
				est++;
			}

			break;
		}

		case 1:
		{
			if(TimerVerify(Timer))
			{
				// Se a quantidade de bytes recebidos n�o mudou
				// ent�o �  porque est� est�vel e pode ser processado
				if(RxVerifyBytesReceived()==sizereceived)
				{
					// Procura pelos carateres de indica��o de pacote recebido	

					// Define a string que ser� comparada
					sprintf(irbuffer, (const rom far char *) "IPD\0");
				
					// Verifica se a resposta do comando � correta
					if(RxSeekString (irbuffer)!= 255)
					{
						// Recebe os bytes do pacote armazenando-o em irbuffer
						sizereceived = RxGetPacket(irbuffer);
					
						CmdProcess(irbuffer,sizereceived);

						// Descarta o lixo recebido
						RxFlush();

						// Volta ao estado inicial
						est = 0;

					}	
					else
					{
						// Descarta o lixo recebido
						RxFlush();

						// Volta ao estado inicial
						est = 0;
					}

				}
				else
				{
					// A quantidade de bytes continua aumentando, o que indica que a recep��o est�
					// em curso, volta ao estado inicial at� que a recep��o se estabilize
					est = 0;
				}
			}
		break;
		}

		default:
		{
			est = 0;
		}
	}
}


// Inicializa o m�dulo como station para o funcionamento 
// normal do m�dulo como uma station conectada no AP local
unsigned char InitStationMode()
{
	static unsigned char est = 0;
	unsigned char resp;
	
	if(resetmachinestationmode)
	{
		resetmachinestationmode = 0;
		est = 0;
	}


	switch(est)
	{
		case 0:
		{
			// Envia o comando de reset
			if(ATRST()==EST_AT_OK)
			{
				retrycmd = 0;
				est++;
			}
		break;
		}

		case 1:
		{						
			// Envia o AT de teste para saber se o m�dulo j� est� pronto para receber comandos
			resp = ATVerify();

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}

		case 2:
		{	
			// Envia o comando para programar o m�dulo como Station
			resp = ATCWMODE(1);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}


	  	case 3:
		{		
			// Conecta-se com o Access Point pr�ximo
			resp = ATCWJAP(ConfigNetWorkData.SSID, ConfigNetWorkData.Netpassword);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{	
				retrycmd = 0;				
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}	

		
		case 4:
		{			
			// Indica que podemos ter multipla conex�es
			resp = ATCIPMUX(1);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				retrycmd = 0;
				
				// Fim da sequencia de comandos 
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}

		case 5:
		{
			
			// Abre o server TCP para a recep��o dos comandos dos tablets e do APE10E
			resp = ATCIPSERVER(ConfigNetWorkData.UdpPort);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				// Fim da sequencia de comandos 
				retrycmd = 0;
				est = 0;
				return (EST_AT_OK);
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}

	}


	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);

}

// Inicializa o m�dulo como Access Point 
// para que possa ser programado
unsigned char InitProgramMode()
{
	static unsigned char est = 0;
	unsigned char resp;
	
	if(resetmachineapmode)
	{
		resetmachineapmode = 0;
		est = 0;
	}


	switch(est)
	{
		case 0:
		{
			// Envia o comando de reset
			if(ATRST()==EST_AT_OK)
			{
				retrycmd = 0;
				est++;
			}
		break;
		}
		
		case 1:
		{				
			// Envia o AT de teste para saber se o m�dulo j� est� pronto para receber comandos
			resp = ATVerify();

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}

		case 2:
		{			
			// Envia o comando para programar o m�dulo como Access Point e Station ao mesmo tempo
			resp = ATCWMODE(3);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				est++;
				retrycmd = 0;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}
		
		case 3:
		{
			// Configura o acesso multiplo, essencial para o modo TCP funcionar
			resp = ATCIPMUX(1);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				retrycmd = 0;

				// Fim da sequencia de comandos 
				est++;
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}
			
		case 4:
		{	
			// Abre o server TCP do Access Point na porta padr�o do modo de programa��o
			resp = ATCIPSERVER(IR_CONTROL_PROGRAM_MODE_PORT_TCP);

			// Verifica a resposta da execu��o do comando
			if(resp == EST_AT_OK)
			{
				// Fim da sequencia de comandos 
				retrycmd = 0;
				est = 0;
				return (EST_AT_OK);
			}
			else
			{
				// Se houve erro repassa acima
				if(resp == EST_AT_ERROR)
				{
					retrycmd = 0;
					est = 0;
					return (EST_AT_ERROR);
				}
			}
		break;
		}
				
		default:
		{
			retrycmd = 0;
			est = 0;
			return (EST_AT_ERROR);
		}

	}

	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}





// M�quina de estados auxiliar que
// retorna EST_AT_OK se o comando 
// AT for recebido corretamente
// retorna EST_AT_RUNNING se o comando ainda est� em execu��o
// e retorna EST_AT_ERROR em caso de falha do comando
unsigned char ATVerify() 
{
	#define AT_OK_MAX_RETRY_CMD 50

	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT\r\n\0");
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 300ms
			Timer = TimerSet(10);
		
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda 300ms pela resposta
			if(TimerVerify(Timer))
			{
				// Define a string que ser� comparada
				sprintf(irbuffer, (const rom far char *) "OK\0");
				
				// Verifica se a resposta do comando � correta
				if(RxSeekString (irbuffer)!= 255)
				{
					est = 0;
					return(EST_AT_OK);
				}		
				
				retrycmd++;

				if(retrycmd >=AT_OK_MAX_RETRY_CMD)
				{
					est = 0;
					return(EST_AT_ERROR);
				}		

				est = 0;
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}

	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}


// Define o modo de opera��o do m�dulo 
// 1 - Modo Station
// 2 - Modo AP
// 3 - Modo AP e Station
unsigned char ATCWMODE(unsigned char mode) 
{
	#define AT_ATCWMODE_MAX_RETRY_CMD 5

	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CWMODE=%d\r\n\0",mode);
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 3000ms
			Timer = TimerSet(30);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda 3s pela resposta
			if(TimerVerify(Timer))
			{			
				// Define a string que ser� comparada
				sprintf(irbuffer, (const rom far char *) "OK\0");
				
				// Verifica se a resposta do comando � correta
				if(RxSeekString (irbuffer)!= 255)
				{
					est = 0;
					return(EST_AT_OK);
				}		
							
				retrycmd++;

				if(retrycmd >=AT_ATCWMODE_MAX_RETRY_CMD)
				{
					est = 0;
					return(EST_AT_ERROR);
				}		

				est = 0;
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}

	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}




// Se autentica junto a uma rede local passando o SSID e  password 
// ex: AT+CWJAP="ARBUS","marcoswi" 
unsigned char ATCWJAP(unsigned char* SSID, unsigned char* Password) 
{
	#define AT_ATCWJAP_MAX_RETRY_CMD 5

	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CWJAP=\"%s\",\"%s\"\r\n\0",SSID,Password);
			
			// Transmite 		
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 20s
			Timer = TimerSet(200);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda 3s pela resposta
			if(TimerVerify(Timer))
			{			
				// Define a string que ser� comparada
				sprintf(irbuffer, (const rom far char *) "WIFI CONNECTED\0");
				
				// Verifica se a resposta do comando � correta
				if(RxSeekString (irbuffer)!= 255)
				{
					est = 0;
					return(EST_AT_OK);
				}		
							
				retrycmd++;

				if(retrycmd >=AT_ATCWJAP_MAX_RETRY_CMD)
				{
					est = 0;
					return(EST_AT_ERROR);
				}		

				est = 0;
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}

	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}




// Entra no modo multiplex, quando recebe multiplas conex�es
// essesncial para o modo TCP funcionar 
// ex: AT+CIPMUX=1 liga o modo multiplex
unsigned char ATCIPMUX(unsigned char mode) 
{
	#define AT_ATCIPMUX_MAX_RETRY_CMD 5

	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CIPMUX=%d\r\n\0",mode);
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 3000ms
			Timer = TimerSet(30);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda 3s pela resposta
			if(TimerVerify(Timer))
			{			
				// Define a string que ser� comparada
				sprintf(irbuffer, (const rom far char *) "OK\0");
				
				// Verifica se a resposta do comando � correta
				if(RxSeekString (irbuffer)!= 255)
				{
					est = 0;
					return(EST_AT_OK);
				}		
							
				retrycmd++;

				if(retrycmd >=AT_ATCIPMUX_MAX_RETRY_CMD)
				{
					est = 0;
					return(EST_AT_ERROR);
				}		

				est = 0;
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}	
	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}









#if 0

// Conecta em modo UDP abrindo a porta 
unsigned char ATCIPSTARTUDP(unsigned int port) 
{
	#define AT_ATCIPSTARTUDP_MAX_RETRY_CMD 5

	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CIPSTART=\"UDP\",\"0\",0,%d,2\r\n\0",port);
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 5s
			Timer = TimerSet(50);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda pela resposta
			if(TimerVerify(Timer))
			{			
				// Define a string que ser� comparada
				sprintf(irbuffer, (const rom far char *) "OK\0");
				
				// Verifica se a resposta do comando � correta
				if(RxSeekString (irbuffer)!= 255)
				{
					est = 0;
					return(EST_AT_OK);
				}		
							
				retrycmd++;

				if(retrycmd >=AT_ATCIPSTARTUDP_MAX_RETRY_CMD)
				{
					est = 0;
					return(EST_AT_ERROR);
				}		

				est = 0;
			}		
		break;
		}
	
		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}

	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}

#endif









// Reseta o m�dulo 
unsigned char ATRST() 
{
	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+RST\r\n\0");
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 5s
			Timer = TimerSet(50);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda 5s pelo tempo de boot e retorna
			if(TimerVerify(Timer))
			{	
				est = 0;
				return(EST_AT_OK);
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}
	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}





// Cria um servidor na porta passada
// ex: AT+CIPSERVER=1,9780 (abre o server TCP na porta 9780)
unsigned char ATCIPSERVER(unsigned int port) 
{
	#define AT_ATCIPSERVER_MAX_RETRY_CMD 5

	static unsigned char est = 0;
	static unsigned long Timer;
	
	switch(est)
	{
		case 0:
		{
			// Limpa qualquer lixo que houver na serial
			RxFlush();

			// Transmite o comando AT pela serial
			sprintf(irbuffer, (const rom far char *) "AT+CIPSERVER=1,%d\r\n\0",port);
			TxString(irbuffer);

			// Registra um timer para receber a resposta do comando, no caso 5s
			Timer = TimerSet(50);
			
			// Passa para o estado de espera pela resposta
			est++;
		break;
		}
		
		case 1:
		{
			// Aguarda pela resposta
			if(TimerVerify(Timer))
			{			
				// Define a string que ser� comparada
				sprintf(irbuffer, (const rom far char *) "OK\0");
				
				// Verifica se a resposta do comando � correta
				if(RxSeekString (irbuffer)!= 255)
				{
					est = 0;
					return(EST_AT_OK);
				}		
							
				retrycmd++;

				if(retrycmd >=AT_ATCIPSERVER_MAX_RETRY_CMD)
				{
					est = 0;
					return(EST_AT_ERROR);
				}		

				est = 0;
			}		
		break;
		}

		default:
		{
			est = 0;
			return (EST_AT_ERROR);
		}

	}
	
	// Indica que o comando ainda est� em execu��o
	return (EST_AT_RUNNING);
}
