// Autor : Marcos Willians    email : marcosfpga@gmail.com

#include<p18f452.h>
#include "main.h"
#include "FsmVirtualMachine.h"
#include "FsmTaskManager.h"
#include "FsmElipse.h"

// Prot�tipos
void high_isr(void);


#define BUFFER_RX_SERIAL 70
#define BUFFER_TX_SERIAL 70

// Buffers da seial
unsigned char BufferRx[BUFFER_RX_SERIAL];
unsigned char BufferTx[BUFFER_TX_SERIAL];

unsigned char UARTReceivedBytes;

unsigned char UARTBytes2Transmit;

unsigned char UARTBytesTxIndex;

unsigned char ticktimer;




unsigned char auxrx;
unsigned char receivedbytes;

unsigned char ledtimer = 0;
unsigned char ledtog = 0;

// Vetor de alta prioridade 
#pragma code high_vector=0x08
void interrupt_at_high_vector(void)
{
  _asm GOTO high_isr _endasm
}

#pragma code

// Interrup��o de alta prioridade
#pragma interrupt high_isr
void high_isr (void)
{
	// Interrup��o de tempo, incrementos a cada 100ms
	if(INTCONbits.TMR0IF)
	{    
		INTCONbits.TMR0IF = 0;                 
		TMR0H = 0xF0;        
		TMR0L = 0xBC;                    
 		
		ticktimer++;

	
		if(TimerEnable[0] == 1)
		{
			Timers[0]++;
		}

		if(TimerEnable[1] == 1)
		{
			Timers[1]++;
		}

		if(TimerEnable[2] == 1)
		{
			Timers[2]++;
		}

		if(TimerEnable[3] == 1)
		{
			Timers[3]++;
		}

		if(TimerEnable[4] == 1)
		{
			Timers[4]++;
		}

		if(TimerEnable[5] == 1)
		{
			Timers[5]++;
		}

		if(TimerEnable[6] == 1)
		{
			Timers[6]++;
		}

		if(TimerEnable[7] == 1)
		{
			Timers[7]++;
		}


		if(ticktimer == 10)
		{
			ticktimer=0;

			if(TimerEnable[8] == 1)
			{
				Timers[8]++;
			}
	
			if(TimerEnable[9] == 1)
			{
				Timers[9]++;
			}
	
			if(TimerEnable[10] == 1)
			{
				Timers[10]++;
			}
	
			if(TimerEnable[11] == 1)
			{
				Timers[11]++;
			}
	
			if(TimerEnable[12] == 1)
			{
				Timers[12]++;
			}
	
			if(TimerEnable[13] == 1)
			{
				Timers[13]++;
			}
	
			if(TimerEnable[14] == 1)
			{
				Timers[14]++;
			}
	
			if(TimerEnable[15] == 1)
			{
				Timers[15]++;
			}	
		}
		
		if(ledtimer++ == 4)
		{
			ledtimer = 0;
		
			if(PORTBbits.RB5)
			{				
				// Detecta a transi��o da chave de entrada 
				if(oldreadswich == 1)
				{
					FsmPlcOperationMode = PLC_OPERATION_PROG_MODE;
					
					// Desliga todas as sa�das
					Outputs[0] = 0;
					Outputs[1] = 0;
					Outputs[2] = 0;
					Outputs[3] = 0;
					Outputs[4] = 0;
					Outputs[5] = 0;
					Outputs[6] = 0;
					Outputs[7] = 0;
					FsmIOProcess();
				}
			
				oldreadswich = 0;	
			
			}
			else
			{
				if(oldreadswich == 0)
				{
					FsmPlcOperationMode = PLC_OPERATION_RUN_MODE;
				}
			
				oldreadswich = 1;
							
			}

			if(FsmPlcOperationMode == PLC_OPERATION_RUN_MODE)
			{
				if(ledtog)
				{
					// Desliga o led		
					ledtog = 0;
					PORTEbits.RE0 = 0;
				}
				else
				{
					// Liga o led
					ledtog = 1;
					PORTEbits.RE0 = 1;
				}
			}
			else
			{
				// Modo de programa��o, mantem o led aceso
				PORTEbits.RE0 = 1;
			}
		}
		
    }

	// Verifica se houve a chegada de um byte pela serial
	if(PIR1bits.RCIF)
	{
		// Apaga a flag de indica��o de chegada do byte 
		PIR1bits.RCIF = 0;

		// Verifica se h� espa�o no buffer para salvar o byte recebido
		if(UARTReceivedBytes < BUFFER_RX_SERIAL)
		{
			// Recebe o byte do buffer de rx
			BufferRx[UARTReceivedBytes++] = RCREG;
		}
		else
		{
			// Descarta o byte recebido pela leitura de RCREG
			auxrx = RCREG;
		} 		
	}

	// Verifica se houve uma transmiss�o de um byte pela serial
	if(PIR1bits.TXIF)
	{
		// Apaga a flag de indica��o de transmiss�o do byte
		PIR1bits.TXIF = 0;

		// Verifica se existem dados a serem transmitidos
		if(UARTBytes2Transmit--)
		{
			// Coloca o pr�ximo byte no buffer da UART
			TXREG = BufferTx[UARTBytesTxIndex++];
		}
		else
		{
			// Reseta o indicador de bytes a transmitir
			// Para que uma nova string possa ser colocada na fila
			UARTBytes2Transmit = 0;

			// Desliga o transmissor  
			TXSTAbits.TXEN = 0;
		}
	}
}

// Inicia a transmiss�o pela serial
void TxStart(unsigned char* Data, unsigned char size)
{
	// Copia os dados para o buffer
	memcpy(&BufferTx[0],Data,(int)size);
	
	// Inicializa as vari�veis para a trnsmiss�o
	UARTBytes2Transmit = size;
	UARTBytesTxIndex = 0;

	// Apaga a flag de indica��o de transmissao
	PIR1bits.TXIF = 0;

	// Coloca o primeiro byte no buffer do tx da UART
	TXREG = BufferTx[UARTBytesTxIndex++];
	
	// Habilita o transmissor  
	TXSTAbits.TXEN = 1;
}

// Retorna se os bytes requisitados j� foram transmitidos se 1 j� foram
unsigned char TxBufferEmptyVerify()
{	
	if(UARTBytes2Transmit)
	{
		return(0);
	}
	else
	{	
		return(1);
	}
}


// Retorna a quantidade de bytes j� recebidos
unsigned char RxVerifyBytesReceived()
{
	return(UARTReceivedBytes);
}



// Descarrega qualquer lixo da UART
void RxFlush()
{
	// Limpa o buffer da uart
	auxrx = RCREG;
 	auxrx = RCREG;
 	auxrx = RCREG;	
  
	// Limpa qualquer erro detectado	
  	RCSTAbits.CREN = 0;
	RCSTAbits.CREN = 1;

	UARTReceivedBytes = 0;
}


// Recebe os dados do buffer de recep��o da serial, retorna a quintidade de bytes lidos
unsigned char RxGet(unsigned char* Data)
{
	if(UARTReceivedBytes)
	{
		// Copia os dados do buffer
		memcpy(Data,&BufferRx[0],(int)UARTReceivedBytes);

		receivedbytes = UARTReceivedBytes;

		// Limpa os buffers e indica que n�o temos bytes para ler
		UARTReceivedBytes = 0;
		
		// Descarrega qualquer lixo da UART
		RxFlush();

		return(receivedbytes);
	}
	else
	{
		return(0);
	}
}





void UARTInterruptOFF()
{
  // Desliga a interrup��o de TX
  PIE1bits.TXIE = 0;

  // Desliga a interrup��o de RX
  PIE1bits.RCIE = 0;

  // Desliga o receptor da UART para evitar receber lixo	
  RCSTAbits.CREN = 0;
}

void UARTInterruptON()
{
  // Liga a interrup��o de TX	
  PIE1bits.TXIE = 1;
  
  // Liga a interrup��o de RX
  PIE1bits.RCIE = 1;

  // Liga o receptor da UART	
  RCSTAbits.CREN = 1;	
}


// Desliga a interrup��o de tempo para que 
// opera��es cr�ticas possam ser executadas 
// sem interfer�ncias
void TimerInterruptOFF()
{
	// Desliga o timer
	T0CONbits.TMR0ON = 0;

	// Desabilita a interrup��o do timer 0
	INTCONbits.TMR0IE = 0;
}

// Liga a gera��o de interrup��es por tempo
void TimerInterruptON()
{
	// Liga o timer	
	T0CONbits.TMR0ON = 1;

	// Habilita a interrup��o do timer 0
	INTCONbits.TMR0IE = 1;
}


// Inicializa o timer
void TimerInit()
{
	int i;

	// Inicializa os timers virtuais do FSM-PLC
	for(i=0;i<16;i++)
	{
		Timers[i] = 0;
		TimerEnable[i] = 0;	
	}

	// Inicializa o tick do timer
	ticktimer = 0;

	// Inicializa o timer 
	T0CON = 0;

	// Prescaler div 256
	T0CONbits.T0PS0 = 1;
	T0CONbits.T0PS1 = 1;
	T0CONbits.T0PS2 = 1;


	// Habilta todas as interrup��es de alta prioridade n�o mascaradas 
	RCONbits.IPEN = 1; 

	// Inicializa a mascara de interrup��es
	INTCON = 0;
	
	// Habilita as interrup��es de alta prioridade
	INTCONbits.GIEH = 1;

	// Habilita a interrup��o do timer 0
	INTCONbits.TMR0IE = 1;

	// Atualiza o timer 0
	TMR0H = 0xF0;        
	TMR0L = 0xBC;	

	// Liga o timer	
	T0CONbits.TMR0ON = 1;


}



void UARTInit()
{
	int i;

	// Configura a porta de saida
	TRISCbits.TRISC6 = 0;

	// Configura a porta de entrada
	TRISCbits.TRISC7 = 1;

	// Mant�m a porta de saida em 1 pois qdo o transmissor for desligado a linha precisa continuar em 1
	PORTCbits.RC6 = 1;

	// Inicializa o registrador de controle do transmissor da UART 
	TXSTA = 0;

	// Seleciona o modo de transmiss�o em "alta" velocidade
	TXSTAbits.BRGH = 1;

	// Inicializa SPBRG para o baudrate de 19200
	SPBRG = 129; 

	// Inicializa o registrador de controle do receptor da UART
	RCSTA = 0;


	// Habilita a porta serial, conectando o RX e TX nos respectivos pinos
	RCSTAbits.SPEN = 1;

	// Liga o receptor da UART
	RCSTAbits.CREN = 1;

	// Liga as interrup��es da UART
	UARTInterruptON();

    // Indica que n�o temos bytes recebidos
	UARTReceivedBytes = 0;

	// Inicializa o buffer de RX mas pode tirar isso depois TESTE
	for(i=0;i<BUFFER_RX_SERIAL;i++)
	{
		BufferRx[i]=0;
	}

	// Inicializa o buffer de TX mas pode tirar isso depois TESTE
	for(i=0;i<BUFFER_TX_SERIAL;i++)
	{
		BufferTx[i]=0;
	}	



	RxFlush();

}



