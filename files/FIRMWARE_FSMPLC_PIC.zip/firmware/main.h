#ifndef MAIN_H
#define MAIN_H

void ClearWatchdog();
void ResetPLC();


#endif