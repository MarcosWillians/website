// Autor : Marcos Willians    email : marcosfpga@gmail.com
#include<p18f452.h>
#include "databank.h"
#include "FsmIO.h"

// Subestados FSM
#define EST_SUBSTATE_INATIVE 0
#define EST_SUBSTATE_ENTRY   1
#define EST_SUBSTATE_REPEAT  2
#define EST_SUBSTATE_EXIT    3


// Instru��es de atribui��o da m�quina virtual FSM
#define INST_COUNTER_ATTRIB      0x00      // Atribui��o de valor para um contador
#define INST_MEMORY_ATTRIB       0x01      // Atribui��o de valor para uma mem�ria
#define INST_OUTPUT_ATTRIB       0x02      // Atribui��o de valor para uma sa�da
#define INST_TIMER_ENABLE_ATTRIB 0x03      // Atribui��o de valor para uma habilita��o de timer
#define INST_COUNTER_ATTRIB_INC  0x04      // Incrementa um contador 
#define INST_COUNTER_ATTRIB_DEC  0x05      // Decrementa um contador

// Instru��es de verifica��o de condicionais da m�quina virtual FSM
#define INST_IF_INPUT_EQUAL      0x06      // Instru��o de verifica��o se a entrada � igual ao valor de referencia
#define INST_IF_INPUT_DIFF       0x07      // Instru��o de verifica��o se a entrada � diferente do valor de referencia
#define INST_IF_OUTPUT_EQUAL     0x08      // Instru��o de verifica��o se a saida � igual ao valor de referencia
#define INST_IF_OUTPUT_DIFF      0x09      // Instru��o de verifica��o se a saida � diferente do valor de referencia
#define INST_IF_MEMORY_EQUAL     0x0A      // Instru��o de verifica��o se a memoria � igual ao valor de referencia
#define INST_IF_MEMORY_DIFF      0x0B      // Instru��o de verifica��o se a memoria � diferente do valor de referencia
#define INST_IF_COUNTER_EQUAL    0x0C      // Instru��o de verifica��o se o contador � igual ao valor de referencia
#define INST_IF_COUNTER_DIFF     0x0D      // Instru��o de verifica��o se o contador � diferente do valor de referencia
#define INST_IF_COUNTER_MAJOR    0x0E      // Instru��o de verifica��o se o contador � maior que o de referencia
#define INST_IF_COUNTER_MINOR    0x0F      // Instru��o de verifica��o se o contador � menor que o valor de referencia
#define INST_IF_TIMER_EQUAL      0x10      // Instru��o de verifica��o se o timer � igual ao valor de referencia
#define INST_IF_TIMER_DIFF       0x11      // Instru��o de verifica��o se o timer � diferente do valor de referencia
#define INST_IF_TIMER_MAJOR      0x12      // Instru��o de verifica��o se o timer � maior que o de referencia
#define INST_IF_TIMER_MINOR      0x13      // Instru��o de verifica��o se o timer � menor que o valor de referencia

// Instru��es de controle de condicionais e de sa�da do estado
#define INST_IF_START            0x14     // Instru��o de inicio de um IF
#define INST_UNION_AND           0x15     // Instru��o de uni�o AND l�gico
#define INST_UNION_OR            0x16     // Instru��o de uni�o OR l�gico
#define INST_GOTO                0x17     // Instru��o ir para o estado
#define INST_EXIT                0xFF     // Instru��o de indica��o de fim do bloco de c�digos do estado




// Dados do subestado carregado a serem processados pela m�quina virtual FSM
unsigned char Program[60];

// Sa�das do FSM-PLC
unsigned char Outputs[6];

// Entradas do FSM-PLC
unsigned char Inputs[6];

// Timers do FSM-PLC            
unsigned char Timers[16];

// Timer Enable do FSM-PLC
unsigned char TimerEnable[16];

// Contadores do FSM-PLC;
unsigned char Counters[16];

// Mem�rias do FSM-PLC
unsigned char Memorys[16];

// Status dos estados do FSM-PLC
unsigned char States[50];


// Prot�tipos
unsigned char FsmVirtualMachineStateProcess();

// Inicializa��o da m�quina virtual FSM
void FsmVirtualMachineInit()
{
	unsigned char i;

	// Carrega a lista de estados que devem ser inicializados ao ligar o FSM-PLC
	DataBankRead(FSM_STATE_SUBSTATE_ID,0,(unsigned char*) States);

	// Inicializa a vari�vel de sa�da, inicialmente desligada
	for(i=0;i<6;i++)
	{
		Outputs[i] = 0;		
	}

	// Inicializa as outras vari�veis de estadod o FSM-PLC
	for(i=0;i<16;i++)
	{	
		Counters[i] = 0;
		Memorys[i] = 0;
	}


	#if 0

	/// EST 0
	for(i=0;i<60;i++)
	{	
		Program[i]= 255;
	}
	
	Program[0] = 2;
	Program[1] = 1;
	Program[2] = 0;

	DataBankWrite(FSM_SUBSTATE_ENTRY_ID,0,(unsigned char*) Program);
	
	for(i=0;i<60;i++)
	{	
		Program[i]= 255;
	}

	Program[0] = 20;
	Program[1] = 5;
	Program[2] = 6;
	Program[3] = 1;
	Program[4] = 1;
	Program[5] = 23;
	Program[6] = 1;

	DataBankWrite(FSM_SUBSTATE_REPEAT_ID,0,(unsigned char*) Program);
	
	for(i=0;i<60;i++)
	{	
		Program[i]= 255;
	}

	DataBankWrite(FSM_SUBSTATE_EXIT_ID,0,(unsigned char*) Program);
	
	//FIM EST0

	/// EST 1
	for(i=0;i<60;i++)
	{	
		Program[i]= 255;
	}
	
	Program[0] = 2;
	Program[1] = 1;
	Program[2] = 1;

	DataBankWrite(FSM_SUBSTATE_ENTRY_ID,1,(unsigned char*) Program);
	
	for(i=0;i<60;i++)
	{	
		Program[i]= 255;
	}

	Program[0] = 20;
	Program[1] = 5;
	Program[2] = 6;
	Program[3] = 2;
	Program[4] = 1;
	Program[5] = 23;
	Program[6] = 0;

	DataBankWrite(FSM_SUBSTATE_REPEAT_ID,1,(unsigned char*) Program);
	
	for(i=0;i<60;i++)
	{	
		Program[i]= 255;
	}

	DataBankWrite(FSM_SUBSTATE_EXIT_ID,1,(unsigned char*) Program);
	
	//FIM EST1

	// Estados ativos

		// Inicializa a vari�vel de sa�da, inicialmente desligada
		for(i=0;i<50;i++)
		{
			States[i] = 0;		
		}
		
		States[0] = EST_SUBSTATE_ENTRY;

		DataBankWrite(FSM_STATE_SUBSTATE_ID,0,(unsigned char*) States);

	// fim estados ativos



	#endif


}

void FsmDefaultDataBank()
{
	unsigned char i;

	// Inicializa a vari�vel de sa�da, inicialmente desligada
	for(i=0;i<50;i++)
	{
		States[i] = 0;		
	}
	
	DataBankWrite(FSM_STATE_SUBSTATE_ID,0,(unsigned char*) States);

}


// Tarefa de execu��o da m�quina virtual
void FsmVirtualMachineRefresh()
{
	 static unsigned char activestateindex = 0;
     static unsigned char statechange = 255;
     static unsigned char  ProcessStateCompleted;
      

	 while((States[activestateindex] == EST_SUBSTATE_INATIVE))
	 {
		 // Passa para o pr�ximo estado	
		 activestateindex++;
		 
		 // Verifica se o ciclo de scan terminou
		 if(activestateindex == 50)
		 {
			activestateindex = 0;
	
			// Atualiza as sa�das e amostra as entradas
			FsmIOProcess();
		 }	
	 }	


	 // Verifica se o estado est� ativo
     if(States[activestateindex] != EST_SUBSTATE_INATIVE)
     {
     	// Permanece processando
        ProcessStateCompleted = 0;
        while (!ProcessStateCompleted)
        {
        	switch (States[activestateindex])
            {
            	// Processamento do subestado Entry
                case EST_SUBSTATE_ENTRY:
                {
                    // Carrega o bloco entry
					DataBankReadOptimized(FSM_SUBSTATE_ENTRY_ID,activestateindex,(unsigned char*) Program);

					// Dispara o processamento do bloco 		
					FsmVirtualMachineStateProcess();	

                    // Atualiza o subestado para processar o Repeat no pr�ximo ciclo
                    States[activestateindex] = EST_SUBSTATE_REPEAT;

                    // Indica que o estado atual foi processado
                    ProcessStateCompleted = 1;

					// Passa para o pr�ximo estado	
		 			activestateindex++;

                    break;
                }

                // Processamento do subestado Repeat
                case EST_SUBSTATE_REPEAT:
                {         
				
				//	PORTEbits.RE0 = 1;
                              
                  	// Carrega o bloco repeat
					DataBankReadOptimized(FSM_SUBSTATE_REPEAT_ID,activestateindex,(unsigned char*) Program);


				//	PORTEbits.RE0 = 0;


					// Dispara o processamento do bloco 		
					statechange = FsmVirtualMachineStateProcess();

                    // Verifica se ocorreu um evento de mudan�a de estado
                    if (statechange != 255)
                    {
                    	// Marca o estado que se tornar� ativo no pr�ximo ciclo  
                        States[statechange] = EST_SUBSTATE_ENTRY;

                        // Marca o estado atual que ser� finalizado
                        States[activestateindex] = EST_SUBSTATE_EXIT;
                    }
                    else
                    {
                    	// Caso n�o tenha ocorrido um evento de mudan�a de estado, finaliza o processamento do estado atual
                        ProcessStateCompleted = 1;

						// Passa para o pr�ximo estado	
		 				activestateindex++;
                    }
                           
                break;
                }

                // Processamento do subestado Exit 
                case EST_SUBSTATE_EXIT:
                {                                       
                	// Carrega o bloco exit
					DataBankReadOptimized(FSM_SUBSTATE_EXIT_ID,activestateindex,(unsigned char*) Program);

					// Dispara o processamento do bloco 		
					FsmVirtualMachineStateProcess();

                    // Indica que o estado atual est� finalizado
                    States[activestateindex] = EST_SUBSTATE_INATIVE;

                    // Finaliza o processamento do estado                                       
                    ProcessStateCompleted = 1;

					 // Passa para o pr�ximo estado	
		 			activestateindex++;
                                       
                    break;
                }
           }                          
        }  
     }

	 #if 0
	 // Passa para o pr�ximo estado	
	 activestateindex++;
	 
	 // Verifica se o ciclo de scan terminou
	 if(activestateindex == 50)
	 {
		activestateindex = 0;

		// Atualiza as sa�das e amostra as entradas
		FsmIOProcess();
	 }	
	#endif
}



// Processamento dos estados da m�quina virtual
unsigned char FsmVirtualMachineStateProcess()
{
	static unsigned char i;
                           
    static unsigned char ifjumpto = 0;

    static unsigned char indexvar;

    static unsigned char comparevalue;

    static unsigned char testresult;

    static unsigned char testresultold;

    static unsigned char fistcompare;

    static unsigned char AndChoice;

    static unsigned char OrChoice;

	// Inicializa o ponteiro da �rea de mem�ria de programa
    i = 0;
	
    // Indica que o resultado l�gico de um teste � false, visto que nenhum ainda foi feito
    testresult = 0;

    // Indica que o resultado l�gico de um teste antigo � false, visto que nenhum ainda foi feito
    testresultold = 0;

    // Como nenhuma compara��o ainda foi feita, indica que � a primeira compara��o
    fistcompare = 1;

    // Indica que os operadores de uni�o ainda n�o foram escolhidos 
    AndChoice = 0;
    OrChoice = 0;

	while(1)
	{		
		// Processa a instru��o	
		switch(Program[i])
		{

 			// Instru��o de indica��o de fim do bloco de c�digos do estado
            case INST_EXIT:
            {
            	// Fim do c�digo, retorna
                return 255;
            }

     	    // Instru��o de inicio de um IF 
            case INST_IF_START:
            {
         		// Passa para a �rea de dados
            	i++;

            	// Armazena a posi��o para a qual o ponteiro de programa de 
                // pular se ocorrer uma sensibiliza��o pr�via da express�o
                // testada pelo 'if'
                ifjumpto = Program[i];

                // Passa para a pr�xima instru��o
                i++;

                // Indica que o resultado l�gico de um teste � false, visto que nenhum ainda foi feito
                testresult = 0;

                // Indica que o resultado l�gico de um teste antigo � false, visto que nenhum ainda foi feito
                testresultold = 0;

                // Como nenhuma compara��o ainda foi feita, indica que � a primeira compara��o
                fistcompare = 1;

                // Indica que os operadores de uni�o ainda n�o foram escolhidos 
                AndChoice = 0;
                OrChoice = 0;

                break;
           }

           // Instru��o de uni�o AND l�gico
           case INST_UNION_AND:
           {
           		// Indica que a pr�xima instru��o dever� calcular um AND
                AndChoice = 1;

                // Passa para a pr�xima instru��o
                i++;

                break;
           }

           // Instru��o de uni�o OR l�gico
           case INST_UNION_OR:
           {
           		// Indica que a pr�xima instru��o dever� calcular um OR
                OrChoice = 1;

                // Se o resultado da opera��o l�gica anterior foi 1, ent�o j� desloca o ponteiro para 
                // a instru��o goto
                if (testresultold)
                {
                	// Desloca o ponteiro do programa para a instru��o goto desse if
                    i = ifjumpto;
                }
                else
                {
                	// Passa para a pr�xima instru��o
                	i++;
                }

                break;
           }

           // Instru��o ir para o estado
           case INST_GOTO:
           {
           		// Verifica se haver� uma mudan�a de estado
                if (testresultold)
                {
                	// Passa para a �rea de dados
                    i++;

                    // Retorna o estado ao qual dever� ser ativado
                    return (Program[i]);
                }

                // Passa para a proxima instrucao
                i = i + 2;

                break;
           }

           // Atribui��o de valor para um contador
           case INST_COUNTER_ATTRIB:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de dados
                i++;

                // Faz a atribui��o  
                Counters[indexvar] = Program[i];

                // Passa para a pr�xima instru��o
                i++;
                break;
           }

           // Atribui��o de valor para uma mem�ria
           case INST_MEMORY_ATTRIB:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de dados
                i++;

                // Faz a atribui��o  
                Memorys[indexvar] = Program[i];

                // Passa para a pr�xima instru��o
                i++;

                break;
           }

           // Atribui��o de valor para uma sa�da
           case INST_OUTPUT_ATTRIB:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de dados
                i++;

                // Faz a atribui��o  
                Outputs[indexvar] = Program[i];

                // Passa para a pr�xima instru��o
                i++;

                break;
           }

           // Atribui��o de valor para a habilita��o de um timer
           case INST_TIMER_ENABLE_ATTRIB:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];
                                
                // Passa para a �rea de dados
                i++;

                // Faz a atribui��o  
                TimerEnable[indexvar] = Program[i];


                // Reseta o timer se o enable for igual a zero
                if (TimerEnable[indexvar] == 0)
                {
                	Timers[indexvar] = 0;
                }


                // Passa para a pr�xima instru��o
                i++;

                break;
           }

           // Incrementa um contador
           case INST_COUNTER_ATTRIB_INC:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Faz a atribui��o
                if (Counters[indexvar] < 255)
                {
                	Counters[indexvar] = Counters[indexvar] + 1;
                }

                // Passa para a pr�xima instru��o
                i++;

                break;
           }

           // Decrementa um contador
           case INST_COUNTER_ATTRIB_DEC:
           {
           		// Passa para a �rea de do �ndice da vari�vel
               	i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Faz a atribui��o  
                if (Counters[indexvar] > 0)
                {
                	Counters[indexvar] = Counters[indexvar] - 1;
                }    

                // Passa para a pr�xima instru��o
                i++;

                break;
           }

           // Instru��o de verifica��o se a entrada � igual ao valor de referencia
           case INST_IF_INPUT_EQUAL:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Inputs[indexvar] == comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                        	// Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                     		// Uni�o AND
                            if (AndChoice)
                            {
                            	// Retorna a condi��o inicial
                               	AndChoice = 0;

                                // Calcula a opera��o l�gica AND
                                testresultold = testresult & testresultold;

                                // Passa para a pr�xima instru��o
                                i++;
                            }
                     }
                }

                break;
            }

            // Instru��o de verifica��o se a entrada � diferente do valor de referencia
            case INST_IF_INPUT_DIFF:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Inputs[indexvar] != comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                        	// Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                     	// Uni�o AND
                        if (AndChoice)
                        {
                        	// Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
               }

               break;
            }

            // Instru��o de verifica��o se a saida � igual ao valor de referencia 
            case INST_IF_OUTPUT_EQUAL:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Outputs[indexvar] == comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                    else
                    {
                    	// Uni�o AND
                        if (AndChoice)
                        {
                        	// Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                 }

                 break;
            }

            // Instru��o de verifica��o se a saida � diferente do valor de referencia
            case INST_IF_OUTPUT_DIFF:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Outputs[indexvar] != comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                    // Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                        	// Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                    else
                    {
                    	// Uni�o AND
                        if (AndChoice)
                        {
                        	// Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                }

                break;
            }

            // Instru��o de verifica��o se a memoria � igual ao valor de referencia
            case INST_IF_MEMORY_EQUAL:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Memorys[indexvar] == comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                             // Indica o resultado da opera��o
                             testresultold = testresult;

                             // Desloca o ponteiro do programa para a instru��o goto desse if
                             i = ifjumpto;
                        }
                        else
                        {
                        	// Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                     	// Uni�o AND
                        if (AndChoice)
                        {
                        	// Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                }

                break;
            }


            // Instru��o de verifica��o se a memoria � diferente do valor de referencia
            case INST_IF_MEMORY_DIFF:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Memorys[indexvar] != comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                     	// Uni�o AND
                        if (AndChoice)
                        {
                        	// Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                  }

               break;
            }

            // Instru��o de verifica��o se o contador � igual ao valor de referencia
            case INST_IF_COUNTER_EQUAL:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Counters[indexvar] == comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                    // Uniao OR
                    if (OrChoice)
                    {
                        // Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                            // Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                        // Uni�o AND
                        if (AndChoice)
                        {
                            // Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                  }

                break;
            }


            // Instru��o de verifica��o se o contador � diferente do valor de referencia
            case INST_IF_COUNTER_DIFF:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Counters[indexvar] != comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                    else
                    {
                    	// Uni�o AND
                        if (AndChoice)
                        {
                            // Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                }

             break;
            }


            // Instru��o de verifica��o se o contador � maior que o de referencia
            case INST_IF_COUNTER_MAJOR:
            {
                // Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Counters[indexvar] > comparevalue)
                {
                	testresult = 1;
                }
                else
                {
                	testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                	fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                	// Uniao OR
                    if (OrChoice)
                    {
                    	// Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                        	// Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                     	// Uni�o AND
                        if (AndChoice)
                        {
                           // Retorna a condi��o inicial
                           AndChoice = 0;

                           // Calcula a opera��o l�gica AND
                           testresultold = testresult & testresultold;

                           // Passa para a pr�xima instru��o
                           i++;
                        }
                     }
                 }

                break;
            }


            // Instru��o de verifica��o se o contador � menor que o valor de referencia
            case INST_IF_COUNTER_MINOR:
            {
            	// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Counters[indexvar] < comparevalue)
                {
                    testresult = 1;
                }
                else
                {
                    testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                    fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                    // Uniao OR
                    if (OrChoice)
                    {
                        // Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                            // Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                    }
                    else
                    {
                        // Uni�o AND
                        if (AndChoice)
                        {
                            // Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                         }
                     }
                 }

              break;
           }

           // Instru��o de verifica��o se o timer � igual ao valor de referencia
           case INST_IF_TIMER_EQUAL:
           {
           		// Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Timers[indexvar] == comparevalue)
                {
                    testresult = 1;
                }
                else
                {
                    testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                    fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                 }
                 else
                 {
                    // Uniao OR
                    if (OrChoice)
                    {
                        // Retorna a condi��o inicial
                        OrChoice = 0;

                        // Se o testresult for true, ent�o j� desloca para a instru��o goto
                        if (testresult)
                        {
                            // Indica o resultado da opera��o
                            testresultold = testresult;

                            // Desloca o ponteiro do programa para a instru��o goto desse if
                            i = ifjumpto;
                        }
                        else
                        {
                            // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                            testresultold = 0;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                     else
                     {
                        // Uni�o AND
                        if (AndChoice)
                        {
                            // Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                        }
                     }
                  }

               break;
            }


            // Instru��o de verifica��o se o timer � diferente do valor de referencia
            case INST_IF_TIMER_DIFF:
            {
                // Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Timers[indexvar] != comparevalue)
                {
                    testresult = 1;
                }
                else
                {
                    testresult = 0;
                }

                 // Verifica se � o primeiro teste desse IF
                 if (fistcompare)
                 {
                     fistcompare = 0;

                     // Indica o resultado da opera��o
                     testresultold = testresult;

                     // Passa para a pr�xima instru��o
                     i++;
                 }
                 else
                 {
                     // Uniao OR
                     if (OrChoice)
                     {
                         // Retorna a condi��o inicial
                         OrChoice = 0;

                         // Se o testresult for true, ent�o j� desloca para a instru��o goto
                         if (testresult)
                         {
                              // Indica o resultado da opera��o
                              testresultold = testresult;

                              // Desloca o ponteiro do programa para a instru��o goto desse if
                              i = ifjumpto;
                         }
                         else
                         {
                              // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                              testresultold = 0;

                              // Passa para a pr�xima instru��o
                              i++;
                         }
                      }
                      else
                      {
                         // Uni�o AND
                         if (AndChoice)
                         {
                             // Retorna a condi��o inicial
                             AndChoice = 0;

                             // Calcula a opera��o l�gica AND
                             testresultold = testresult & testresultold;

                             // Passa para a pr�xima instru��o
                             i++;
                         }
                      }
                   }

                break;
            }


            // Instru��o de verifica��o se o timer � maior que o de referencia
            case INST_IF_TIMER_MAJOR:
            {
                // Passa para a �rea de do �ndice da vari�vel
                i++;

                // Captura o indice da vari�vel que ser� acessada
                indexvar = Program[i];

                // Passa para a �rea de do valor de compara��o
                i++;

                // Captura o valor que ser� comparado
                comparevalue = Program[i];

                // Efetua o teste
                if (Timers[indexvar] > comparevalue)
                {
                     testresult = 1;
                }
                else
                {
                     testresult = 0;
                }

                // Verifica se � o primeiro teste desse IF
                if (fistcompare)
                {
                    fistcompare = 0;

                    // Indica o resultado da opera��o
                    testresultold = testresult;

                    // Passa para a pr�xima instru��o
                    i++;
                }
                else
                {
                    // Uniao OR
                    if (OrChoice)
                    {
                         // Retorna a condi��o inicial
                         OrChoice = 0;

                         // Se o testresult for true, ent�o j� desloca para a instru��o goto
                         if (testresult)
                         {
                              // Indica o resultado da opera��o
                              testresultold = testresult;

                              // Desloca o ponteiro do programa para a instru��o goto desse if
                              i = ifjumpto;
                         }
                         else
                         {
                              // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                              testresultold = 0;

                              // Passa para a pr�xima instru��o
                              i++;
                         }
                     }
                     else
                     {
                         // Uni�o AND
                         if (AndChoice)
                         {
                             // Retorna a condi��o inicial
                             AndChoice = 0;

                             // Calcula a opera��o l�gica AND
                             testresultold = testresult & testresultold;

                             // Passa para a pr�xima instru��o
                             i++;
                         }
                      }
                   }

                 break;
             }


             // Instru��o de verifica��o se o timer � menor que o valor de referencia
             case INST_IF_TIMER_MINOR:
             {
                 // Passa para a �rea de do �ndice da vari�vel
                 i++;

                 // Captura o indice da vari�vel que ser� acessada
                 indexvar = Program[i];

                 // Passa para a �rea de do valor de compara��o
                 i++;

                 // Captura o valor que ser� comparado
                 comparevalue = Program[i];

                 // Efetua o teste
                 if (Timers[indexvar] < comparevalue)
                 {
                     testresult = 1;
                 }
                 else
                 {
                     testresult = 0;
                 }

                 // Verifica se � o primeiro teste desse IF
                 if (fistcompare)
                 {
                     fistcompare = 0;

                     // Indica o resultado da opera��o
                     testresultold = testresult;

                     // Passa para a pr�xima instru��o
                     i++;
                 }
                 else
                 {
                     // Uniao OR
                     if (OrChoice)
                     {
                         // Retorna a condi��o inicial
                         OrChoice = 0;

                         // Se o testresult for true, ent�o j� desloca para a instru��o goto
                         if (testresult)
                         {
                             // Indica o resultado da opera��o
                             testresultold = testresult;

                             // Desloca o ponteiro do programa para a instru��o goto desse if
                             i = ifjumpto;
                         }
                         else
                         {
                             // Como os dois testes (testresult e testresultold) foram false o OR deles � false tamb�m
                             testresultold = 0;

                             // Passa para a pr�xima instru��o
                             i++;
                         }
                      }
                      else
                      {
                         // Uni�o AND
                         if (AndChoice)
                         {
                            // Retorna a condi��o inicial
                            AndChoice = 0;

                            // Calcula a opera��o l�gica AND
                            testresultold = testresult & testresultold;

                            // Passa para a pr�xima instru��o
                            i++;
                         }
                      }
                  }
				
				break;
			 }
		}	
	}
}