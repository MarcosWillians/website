#ifndef DELAY_H
#define DELAY_H

void delay_tcarrier_ir();

#endif
