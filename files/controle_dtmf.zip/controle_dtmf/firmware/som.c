


void Freq1()
{
   auto int i;
   for(i=0;i<250;i++)
   {
   delay_cycles(200);
   delay_cycles(200);
   #asm
      bsf PORTB,4
   #endasm
   delay_cycles(200);
   delay_cycles(200);
   #asm
      bcf PORTB,4
   #endasm

   /* Reinicia o watchdog */
   restart_wdt();

   }
}


void Freq2()
{
   auto int i;

   for(i=0;i<250;i++)
   {
   delay_cycles(250);
   delay_cycles(250);
   delay_cycles(250);
   #asm
      bsf PORTB,4
   #endasm  
   delay_cycles(250);
   #asm
      bcf PORTB,4
   #endasm

   /* Reinicia o watchdog */
   restart_wdt();

   }
}



#if 0
void freqvar()
{
      int i,j,periodo;

      periodo=120;
      for(i=100;i<200;i++)
      {
         for(j=0;j<periodo;j++)
         {
            delay_cycles(1);
         }
         #asm
            bsf PORTB,4
         #endasm

         for(j=0;j<periodo;j++)
         {
            delay_cycles(1);
         }
         #asm
            bcf PORTB,4
         #endasm

         periodo--;

         /* Reinicia o watchdog */
         restart_wdt();
      }
}
#endif


int xx;

void SomLigado()
{
   if(SomAtiv)
   {
      delay_ms(200);
      Freq1();
      delay_ms(100);
      Freq1();
   }
}

void SomDesligado()
{
   if(SomAtiv)
   {
      delay_ms(100);
      Freq2();
   }
}



void SomErro()
{
   if(SomAtiv)
   {
      delay_ms(200);
      Freq2();      
      Freq2(); 
   }
}

void SomAcerto()
{
	if(SomAtiv)
   {

      delay_ms(200);
      Freq1();

      //printf("Som\n\r");
   }
}


