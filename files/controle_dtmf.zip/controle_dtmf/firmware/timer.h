
/* Prot�tipos */
unsigned int SetTimeOut(unsigned int Time);
short	RetTimeOut(unsigned int Timer);


#define TIME_MAX_TIMERS 6
#define MAX_TIMER_VALUE   128
#define TIMEOUT_RFS_CHM     0
#define TIMEOUT_RFS_COMANDO 1
#define TIMEOUT_RFS_WDT     2
#define TIMEOUT_RFS_TIME    3
#define TIMEOUT_RFS_TIMERS  4
#define TIMEOUT_RFS_INPUT   5





#define TIMEOUT_RFS_COMANDO_VALUE    4
#define TIMEOUT_RFS_TIME_VALUE      20
#define TIMEOUT_RFS_TIMERS_VALUE    20
#define TIMEOUT_RFS_WDT_VALUE        4
#define TIMEOUT_RFS_CHM_VALUE        2
#define TIMEOUT_RFS_INPUT_VALUE      2
