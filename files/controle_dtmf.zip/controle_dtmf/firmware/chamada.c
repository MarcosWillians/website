/**************************************************/
/*                                                */
/* Chamada.c                                      */
/*                                                */
/* -Controla a opera��o de chamada telefonica     */
/*                                                */
/**************************************************/


int ContPulsoChm;
int ContTimePulsoChm;
int ContTremPulso;
int ContTimeOutChm;
int ContResetTimePulsoChm;


/* TimeOut de encerramento de chamada */
#define CHM_TIMEOUT_CHAMADA       250

unsigned int TimerChamada;


/**************************************************/
/*                                                */
/* ChmInicia()                                    */
/*                                                */
/* -Inicializa a tarefa de chamada                */
/*                                                */
/**************************************************/
void ChmInicia()
{
   TimerChamada=SetTimeOut(TIMEOUT_RFS_CHM_VALUE);
}



/**************************************************/
/*                                                */
/* ChmRefresh()                                   */
/*                                                */
/* -Refresh da tarefa de chamada                  */
/*                                                */
/**************************************************/
void ChmRefresh()
{
   auto short Aux;
   auto int Aux2;
   static short PusoAnt;

    /* Para encontrar erros */
   UltFunc=UltFunc_ChmRefresh();

   /* Verifica timeout da chamada */
   if (RetTimeOut(TimerChamada))
   {  

      TimerChamada=SetTimeOut(TIMEOUT_RFS_CHM_VALUE);

      switch(EstadoChm)
      {
          case CHM_EST_TREM_PULSO:
          {
            Aux=input(PIN_B6);

            //printf("\nAux=%d PusoAnt=%d\n\r",Aux,PusoAnt);

            /* Verifica se � hora de resetar */
            if(ContResetTimePulsoChm<=0)
            {
               /* Reseta o contador de pulsos de chamada */
               EstadoChm=CHM_EST_ENCERRA_CHAMADA;
            }
            ContResetTimePulsoChm--;

            /* Verifica se houve transi��o negativa */
            if(!Aux)  //if(!Aux&&PusoAnt)
            {
               /* Incrementa o contador de trem de pulso */
               ContTremPulso++;

               /* Verifica se j� recebeu pulsos */
               if(ContTremPulso>1)
               {
                  /* Recarrega o contador de reset de pulso */
                  ContResetTimePulsoChm=250;

                  ContTimeOutChm=0;
                  ContTimePulsoChm=0;
                  ContTremPulso=0;
                  EstadoChm=CHM_EST_CONTA_PULSO;
               }
            }
            //PusoAnt=Aux;
         }
         break;


         case CHM_EST_CONTA_PULSO:
         {
             /* Se j� deu o tempo do ring */
             if(ContTimePulsoChm>15)
             {
                //printf("\nRng\r\n");

                /* Incremewnta o contador de pulso */
                ContPulsoChm++;

                /* Carrega o numero de toques da eeprom */
                Aux2=read_eeprom_func(CMD_END_N_TOQUES);

                //printf("nt:%d\n\r",Aux2);

                if(ContPulsoChm>=Aux2)
                {
                  EstadoChm=CHM_EST_PROCESSA_CHAMADA;
                  //printf("\nChamada atendida\n\r");
                }
                else
                {
                  EstadoChm=CHM_EST_TREM_PULSO;
                }
             }
             else
             {
                ContTimePulsoChm++;
             }
         }
         break;

         case CHM_EST_PROCESSA_CHAMADA:
         {
            /* Atende a chamada */
            #asm
               bsf PORTB,7
            #endasm

            //printf("\ntarefa chamada %d\n\r",ContTimeOutChm);

            /* Verifica se houve timeout da chamada */
            if(ContTimeOutChm<CHM_TIMEOUT_CHAMADA)
            {
               /* Verifica se alguma tecla foi digitada */
               if(CmdTeclaDigitada)
               {
                  /* Zera o contador de timeout de encerramento de chamada */
                  ContTimeOutChm=0;

                  /* Desliga o flag de tecla digitada*/
                  CmdTeclaDigitada=FALSE;
               }
               else
               {
                  /* Incrementa o contador de timeout de encerramento de chamada */
                  ContTimeOutChm++;
               }
            }
            else
            {
               /* Encerra a chamada */
               EstadoChm=CHM_EST_ENCERRA_CHAMADA;
            }

         }
         break;

         case CHM_EST_ENCERRA_CHAMADA:
         {
            ContTremPulso=0;
            ContPulsoChm=0;
            ContDigSenha=0;
            //printf("\nChamada encerrada\n\r");

            /* Recarrega o contador de reset de pulso */
            ContResetTimePulsoChm=250;

            /* Encerra a chamada desligando o rele de atendimento */
            #asm
            bcf PORTB,7
            #endasm

            EstadoChm=CHM_EST_TREM_PULSO;

            /* Retorna ao estado para digitar a senha se o estado do jumper de snha permitir */
            if(input(PIN_B5))
            {
               CmdEstado=CMD_EST_SENHA_0;
            }
         }
         break;


         default:
         {
            EstadoChm=CHM_EST_TREM_PULSO;
            ContPulsoChm=0;
            ContTremPulso=0;
            ContTimePulsoChm=0;
         }
         break;
      }
   }
}














