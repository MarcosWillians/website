
void ChmInicia();
void ChmRefresh();

int EstadoChm;
#define CHM_EST_TREM_PULSO       0
#define CHM_EST_CONTA_PULSO      1
#define CHM_EST_PROCESSA_CHAMADA 2
#define CHM_EST_ENCERRA_CHAMADA  3
