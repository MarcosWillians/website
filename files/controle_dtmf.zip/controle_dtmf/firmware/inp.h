long ContDiv;
long ContDiv2;

extern short InpValorEntrada;

void InpBounce();


void InpInicia();
