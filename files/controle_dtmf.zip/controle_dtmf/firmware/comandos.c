/**************************************************/
/*                                                */
/* comandos.c                                     */
/*                                                */
/* -Interface de entrada de dados do sistema      */
/*                                                */
/**************************************************/

/* Valor inv�lido do contador de digitos */
#define CONT_DIG_NONE 255;


int CmdSenha[4];

int CmdAux[3];

int CmdNumToques;
int HoraCpy;
int MinCpy;
int DiaCpy;
int PortaComTimer;
int EstadoComTimer;
int ContDig;
int GravaConfEnt;
short CmdErroSenha;
unsigned int TimerCmd;

void CmdProcessaComando();



int Entrada;

short ComandoPendente;

/**************************************************/
/*                                                */
/* CmdInicia()                                    */
/*                                                */
/* -Inicia os comandos                            */
/*                                                */
/**************************************************/
void CmdInicia()
{
   CmdEstado=CMD_EST_SENHA_0;
   TimerCmd=SetTimeOut(TIMEOUT_RFS_COMANDO_VALUE);
   ComandoPendente=FALSE;
}


//void ExibeTime()
//{
//printf("%u\n\r",TimeCont);
//}




/**************************************************/
/*                                                */
/* CmdProcessaComando()                           */
/*                                                */
/* -Refresh da tarefa de comandos                 */
/*                                                */
/**************************************************/
void CmdProcessaComando()
{
   auto int Aux;
   auto int i;

   SomAcerto();

   CmdTeclaDigitada=TRUE;

   switch (CmdEstado)
   {
      case CMD_EST_SENHA_0:
      {
         //printf("c0\n\r");

         if(!input(PIN_B5))
         {
            /* Se o o jumper estiver conectado (aterrado) n�o faz a verifica��o de senha */
            CmdEstado=CMD_EST_COMANDO;
            //printf("N�o verifica senha\n");
         }
         else
         {
            /* Apaga o indicador de erro de senha */
            CmdErroSenha=0;

            if(ContDig>2)
            {
               /* Recebe o �ltimo d�gito da senha */
               CmdSenha[3]=Entrada;

               for(i=0;i<4;i++)
               {
                  /* Le o valor gravado da senha */
                  Aux=read_eeprom_func(CMD_END_SENHA+i);

                  //printf("CmdSenha[i]=%d Aux=%d\n",CmdSenha[i],Aux);
                  //delay_ms(100);

                  /* Se o valor digitado � diferente do gravado indica erro */
                  if(CmdSenha[i]!=Aux)
                  {
                     CmdErroSenha=1;
                  }
               }

               /* Se houve erro retorna para redigitar a senha*/
               if(CmdErroSenha)
               {
                  ContDig=0;
                  SomErro();

                  /* Encerra a chamada */
                  EstadoChm=CHM_EST_ENCERRA_CHAMADA;
               }
               else
               {
                  //CmdFimAcerto();

                  SomLigado();

                  CmdEstado=CMD_EST_COMANDO;
               }
            }
            else
            {
               CmdSenha[ContDig]=Entrada;

               ContDig++;
            }
         }
      }
      break;

      /* Escolha do comando desejado */
      case CMD_EST_COMANDO:
      {
         //printf("c1\n\r");

         /* Zera o contador de numeros digitados */
         ContDig=0;

         switch(Entrada)
         {

            /* Controle da porta de sa�da 1 */
            case CMD_COMANDO_PORT_1:
            {
               CmdEstado=CMD_EST_PORT_1;
            }
            break;

            /* Controle da porta de sa�da 2 */
            case CMD_COMANDO_PORT_2:
            {
                CmdEstado=CMD_EST_PORT_2;
            }
            break;

            /* Status da porta de entrada */
            case CMD_COMANDO_PORT_3:
            {
                CmdEstado=CMD_EST_PORT_3;
            }
            break;

            /* Controle da programa��o dos timers */
            case CMD_COMANDO_TIMER:
            {
               ContDig=0;
               CmdEstado=CMD_EST_TIMER;
            }
            break;

            /* Controle da programacao da senha */
            case CMD_COMANDO_SENHA:
            {
               ContDigSenha=0;
               CmdEstado=CMD_EST_SENHA;
            }
            break;

            /* Controle do numero de toques para o atendimento */
            case CMD_COMANDO_TOQUES_ATEND:
            {
               CmdEstado=CMD_EST_TOQUES_ATEND;
            }
            break;

            /* Comando para encerramento da chamada */
            case CMD_COMANDO_ENCERRA_CHM:
            {
               CmdEstado=CMD_EST_COMANDO_ENCERRA_CHM;
            }
            break;


            case CMD_COMANDO_CONF_ENT:
            {
               ContDig=0;
               CmdEstado=CMD_EST_COMANDO_CONF_ENT;
            }
            break;


         }
      }
      break;

      /* Controle porta 1 */
      case CMD_EST_PORT_1:
      {
        IoStatus(PORTA_1,Entrada);

        CmdEstado=CMD_EST_COMANDO;

        //CmdFimAcerto();
      }
      break;

      /* Controle porta 2 */
      case CMD_EST_PORT_2:
      {

        IoStatus(PORTA_2,Entrada);

        CmdEstado=CMD_EST_COMANDO;

        //CmdFimAcerto();
      }
      break;

      /* Controle porta 2 */
      case CMD_EST_PORT_3:
      {
         IoStatus(PORTA_3,Entrada);

         CmdEstado=CMD_EST_COMANDO;
      }
      break;

      /* Estado de configura��o dos numeros de toques para atendimento */
      case CMD_EST_TOQUES_ATEND:
      {
          switch(Entrada)
          {
              /* Caso seja o # configura o numero de toques */
              case 12:
              {
                  write_eeprom_func (CMD_END_N_TOQUES, CmdNumToques);

                 SomLigado();

                 CmdEstado=CMD_EST_COMANDO;

                 // printf("Gravado toques %d\r\n",read_eeprom_func(CMD_END_N_TOQUES));
                 // CmdFimAcerto();
              }
              break;

              /* Caso seja o * cancela a opera��o */
              case 11:
              {
                  //CmdFimErro();

                  SomErro();

                  CmdEstado=CMD_EST_COMANDO;
              }
              break;

              /* Recebe o numero de toques desejado */
              default:
              {
                  CmdNumToques=Entrada;
              }
          }

      }
      break;

      /* Programacao da senha */
      case CMD_EST_SENHA:
      {

          /* Se for um asterisco cancela o comando */
          if(Entrada==11)
          {
            //CmdFimErro();
            SomErro();

            CmdEstado=CMD_EST_COMANDO;
          }


          /* Atualiza o valor da senha */
          CmdSenha[ContDig]=Entrada;


          if(ContDig==4)
          {
               /* Se for um enter atualiza a senha */
               if(Entrada==12)
               {
                  for(i=0;i<4;i++)
                  {
                     /* Salva a senha na mem�ria */
                     write_eeprom_func (CMD_END_SENHA+i, CmdSenha[i]);
                  }
                  //printf("Senha alterada\n");
                  SomLigado();
                  CmdEstado=CMD_EST_COMANDO;
               }
               else
               {
                  SomErro();
                  CmdEstado=CMD_EST_COMANDO;
               }
               ContDig=0;
          }

          /* Atualiza o endere�o da senha */
          Aux=CMD_END_SENHA+ContDig;

          ContDig++;

      }
      break;


     /* Comando para o encerramento da chamada */
     case CMD_EST_COMANDO_ENCERRA_CHM:
     {
         #if 0
         while(1)
         {
            //printf("Trava\n");
            delay_ms(500);
         }
         #endif

         if(Entrada==12)
         {
            EstadoChm=CHM_EST_ENCERRA_CHAMADA;
            SomLigado();
         }
         else
         {
            SomErro();
         }
         CmdEstado=CMD_EST_COMANDO;
     }
     break;


     /* Estado de configura��o dos timers */
     case CMD_EST_TIMER:
     {

        /* Se for um asterisco cancela o comando */
        if(Entrada==11)
        {
            /* Emite o som de erro */
            SomErro();

            /* N�o faz a analise deste digito*/
            ContDig=CONT_DIG_NONE;

            CmdEstado=CMD_EST_COMANDO;
        }

        switch(ContDig)
        {
           case 0:
           {
               /* Recebe o primeiro digito da Hora*/
               HoraCpy=10*Entrada;

               /* Apaga todos os timers */
               if(Entrada==12)
               {
                  for (i=0;i<=TMP_MEM_TEMPORIZADORES;i=i+5)
                  {
                     Aux=i+TMP_END_BASE_TEMP;

                     /* Apaga o Temporizador */
                     write_eeprom_func (Aux, TMP_TEMP_DESATIVADO);
                  }

                  /* Zera o contador de temporizadores */
                  write_eeprom_func (TMP_END_QUANT_TEMP,0 );

                  //printf("\nTimers zerados\n");

                  SomLigado();

                  CmdEstado=CMD_EST_COMANDO;

               }
           }
           break;

           case 1:
           {
               /* Recebe o segundo digito da hora */
               HoraCpy=HoraCpy+Entrada;
           }
           break;

           case 2:
           {
               /* Recebe o primeiro digito do minuto*/
               MinCpy=10*Entrada;
           }
           break;

           case 3:
           {
               /* Recebe o segundo digito do minuto */
               MinCpy=MinCpy+Entrada;
           }
           break;

           case 4:
           {
               /* Recebe o digito do dia */
               DiaCpy=Entrada;
           }
           break;

           case 5:
           {
               /* Se for um enter reprograma o rel�gio, sen�o continua */
               if(Entrada==12)
               {
                  /* Atualiza a Hora */
                  Hora=HoraCpy;

                  /* Atualiza o minuto */
                  Minuto=MinCpy;

                  /* Atualiza o segundo */
                  Segundo=0;

                  /* Atualiza o dia */
                  Dia=DiaCpy;

                  //printf("\nHora Ajustada\n");

                  SomLigado();

                  CmdEstado=CMD_EST_COMANDO;

               }
               else
               {
                  /* Recebe a Porta a ser controlada pelo timer */
                  PortaComTimer=Entrada;
               }
           }
           break;

           case 6:
           {
               /* Recebe o Estado da porta a ser controlada pelo timer */
               EstadoComTimer=Entrada;
           }
           break;

           case 7:
           {
               /* Se for um enter inclui o timer  */
               if(Entrada==12)
               {
                  #if 1


                  if(TmpInclui(EstadoComTimer,DiaCpy,HoraCpy,MinCpy,PortaComTimer))
                  {
                     //printf("\nTmr\n");

                      SomLigado();

                      CmdEstado=CMD_EST_COMANDO;
                     //printf("h:%d",hora);

                  }
                  else
                  {

                     //printf("\nErro Timer\n");

                     //CmdFimErro();

                     SomErro();

                     CmdEstado=CMD_EST_COMANDO;

                  }

                  #endif

               }
               else
               {
                  SomErro();

                  CmdEstado=CMD_EST_COMANDO;
               }
           }
           break;
        }

        ContDig++;
     }
     break;


      /* Comando para a configura��o das a��es da entrada */
     case CMD_EST_COMANDO_CONF_ENT:
     {
        /* Indica que a configuracao nao deve ser gravada */
        GravaConfEnt=FALSE;

        /* Se for um asterisco cancela o comando */
        if(Entrada==11)
        {
            SomErro();

            CmdEstado=CMD_EST_COMANDO;
        }


        switch(ContDig)
        {
            case 0:
            {
               /* Se for um enter no inicio desativa a programacao da entrada */
               if(Entrada==12)
               {
                  /* Desativa a programacao da entrada */
                  CmdAux[0]=0;

                  /* Indica que a configuracao  deve ser gravada */
                  GravaConfEnt=TRUE;
               }
               else
               {
                   /* Recebe o comando */
                  CmdAux[0]=Entrada;
               }
            break;
            }

            case 1:
            {
               /* Verifica se o comando digitado � simples */
               if(CmdAux[0]<3)
               {
                  if(Entrada==12)
                  {
                     /* Indica que a configuracao  deve ser gravada */
                     GravaConfEnt=TRUE;
                  }
                  else
                  {
                     //CmdFimErro();
                     SomErro();

                     CmdEstado=CMD_EST_COMANDO;
                  }
               }
               else
               {
                  if(Entrada!=12)
                  {
                     /* Recebe o comando */
                     CmdAux[1]=Entrada;
                  }
                  else
                  {
                     //CmdFimErro();
                      SomErro();

                     CmdEstado=CMD_EST_COMANDO;
                  }
               }
            break;
            }

            case 2:
            {
               if(Entrada==12)
               {
                  /* Indica que a configuracao deve ser gravada */
                  GravaConfEnt=TRUE;
               }
               else
               {
                     //CmdFimErro();

                     SomErro();

               }
               CmdEstado=CMD_EST_COMANDO;
               break;
           }

            default:
            {
               //CmdFimErro();
               SomErro();

               CmdEstado=CMD_EST_COMANDO;

            }
        }

        if(GravaConfEnt)
        {

            for(i=0;i<3;i++)
            {
               write_eeprom_func (i+INP_END_ACAO_1_ENT,CmdAux[i]);

               //printf("CmdAux[%d]=%d",i,CmdAux[i]);

               //printf("Salvando end:%d",i);
            }

             SomLigado();

             CmdEstado=CMD_EST_COMANDO;
         }
         ContDig++;
     }
     break;
   }   

   /* Desliga a emiss�o de som */
	SomAtiv=FALSE;

   /* Reabilita as interrup��es */
   //enable_interrupts(GLOBAL);

   //printf("\nFim\n");
}


/**************************************************/
/*                                                */
/* CmdRefresh()                                   */
/*                                                */
/* -Refresh da tarefa de comandos                 */
/*                                                */
/**************************************************/
void CmdRefresh()
{
   static short BotaoPressionado;
   int cc;

   if(RetTimeOut(TimerCmd))
   {
         TimerCmd=SetTimeOut(TIMEOUT_RFS_COMANDO_VALUE);

         /* Verifica se algum bot�o foi pressionado */
         if(input(PIN_A4)&&(!BotaoPressionado))
   	   {
            /* Marca que o bot�o j� foi pressionado */
            BotaoPressionado=TRUE;

             /* L� a entrada */
             Entrada=input_a() & 0x0F;

             /* Trata o caso do zero */
             if(Entrada==10)
             {
               Entrada=0;
             }

             /* Ativa o som */
             SomAtiv=TRUE;

             //cc=48+Entrada;

             //printf("r:%c",cc);
                         
             /* Processa o dado recebido */
             CmdProcessaComando();
         }
         else
         {
            if(!input(PIN_A4))
            {
               /* Marca que o bot�o foi solto */
               BotaoPressionado=FALSE;
            }
         }
    }
}











