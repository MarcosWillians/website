/////////////////////////////////////////////////////////////
//                           main.c                        //
//                                                         //
// -Programa principal do sistema de controle por dtmf     //
// Autor: Marcos Willians                                  //
//                                                         //
//                                                         //
// PINOUTS                                                 //
//                                                         //
// PORTA,0 ->DTMF BIT0              (IN)                   //
// PORTA,1 ->DTMF BIT1              (IN)                   //
// PORTA,2 ->DTMF BIT2              (IN)                   //
// PORTA,3 ->DTMF BIT3              (IN)                   //
// PORTA,4 ->DTMF TONE              (IN)                   //
//                                                         //
// PORTB,0 ->RELE 1                (OUT)                   //
// PORTB,1 ->RELE 2                (OUT)  TX TEPORARIO (5) //
// PORTB,2 ->ENTRADA 1              (IN)  RX TEMPORARIO(6) //
// PORTB,3 ->ATENDIMENTO A CHAMADA (OUT)                   //
// PORTB,4 ->SOM                   (OUT)                   //
// PORTB,5 ->JUMPER SENHA           (IN)                   //
// PORTB,6 ->RING                   (IN)                   //
// PORTB,7 ->POWERDOWN              (IN)                   //
//                                                         //
/////////////////////////////////////////////////////////////


#include <16f628.h>
#fuses HS,NOPROTECT,WDT,NOLVP,NOMCLR,NOBROWNOUT
#use delay(clock=3575611)
#use rs232(baud=2400, xmit=PIN_A5, rcv=PIN_B3) // #use rs232(baud=2400, xmit=PIN_B1, rcv=PIN_B3)


#include <main.h>
#include <inicia.h>
#include <comandos.h>
#include <temporizador.h>
#include <som.h>
#include <timer.h>
#include <funcs.h>
#include <io.h>
#include <chamada.h>
#include <inp.h>
#include <powersafe.h>

#include <som.c>
#include <interrupts.c>
#include <timer.c>
#include <inicia.c>
#include <temporizador.c>
#include <comandos.c>
#include <funcs.c>
#include <io.c>
#include <chamada.c>
#include <inp.c>
#include <powersafe.c>

void Debug(char c);


char c;

main()
{
   static unsigned int TimerWdt;

   TimerWdt=SetTimeOut(4);

   inicia();

   while(TRUE)
   {
      /* Refresh da tarefa de Timers */
      TmpRefresh();

      /* Refresh da tarefa de comandos */
      CmdRefresh();

      /* Refresh da tarefa de chamada */
      ChmRefresh();

      /* Refresh da tarefa de gerenciamento da entrada */
      PwrRefresh();

      /* Refresh da tarefa de power safe */
      InpRefresh();

      if(kbhit())
		{
         UltFunc=UltFunc_kbhit();
         c=getc();
         Debug(c);
      }

      if(RetTimeOut(TimerCmd))
      {      
         TimerWdt=SetTimeOut(4);
         restart_wdt();        
      } 
   }
}


void Debug(char c)
{

   //printf("%c\n\r",c);

   /* Desliga a emiss�o de som */
	SomAtiv=FALSE;



   switch(c)
   {

         case'0':
         {
            Entrada=0;
            CmdProcessaComando();
         }
         break;

         case'1':
         {
            Entrada=1;
            CmdProcessaComando();
         }
         break;

         case'2':
         {
            Entrada=2;
            CmdProcessaComando();
         }
         break;

         case'3':
         {
            Entrada=3;
            CmdProcessaComando();
         }
         break;

         case'4':
         {
            Entrada=4;
            CmdProcessaComando();
         }
         break;

         case'5':
         {
            Entrada=5;
            CmdProcessaComando();
         }
         break;

         case'6':
         {
            Entrada=6;
            CmdProcessaComando();
         }
         break;

         case'7':
         {
            Entrada=7;
            CmdProcessaComando();
         }
         break;

         case '8':
         {
            Entrada=8;
            CmdProcessaComando();
         }
         break;

         case'9':
         {
            Entrada=9;
            CmdProcessaComando();
         }
         break;

         case'*':
         {
            Entrada=11;
            CmdProcessaComando();
         }
         break;

         case'#':
         {
            Entrada=12;
            CmdProcessaComando();
         }
         break;
   }
}








