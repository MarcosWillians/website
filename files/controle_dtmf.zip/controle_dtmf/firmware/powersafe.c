/**************************************************/
/*                                                */
/* powersafe.c                                    */
/*                                                */
/* -Controla o consumo de energia                 */
/*                                                */
/**************************************************/

//Verificar a entrada de energia
//Se houver energia n�o faz nada
//Quando acabar:
//Desliga as saidas digitais
//desliga todos os perif�ricos
//Quando voltar:
//Restaura o valor das saidas
//


short PwrEnerg;

/**************************************************/
/*                                                */
/* PwrInicia()                                    */
/*                                                */
/* -Inicia a tarefa powersafe                     */
/*                                                */
/**************************************************/
void PwrInicia()
{
   PwrEnerg=TRUE;
}


/**************************************************/
/*                                                */
/* PwrRefresh()                                   */
/*                                                */
/* -Refresh da tarefa powersafe                   */
/*                                                */
/**************************************************/
void PwrRefresh()
{
   if(!input(PIN_B2))
   {
      PwrEnerg=FALSE;

      #asm
      		bcf PORTB,0 //Desliga a saida 1
            bcf PORTB,1 //Desliga a saida 2
            bcf PORTB,4 //Desliga o som
            bcf PORTB,7 //Desliga o rele de atendimento a chamada
      #endasm
   }
   else
   {
      /* Verifica se houve religamento da energia */
      if(!PwrEnerg)
      {
         /* Restaura o valor da saida 1 */
         if(ss1)
         {
            #asm
               bsf PORTB,0
            #endasm
         }

         /* Restaura o valor da saida 2 */
         if(ss2)
         {
            #asm
               bsf PORTB,1
            #endasm
         }
      }

      PwrEnerg=TRUE;
   }

}






