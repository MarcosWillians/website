

int read_eeprom_func(int End);
void write_eeprom_func(int End,int Valor);
void delay200();
