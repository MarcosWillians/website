/**************************************************/
/*                                                */
/* temporizador.c                                 */
/*                                                */
/* -Dispara o acionamento das sa�das              */
/*  de acordo com os hor�rios programados         */
/**************************************************/



/* Mem�ria flash dos temporizadores */
#define TMP_MAX_TEMPORIZADORES     10
#define TMP_MEM_TEMPORIZADORES     TMP_MAX_TEMPORIZADORES * 5



/* Constantes */
#define TMP_TEMP_DESATIVADO        0XFF
#define TMP_TODOS_DIAS             0

unsigned int TimerTemporizador;


/**************************************************/
/*                                                */
/* TmpInicia()                                    */
/*                                                */
/* Inicializa o Temporizador                      */
/*                                                */
/**************************************************/
void TmpInicia()
{   
   TimerTemporizador=SetTimeOut(TIMEOUT_RFS_TIMERS_VALUE);
}



/**************************************************/
/*                                                */
/* TmpRefresh()                                   */
/*                                                */
/* Inicializa o Temporizador                      */
/*                                                */
/**************************************************/
void TmpRefresh()
{
   auto int i;
   auto int Temporizador;
   auto int Estado;
   auto int Aux;

   /* Para encontrar erros */
   UltFunc=UltFunc_TmpRefresh();


   if (RetTimeOut(TimerTemporizador))
   {
      TimerTemporizador=SetTimeOut(TIMEOUT_RFS_TIMERS_VALUE);

      //printf("%d:%d:%d \r\n",hora,minuto,segundo);


      for (i=0;i<=TMP_MEM_TEMPORIZADORES;i=i+5)
      {
         /* Seleciona o endere�o base que cont�m o estado do temporizador */
        Temporizador=TMP_END_BASE_TEMP+i;

         /* Le o estado do temporizador */
        Estado=read_eeprom_func(Temporizador);



         /* Se o temporizador selecionado est� habilitado prossiga */
         if(Estado!=TMP_TEMP_DESATIVADO)
         {
            /* Seleciona o endere�o que cont�m o dado do dia */
            Temporizador++;

            /* Carrega o registro selecionado para a Ram */
            Aux=read_eeprom_func(Temporizador);

            /* Verifica se � o dia  de acionar ou se � para acionar todos os dias */
            if ((Aux==Dia)||(Aux==TMP_TODOS_DIAS))
            {
               /* Seleciona o endere�o que cont�m o dado da hora */
               Temporizador++;

               /* Carrega o registro selecionado para a Ram */
               Aux=read_eeprom_func(Temporizador);

               /* Verifica se � a hora de acionar */
               if (Aux==Hora)
               {
                  /* Seleciona o endere�o que cont�m o dado do minuto */
                  Temporizador++;

                  /* Carrega o registro selecionado para a Ram */
                  Aux=read_eeprom_func(Temporizador);

                  /* Verifica se � o minuto de acionar */
                  if (Aux==Minuto)
                  {
                     /* Seleciona o endere�o que cont�m o dado da porta */
                     Temporizador++;

                     /* Carrega o registro selecionado para a Ram */
                     Aux=read_eeprom_func(Temporizador);

                     /* Desativa o som */
                     SomAtiv=FALSE;

                     switch(Aux)
                     {
                        case 1:
                        {
                           if(Estado==1)
                           {
                              IoStatus(PORTA_1,LIGA);
                           }
                           else
                           {
                              IoStatus(PORTA_1,DESLIGA);
                           }
                        }
                        break;

                        case 2:
                        {
                           if(Estado==1)
                           {
                              IoStatus(PORTA_2,LIGA);
                           }
                           else
                           {
                              IoStatus(PORTA_2,DESLIGA);
                           }
                        }
                        break;
                     }

                     /* Ativa o som */
                     SomAtiv=TRUE;
                  }
               }
            }
         }
      }
   }
}


/**************************************************/
/*                                                */
/* TmpInclui()                                    */
/*                                                */
/* Inclui um  Temporizador                        */
/*                                                */
/**************************************************/
short TmpInclui(int Estado,int Dia,int Hora,int Minuto,int Port)
{
   auto int Aux;
   auto int Aux2;

   Aux2=read_eeprom_func(TMP_END_QUANT_TEMP);

   /* Verifica se h� espa�o para gravar o novo temporizador */
   if (Aux2<=TMP_MAX_TEMPORIZADORES)
   {
      /* Verifica se os valores de entrada s�o v�lidos */
      if ((Dia<0)||(Dia>7)||(Hora<0)||(Hora>23)||(Minuto<0)||(Minuto>59)||(Estado<0)||(Estado>8)||(Porta<3))
      {
        return(FALSE);
      }

      /* Aponta para o endere�o do pr�ximo temporizador */
      Aux=5*(Aux2)+TMP_END_BASE_TEMP;

      /* Desabilita as interrup��es para travar o valor de TimeCont*/
      disable_interrupts(GLOBAL);

      /* Escreve o Estado */
      write_eeprom_func (Aux, Estado);
      Aux++;

      /* Escreve o Dia */
      write_eeprom_func (Aux, Dia);
      Aux++;

       /* Escreve a Hora */
      write_eeprom_func (Aux, Hora);
      Aux++;

      /* Escreve o Minuto */
      write_eeprom_func (Aux, Minuto);
      Aux++;

      /* Escreve a Porta */
      write_eeprom_func (Aux, Port);


      /* Incrementa a quantidade de temporizadores registrados */
      Aux2++;

      /* Atualiza a quantidade de temporizadores registrados */
      write_eeprom_func (TMP_END_QUANT_TEMP,Aux2);

      /* Reabilita as interrup��es */
      enable_interrupts(GLOBAL);

      return(TRUE);
   }
   else
   {
      return(FALSE);
   }

}






