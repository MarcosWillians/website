void PwrInicia();
void PwrRefresh();
