


unsigned int TimeOut[TIME_MAX_TIMERS];

unsigned int SetTimeOut(unsigned int Time)
{
   return(Time+TimeCont);
}




short	RetTimeOut(unsigned int Timer)
{
   /* Verifica se deu timeout */
   if (TimeCont>=Timer)
   {
      /* Trata o caso do estouro da vari�vel inteira */
      if (TimeCont-Timer>MAX_TIMER_VALUE)
      return (FALSE);
      return (TRUE);
   }
   else
   {
      /* Trata o caso em que o timecont passou pelo ff e nao foi feito o teste do rettimeout */
      if(Timer-TimeCont>MAX_TIMER_VALUE)
      return (TRUE);
      return (FALSE);
   }
   
   
   
}


