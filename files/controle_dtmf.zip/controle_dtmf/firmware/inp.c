/**************************************************/
/*                                                */
/* input.c                                        */
/*                                                */
/* -Processamento da entrada digital e acionamento*/
/*                                                */
/*                                                */
/* 0-Nada                                         */
/* 1-Liga a saida 1 se entrada em 1               */
/* 2-Liga a saida 1 se entrada em 0               */
/* 3-Liga a saida 1 se entrada em 1 por 15 min    */
/* 4-Liga a saida 1 se entrada em 0 por 15 min    */
/* 5-Desliga a saida 1 se entrada em 1            */
/* 6-Desliga a saida 1 se entrada em 0            */
/* 7-Desliga a saida 1 se entrada em 1 por 15 min */
/* 8-Desliga a saida 1 se entrada em 0 por 15 min */
/*                                                */
/**************************************************/


int InpBounceCont;
short InpAtivaContTempo1;
short InpAtivaContTempo2;
short InpTimeout1;
short InpTimeout2;
int InpContTempo1;
int InpContTempo2;
unsigned int TimerInput;

#define INP_BOUCE_VALUE 3


/**************************************************/
/*                                                */
/* InpInicia()                                    */
/*                                                */
/* -Inicializa tarefa da entrada digital          */
/*                                                */
/**************************************************/
void InpInicia()
{
  InpBounceCont=0;
  InpAtivaContTempo1=0;
  InpAtivaContTempo2=0;
  InpTimeout1=0;
  InpTimeout2=0;
  InpContTempo1=0;
  InpContTempo1=0;
  ContDiv=0;
  ContDiv2=0;

  TimerInput=SetTimeOut(TIMEOUT_RFS_INPUT_VALUE);
}


/**************************************************/
/*                                                */
/* InpBounce()                                    */
/*                                                */
/* -Bounce da entrada digital                     */
/*                                                */
/**************************************************/
void InpBounce()
{
	auto short EntradaAtual;
	static short EntradaAnterior;

  /* Faz uma amostra do n�vel l�gico da entrada */
  EntradaAtual=input(PIN_B3);
  //EntradaAtual=testeentrada;


  /* Verifica se o n�vel l�gico da entrada continua o mesmo */
  if(EntradaAtual==EntradaAnterior)
  {
  	 /* Faz o bounce da entrada */
  	 if(InpBounceCont>=INP_BOUCE_VALUE)
    {
    	/* Atualiza o valor da entrada */
      InpValorEntrada=EntradaAtual;

      //printf("\r\nEntrada:%d\r\n",InpValorEntrada);

    }
    else
    {
      //printf("\r\nBouncecont:%d\r\n",InpBounceCont);

      /* Incrementa o contador do bounce */
    	InpBounceCont++;
    }
  }
  else
  {
   InpBounceCont=0;

   /* Salva o valor da entrada atual */
   EntradaAnterior=EntradaAtual;
  }
}


/**************************************************/
/*                                                */
/* InpExecAcao()                                   */
/*                                                */
/* -Executa a acao                                */
/*                                                */
/**************************************************/
void InpExecAcao(int Acao,short Index)
{

   auto int aux;

   aux=read_eeprom_func(INP_END_ACAO_TEMP);

   /* Entra a cada 1 minuto */
   if(ContDiv>1200)
   {
      ContDiv=0;

      if(InpAtivaContTempo1)
      {
         InpContTempo1++;

         if(InpContTempo1>=aux)
         {
            InpTimeout1=TRUE;
            InpAtivaContTempo1=FALSE;
            InpContTempo1=0;
         }
      }
   }
   else
   {
      if(InpAtivaContTempo1)
      {
         ContDiv++;
      }
      else
      {
         ContDiv=0;
      }
   }


   /* Entra a cada 1 minuto */
   if(ContDiv2>1200)
   {
      ContDiv2=0;

      if(InpAtivaContTempo2)
      {
         InpContTempo2++;

         if(InpContTempo2>=aux)
         {
            InpTimeout2=TRUE;
            InpAtivaContTempo2=FALSE;
            InpContTempo2=0;
         }
      }
   }
   else
   {
      if(InpAtivaContTempo2)
      {
         ContDiv2++;
      }
      else
      {
         ContDiv2=0;
      }
   }


   switch(Acao)
	{
	  /* Liga a saida 1 se entrada em 1 */
	  case 1:
	  {
         //printf("\r\na1\r\n");

         if(InpValorEntrada)
			{
			   IoStatus(PORTA_1,LIGA);
			}
	  }
	  break;

	  /* Liga a saida 1 se entrada em 0 */
	  case 2:
	  {
        //printf("\r\na2\r\n");

        if(!InpValorEntrada)
		  {
		    IoStatus(PORTA_1,LIGA);
		  }
	  }
	  break;

	  /* Liga a saida 1 se entrada em 1 por T min */
	  case 3:
     {
        //printf("\r\na3\r\n");

        if(InpValorEntrada)
		  {
            if(Index)
            {
               InpAtivaContTempo1=TRUE;

               if(InpTimeout1)
               {
                  IoStatus(PORTA_1,LIGA);
               }
            }
            else
            {
               InpAtivaContTempo2=TRUE;

               if(InpTimeout2)
               {
                  IoStatus(PORTA_1,LIGA);
               }
            }
        }
        else
        {
            if(Index)
            {
               InpTimeout1=FALSE;

               InpAtivaContTempo1=FALSE;
            }
            else
            {
               InpTimeout2=FALSE;

               InpAtivaContTempo2=FALSE;
            }
        }
     }
	  break;

	  /* Liga a saida 1 se entrada em 0 por T min */
	  case 4:
	  {
        //printf("\r\na4\r\n");

        if(!InpValorEntrada)
		  {
            if(Index)
            {
               InpAtivaContTempo1=TRUE;

               if(InpTimeout1)
               {
                  IoStatus(PORTA_1,LIGA);
               }
            }
            else
            {
               InpAtivaContTempo2=TRUE;

               if(InpTimeout2)
               {
                  IoStatus(PORTA_1,LIGA);
               }
            }
        }
        else
        {
            if(Index)
            {
               InpTimeout1=FALSE;

               InpAtivaContTempo1=FALSE;
            }
            else
            {
               InpTimeout2=FALSE;

               InpAtivaContTempo2=FALSE;
            }
        }
	  }
	  break;

	  /* Desliga a saida 1 se entrada em 1 */
	  case 5:
	  {

         //printf("\r\na5\r\n");

			if(InpValorEntrada)
			{
				IoStatus(PORTA_1,DESLIGA);
			}
	  }
	  break;

		/* Desliga a saida 1 se entrada em 0 */
	  case 6:
	  {
        //printf("\r\na6\r\n");

        if(!InpValorEntrada)
		  {
		    IoStatus(PORTA_1,DESLIGA);
		  }
	  }
	  break;

	  /* Desliga a saida 1 se entrada em 1 por T min */
	  case 7:
	  {
        //printf("\r\na7\r\n");

        if(InpValorEntrada)
		  {
            if(Index)
            {
               InpAtivaContTempo1=TRUE;

               if(InpTimeout1)
               {
                  IoStatus(PORTA_1,DESLIGA);
               }
            }
            else
            {
               InpAtivaContTempo2=TRUE;

               if(InpTimeout2)
               {
                  IoStatus(PORTA_1,DESLIGA);
               }
            }
        }
        else
        {
            if(Index)
            {
               InpTimeout1=FALSE;

               InpAtivaContTempo1=FALSE;
            }
            else
            {
               InpTimeout2=FALSE;

               InpAtivaContTempo2=FALSE;
            }
        }
	  }
	  break;

     /* Desliga a saida 1 se entrada em 0 por T min */
	  case 8:
	  {
        //printf("\r\na8\r\n");

        if(!InpValorEntrada)
		  {
            if(Index)
            {
               InpAtivaContTempo1=TRUE;

               if(InpTimeout1)
               {
                  IoStatus(PORTA_1,DESLIGA);
               }
            }
            else
            {
               InpAtivaContTempo2=TRUE;

               if(InpTimeout2)
               {
                  IoStatus(PORTA_1,DESLIGA);
               }
            }
        }
        else
        {
            if(Index)
            {
               InpTimeout1=FALSE;

               InpAtivaContTempo1=FALSE;
            }
            else
            {
               InpTimeout2=FALSE;

               InpAtivaContTempo2=FALSE;
            }
        }
	  }
	  break;
	}
}





/**************************************************/
/*                                                */
/* InpRefresh()                                   */
/*                                                */
/* -Refresh da tarefa da entrada digital          */
/*                                                */
/**************************************************/
void InpRefresh()
{
	auto int Aux;

	if (RetTimeOut(TimerInput))
   {
      TimerInput=SetTimeOut(TIMEOUT_RFS_INPUT_VALUE);

      /* Faz o bounce da entrada digital */
      InpBounce();

  	  /* Le o valor da condi��o para a a��o 1 */
      Aux=read_eeprom_func(INP_END_ACAO_1_ENT);

      /* Executa a a��o de acordo com o valor da entrada */
      InpExecAcao(Aux,FALSE);

      /* Le o valor da condi��o para a a��o 2 */
      Aux=read_eeprom_func(INP_END_ACAO_2_ENT);

      /* Executa a a��o de acordo com o valor da entrada */
      InpExecAcao(Aux,TRUE);
   }
}
