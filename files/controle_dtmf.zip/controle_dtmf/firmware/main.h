short ss1;
short ss2;

short testeentrada;


#define CMD_END_N_TOQUES           0x00
#define INP_END_ACAO_1_ENT         0x01
#define INP_END_ACAO_2_ENT         0x02
#define INP_END_ACAO_TEMP          0x03
#define IO_END_EST_PORTA           0x04
#define CMD_END_SENHA              0x05
#define TMP_END_QUANT_TEMP         0x09
#define TMP_END_BASE_TEMP          0x10


int UltFunc;
#define UltFunc_TmpRefresh() 1
#define UltFunc_ClkRefresh() 2
#define UltFunc_CmdRefresh() 3
#define UltFunc_ChmRefresh() 4
#define UltFunc_CmdProcessaComando(Entrada) 5
#define UltFunc_kbhit() 6


