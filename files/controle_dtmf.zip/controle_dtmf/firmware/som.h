

/* Prototipos */
void SomLigado();
void SomDesligado();
void SomErro();
void SomAcerto();
short SomAtiv;
