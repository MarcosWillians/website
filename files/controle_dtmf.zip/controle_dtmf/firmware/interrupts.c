


unsigned int TimeCont;
int ClockCont;

int Segundo,Minuto,Hora,Dia;


int save_w;
int save_status;
/**************************************************/
/*                                                */
/* interrupts.c                                   */
/*                                                */
/* -Processa as interrup��es do processador       */
/*                                                */
/**************************************************/

#define CLKREFRESH  0x0070


#bit zero_flag = status.2
#bit t0if = 0xb.2

#define Z 2

#INT_GLOBAL
void isr()  {
   #asm
      /* Salva o estado corrente do processador */
      MOVWF save_w
      SWAPF status,W
      BCF   status,5
      BCF   status,6
      MOVWF save_status

      BTFSS PIR1,TMR1IF   //Verifica se a interrup��o foi do Timer1
      GOTO cc1
      BCF T1CON,TMR1ON    // Desliga o Timer1 para recarregar
      MOVLW 0x51 //ea
      MOVWF TMR1H
      MOVLW 0x68 //2c
      MOVWF TMR1L

      INCF  TimeCont,F

      BSF T1CON,TMR1ON    // Liga o Timer1
      BCF PIR1,TMR1IF     // O bit de ocorrencia de interrupcao no Timer1 � apagado

      // Verifica se � hora de contar os segundos
      INCF ClockCont,F
      MOVLW 20
      XORWF ClockCont,W
      BTFSC status,Z
      goto PulsoSegundo
      crel:


      cc1:


      /* Restaura o processador da interrup��o */
      SWAPF save_status,W
      MOVWF status
      SWAPF save_w,F
      SWAPF save_w,W
      retfie


      PulsoSegundo:
      CLRF ClockCont
      INCF Segundo,F
      MOVLW 60
      XORWF Segundo,W
      BTFSC status,Z
      goto PulsoMinuto
      goto crel


      PulsoMinuto:
      CLRF Segundo
      INCF Minuto,F
      MOVLW 60
      XORWF Minuto,W
      BTFSC status,Z
      goto PulsoHora
      goto crel


      PulsoHora:
      CLRF Minuto
      INCF Hora,F
      MOVLW 24
      XORWF Hora,W
      BTFSC status,Z
      goto PulsoDia
      goto crel

      PulsoDia:
      CLRF Hora
      INCF Dia,F
      MOVLW 8
      XORWF Hora,W
      BTFSS status,Z
      goto crel
      MOVLW 1
      MOVWF DIA
      goto crel



   #endasm
}
