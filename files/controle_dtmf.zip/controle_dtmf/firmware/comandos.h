
/* Prot�tipos */
void CmdInicia();
void CmdRefresh();
void CmdProcessaComando();

int MultDez(int Dec);
short CmdTeclaDigitada;
int CmdEstado;
int ContDigSenha;
short AlteraDisc;
short AstDigitado;


/* Defines dos estados */
#define CMD_EST_SENHA_0               0
#define CMD_EST_COMANDO               1
#define CMD_EST_CONFIRMA              2
#define CMD_EST_PORT_1                3
#define CMD_EST_PORT_2                4
#define CMD_EST_PORT_3                5
#define CMD_EST_TOQUES_ATEND          6
#define CMD_EST_TIMER                 7
#define CMD_EST_SENHA                 8
#define CMD_EST_COMANDO_ENCERRA_CHM   9
#define CMD_EST_DISCAGEM             10
#define CMD_EST_COMANDO_CONF_ENT     11


/* Defines dos comandos */
#define CMD_COMANDO_PORT_1        1
#define CMD_COMANDO_PORT_2        2
#define CMD_COMANDO_PORT_3        3
#define CMD_COMANDO_TIMER         4
#define CMD_COMANDO_SENHA         5
#define CMD_COMANDO_TOQUES_ATEND  6
#define CMD_COMANDO_CONF_ENT      7

#define CMD_COMANDO_ENCERRA_CHM   9





#define CMD_BOT_AST_VELHA   23
#define CMD_BOT_NUMERO      25
#define CMD_USA_SENHA       26
#define CMD_NAO_USA_SENHA   27





