/**************************************************/
/*                                                */
/* io.c                                           */
/*                                                */
/* -Controle das portas de entrada/saida          */
/*                                                */
/**************************************************/


#define IO_EST_PORTA_MAX_REG 8

#define IO_END_EST_PORTA_FINAL IO_EST_PORTA_MAX_REG+IO_END_EST_PORTA



void IoInicia()
{
   auto int i;
   auto int aux;
}



void IoStatus(int Port,int Acao)
{
   auto int i;
   auto int aux;

	//printf("Porta:%d Acao:%d",Port,Acao);

   switch(Acao)
   {
      case LIGA:
      {
         switch(Port)
         {
            case PORTA_1:
            {
               	#asm
      		      bsf PORTB,0
      		      #endasm
      		      ss1=TRUE;
                  SomLigado();
                  break;
            }
            case PORTA_2:
            {
                  #asm
      		      bsf PORTB,1
      		      #endasm
      		      ss2=TRUE;
                  SomLigado();
                  break;
            }
            default:
            {
               SomErro();
            }

         }
         break;
      }

      case DESLIGA:
      {
         switch(Port)
         {
            case PORTA_1:
            {
               	#asm
      		      bcf PORTB,0
      		      #endasm
      		      ss1=FALSE;
                  SomDesligado();
                  break;
            }
            case PORTA_2:
            {
                  #asm
      		      bcf PORTB,1
      		      #endasm
      		      ss2=FALSE;
                  SomDesligado();
                  break;
            }
            default:
            {
               SomErro();
            }
         }
         break;
      }

      case PULSA:
      {
         switch(Port)
         {
            case PORTA_1:
            {
                  #asm
      		      bcf PORTB,0
      		      #endasm
                  delay200();
                  #asm
      		      bsf PORTB,0
      		      #endasm
      		      ss1=FALSE;
                  delay200();
                  #asm
      		      bcf PORTB,0
      		      #endasm
                  SomAcerto();
                  break;
            }
            case PORTA_2:
            {
                  #asm
      		      bcf PORTB,1
      		      #endasm
                  delay200();
                  #asm
      		      bsf PORTB,1
      		      #endasm
      		      ss2=FALSE;
                  delay200();
                  #asm
      		      bcf PORTB,1
      		      #endasm
                  SomAcerto();
                  break;
            }
            default:
            {
               SomErro();
            }
         }
      break;
      }

      case VERIFICA:
      {
         switch(Port)
         {
            case PORTA_1:
            {
               if(ss1)
               {
                  SomLigado();
               }
               else
               {
                  SomDesLigado();
               }
               break;
            }
            case PORTA_2:
            {
               if(ss2)
               {
                  SomLigado();
               }
               else
               {
                  SomDesLigado();
               }
               break;
            }
            case PORTA_3:
            {
               if(InpValorEntrada)
               {
                  SomLigado();
               }
               else
               {
                  SomDesLigado();
               }
               break;
            }
         }
         break;
      }
   }
}
