

void inicia()
{

   #asm

   ///////////////////PROGRAMACAO DAS PORTAS//////////////////////

   bsf	STATUS,RP0
   movlw	0b11111
	movwf	TRIPORTA 			//programa PORTA
	movlw	0b01101100
	movwf	TRIPORTB         	//programa PORTB
   bcf   STATUS,RP0

   clrf	PORTA             //Limpa PORTA

   movlw 0x07
	movwf CMCON             //habilita a PORTA para entrada/saida

   ///////////////////////////////////////////////////////////////




   ///////////////////PROGRAMACAO DO TIMER1///////////////////////

   movlw	0b11000000       //Habilita as interrup�oes gerais
   movwf	INTCON
   movlw 0b00000101       //Configura o Timer1
   movwf T1CON

   bsf STATUS,RP0
   movlw 0b00000001       //Habilita a interrup��o pelo Timer1
   movwf PIE1
   bcf STATUS,RP0

   ///////////////////////////////////////////////////////////////



   #endasm
 
   /* Habilita a interrup�ao do timer */
   #asm
      MOVLW 0xC0
      MOVWF 0x0B
   #endasm


   /* Habilita a interrup�ao do timer */
   //enable_interrupts(INT_RTCC);
   //enable_interrupts(GLOBAL);



   /* Coloca PORTB em pull up*/
   port_b_pullups(TRUE);

   /* Inicializa a tarefa dos comandos */
   CmdInicia();

   /* Inicializa as portas de io */
   IoInicia();

   /* Inicializa a tarefa de atendimento a chamadas */
   ChmInicia();

   /* Inicia a tarefa de monitoramento da entrada */
   InpInicia();

   /* Inicia a tarefa do power safe */
   PwrInicia();

   /* Configura o watchdog */
   setup_wdt(WDT_2304MS);

   /* Marca que o numero digitado nao vai ser gravado */
   AlteraDisc=FALSE;

   /* Seta o asterisco n�o digitado */
   AstDigitado=FALSE;


   SomAtiv=TRUE;   
}
