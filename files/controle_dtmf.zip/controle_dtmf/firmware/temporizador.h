
/* Prot�tipos */
void TmpInicia();
void TmpRefresh();
short TmpInclui(int Estado,int Dia,int Hora,int Minuto,int Port);

