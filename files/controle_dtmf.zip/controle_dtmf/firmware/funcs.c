
/**************************************************/
/*                                                */
/* funcs.c                                        */
/*                                                */
/* Fun��es                                        */
/*                                                */
/**************************************************/






/**************************************************/
/*                                                */
/* write_eeprom_func() - Substitui o write_eeprom */
/*                                                */
/**************************************************/
int read_eeprom_func(int End)
{
   return(read_eeprom(End));
}


void delay200()
{
   delay_ms(200);
}



/**************************************************/
/*                                                */
/* write_eeprom_func() - Substitui o write_eeprom */
/*                                                */
/**************************************************/
void write_eeprom_func(int End,int Valor)
{
   write_eeprom(End, Valor);
   delay_ms(10);

}
