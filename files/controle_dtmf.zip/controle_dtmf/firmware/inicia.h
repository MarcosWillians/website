


/* Endere�os de registros */
#define TRIPORTA 0x85
#define TRIPORTB 0x86
#define PORTA    0x05
#define PORTB    0x06
#define CMCON    0x1F
#define PIE1     0x8C
#define STATUS   0x03
#define OPTION   0x81
#define INTCON   0x0B
#define T1CON    0x10
#define PIR1     0x0C 
#define TMR1L    0x0E
#define TMR1H    0x0F


/* Endere�os de bits */
#define RP0       5
#define TMR1IF    0
#define TMR1ON    0






     
   
