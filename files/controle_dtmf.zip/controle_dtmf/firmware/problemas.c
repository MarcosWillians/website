TimeCont=251;

Seta timeout:
TimeOut[Watchdog]=253 (251+2)

programa trava por causa do som por 1s

Timecont=Timecont + 10 (1s) = 6 (251 + 10)

No RetTimeout Timecont<TimeOut[Watchdog]  (6<253) ou seja retorna falso para timeout erroneamente

e assim vai ser ate 253, porem como � muito tempo, da resset do watchdog

e outras tarefas tb podem demorar muito tempo para serem executadas novamente

para resolver isso o ideal � travar o contador de tempo qdo o processador estiver ocupado por muito tempo


--------------------------------------------------------------------------------------------------------
02/06

1) Algumas vezes o telefone toca mas o circuito nao atende
   -???
   
3) O tom dfmf por algumas vezes n�o � reconhecido
   -Melhorar o ganho do amplificador de entrada do mt8870


4) O teste para ver se a porta est� ligada ou desligada n�o est� funcionando
   -Mudar o algoritmo.
