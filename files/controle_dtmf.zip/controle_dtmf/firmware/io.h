/**************************************************/
/*                                                */
/* io.h                                           */
/*                                                */
/* -Controle das portas de entrada/saida          */
/*                                                */
/**************************************************/


#define PORTA_1 1
#define PORTA_2 2
#define PORTA_3 3

#define DESLIGA  0
#define LIGA     1
#define VERIFICA 2
#define PULSA    3

void IoInicia();
void IoStatus(int Port,int Acao);
