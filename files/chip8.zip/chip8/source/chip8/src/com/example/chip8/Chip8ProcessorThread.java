package com.example.chip8;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.util.Random;

import android.os.Environment;
import android.view.SurfaceHolder;

public class Chip8ProcessorThread extends Thread {

	
	VideoThread VideoThread1;
	AudioThread AudioThread1;
	TimerThread TimerThread1;
	
	byte [] Program = new byte[4096];
	
	private SurfaceHolder sh;
	
	byte x = 20;
	byte y = 12;
	
	int [] STACK = new int[16];
	
	byte [] V = new byte[16];
	
	byte SP = 0;
	
	
	
	byte Key = (byte) 0xff;
	
	int I;
	
	boolean fatalerror = false;
	
	int PC = 0x200; // Contador de programa iniciando em 0x200, correspondente ao in�cio da maioria dos programas
	
	boolean ProgramLoaded = false;
	
	// Construtor
	Chip8ProcessorThread(SurfaceHolder surfaceHolder)
	{
		// Recebe o surfaceholder para a manipula��o da surface pela thread  
	    sh = surfaceHolder;
	    
	    // Instancia o objeto de thread espec�fico estendido da thread padr�o
	 	// o surfaceholder, utilizado para o acesso e controle a surface view � passado para a thread
	 	VideoThread1 = new VideoThread(sh);
	 			
	 	// Inicializa a Thread
	 	VideoThread1.start();		
	 	
	 	// Instancia o objeto de gera��o de efeitos sonoros
	 	AudioThread1 = new AudioThread();
	 	
	    // Inicializa a Thread 
	 	AudioThread1.start();
	 	
	 	// Instancia o objeto de timer
	 	TimerThread1 = new TimerThread();
	 	
	 	// Inicializa a Thread
	 	TimerThread1.start();
	 	
	}
	
	
	public void run() {
		
		try {
			
			while(true)
			{
				sleep(3);				
				KeyboardProcess();
				Chip8task();
			}
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	// Tamanho da tela
	public void setSurfaceSize(int width, int height) {
		
		VideoThread1.setSurfaceSize(width, height);
	}
	
	// Recebe a posi��o do toque na tela e verifica
	public void SetTouchPos(float x,float y)
	{
		VideoThread1.SetTouchPos(x,y);
	}
	
	public void SetTouchUp()
	{
		VideoThread1.SetTouchUp();
	}
	
	
	private void FillDigitsFonts()
	{
		int i = 0;
		
		Program[i++] = (byte) 0xF0; // Digito 0 
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0; 
		Program[i++] = (byte) 0x20; // Digito 1 
		Program[i++] = (byte) 0x60;
		Program[i++] = (byte) 0x20;
		Program[i++] = (byte) 0x20;
		Program[i++] = (byte) 0x70;
		Program[i++] = (byte) 0xF0; // Digito 2  
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xF0; // Digito 3  
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x90; // Digito 4 
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0xF0; // Digito 5 
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xF0; // Digito 6  
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xF0; // Digito 7  
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0x20;
		Program[i++] = (byte) 0x40;
		Program[i++] = (byte) 0x40;
		Program[i++] = (byte) 0xF0; // Digito 8 
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xF0; // Digito 9  
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0;		
		Program[i++] = (byte) 0x10;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xF0; // Digito A 
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xE0; // Digito B 
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xE0;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xE0;
		Program[i++] = (byte) 0xF0; // Digito C  
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xE0; // Digito D  
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0x90;
		Program[i++] = (byte) 0xE0;
		Program[i++] = (byte) 0xF0; // Digito E 
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0xF0; // Digito F 
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0xF0;
		Program[i++] = (byte) 0x80;
		Program[i++] = (byte) 0x80;	
	}
	
	
	
	
	// Processa as a��es e reconhecimento de entrada do teclado
	private void KeyboardProcess()
	{
		if(VideoThread1.FileSelected == true)
		{
			// Indica que o arquivo j� foi lido
			VideoThread1.FileSelected = false;
						
			// Pega o arquivo de texto
	        File file = new File(Environment.getExternalStorageDirectory().toString()+"/chip8",VideoThread1.FileRom);

	        byte [] buffer = new byte[4096];
	        
	        try {
	            BufferedInputStream buf = new BufferedInputStream(new FileInputStream(file));
	            buf.read(buffer, 0, buffer.length);
	            buf.close();
	            	
	            // Preenche os sprites dos d�gitos na mem�ria de programa
	    	 	FillDigitsFonts();
	            
				// Desloca o buffer 0x200 bytes para cima, pois nessa posi��o come�am os programas chip8
				int i;
				for(i=0;i<3584;i++)
				{
					Program[512+i] = buffer[i];
				}
				
				// Aponta o contador de programa para a �rea do programa
				PC = 0x200;
				
				for(i=0;i<16;i++)
				{
					STACK[i]=0;
					V[i]=0;
				}
				
				I = 0;
				SP = 0;
				
				
				VideoThread1.ClearScreen();
				
				ProgramLoaded =true;
	        } catch (FileNotFoundException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        } catch (IOException e) {
	            // TODO Auto-generated catch block
	            e.printStackTrace();
	        }
		}  
			
		
	        /*
	        
	        //Read text from file
	        StringBuilder text = new StringBuilder();
	        
	        BufferedReader br = null;
			try {
				br = new BufferedReader(new FileReader(file));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}  
	       
	        char[] buffer = new char[4096];
	        char[] bufferaux = new char[4096];
	       	
	        
	        try {
	        		// Copia o arquivo para o buffer
					br.read(buffer);
				   
				
					char[] auxbuffer = new char[4096];
		       	
					// Desloca o buffer 0x200 bytes para cima, pois nessa posi��o come�am os programas chip8
					int i;
					for(i=0;i<3584;i++)
					{
						auxbuffer[512+i] = buffer[i];
					}
					
					
					Program = Charset.forName("ASCII").encode(CharBuffer.wrap(auxbuffer)).array();
					ProgramLoaded =true;
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		
		*/
	
	}
	
	// Processa a m�quina chip8
	private void Chip8task()
	{
		
		// S� processa o programa se estiver carregado
		if(ProgramLoaded == false)
		{
			return;
		}
		
	
		byte opcode1;
		byte inst_hi;
		byte inst_low;
		byte aux1;
		byte aux2;
		byte aux3;		
		int i;
		byte[][] Sprite = new byte[8][16];
		
		
		inst_hi = Program[PC];
		inst_low = Program[PC+1];
				
		opcode1 = (byte) ((byte) (inst_hi >> 4) & (byte)0x0f);
		
		
		
		switch(opcode1)
		{
			case 0:
			{
				switch(inst_low)
				{
					// 00E0 - CLS - Limpa a tela
					case (byte) 0x0E:
					{
						VideoThread1.ClearScreen();
						PC = PC + 2;
					break;	
					}
					
					// 00EE - RET - Retorna de uma subrotina, carregando o valor do contador de programa com o valor apontado pela pilha
					case (byte) 0xEE:
					{
						
						
						if(SP>0)
						{	
							SP--;
							
							PC = STACK[SP];
							
							PC = PC + 2;
						}
						else
						{
							// Erro de consumo indevido da pilha
							fatalerror = true;
						}	
						
						
					break;	
					}
				}
				
				break;
			}
			
			// 1nnn - JP - Salta para a posi��o indicada nnn
			case 1:
			{
				// Desloca o contador de programa para a posi��o indicada
				aux1 = (byte) (inst_hi & 0x0F);
				PC = (int)((int)aux1 << 8) | (int)((int)inst_low & 0x00FF);
								
				break;
			}
			
			// 2nnn - CALL - Salva o contador de programa na pilha e chama uma subrotina numa posi��o nnn
			case 2:
			{
				// Adianta uma posi��o da pilha
				if(SP<16)
				{	
					// Salva o contador de programa na pilha
					STACK[SP] = PC;
					SP++;					
				}
				else
				{
					// Estouro da pilha
					fatalerror = true;
				}
								
				// Desloca o contador de programa para a posi��o indicada
				aux1 = (byte) (inst_hi & 0x0F);				
				PC = (int)((int)aux1 << 8) | (int)((int)inst_low & 0x00FF);
				
				
				
				break;
			}
			
			// 3xkk - SE - Pula a pr�xima instru��o se Vx == kk
			case 3:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
								
				// Pula a pr�xima instru��o se Vx == kk
				if(V[aux1]==inst_low)
				{
					PC = PC + 4;
				}
				else
				{
					PC = PC + 2;
				}
				
				break;
			}
			
			// 4xkk - SEN - Pula a pr�xima instru��o se Vx != kk
			case 4:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
								
				// Pula a pr�xima instru��o se Vx == kk
				if(V[aux1]!=inst_low)
				{
					PC = PC + 4;
				}
				else
				{
					PC = PC + 2;
				}
								
				break;
			}
			
			// 5xy0 - SE - Pula a pr�xima instrucao se Vx == Vy
			case 5:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
				
				// Pega o �ndice y do vetor V
				inst_low = (byte) (inst_low >> 4);				
				aux2 = (byte) (inst_low & 0x0F);
								
				// Pula a pr�xima instru��o se Vx == kk
				if(V[aux1]==V[aux2])
				{
					PC = PC + 4;
				}
				else
				{
					PC = PC + 2;
				}
								
				
				break;
			}
			
			// 6xkk - LD Vx,byte - Vx = kk
			case 6:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
				
				// Salva o valor carregado em vx
				V[aux1] = inst_low;
				
				PC = PC + 2;
				
				break;
			}
			
			// 7xkk - ADD Vx, byte - Soma kk ao Vx, e armazena o resultado em Vx
			case 7:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
				
				V[aux1] = (byte) (V[aux1] + inst_low);	
				
				PC = PC + 2;
				
				break;
			}
			
			
			case 8:
			{
				aux3 = (byte) (inst_low & 0x0F);
				
				switch(aux3)
				{
					// 8xy0 - LD Vx, Vy - Carrega Vx com o valor de Vy
					case (byte)0:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Faz Vx = Vy
						V[aux1] = V[aux2];
						
						PC = PC + 2;
						
					break;
					}
					
					// 8xy1 - OR Vx, Vy - Faz a opera��o OR entre Vx e Vy. O resultado � armazenado em Vx
					case (byte)1:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Faz Vx = Vy OR Vx
						V[aux1] = (byte) (V[aux2] | V[aux1]);
						
						PC = PC + 2;
						
					break;
					}
					
					
					// 8xy2 - AND Vx, Vy - Faz a opera��o AND entre Vx e Vy. O resultado � armazenado em Vx
					case (byte)2:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Faz Vx = Vy AND Vx
						V[aux1] = (byte) (V[aux2] & V[aux1]);
						
						PC = PC + 2;
						
					break;
					}
					
					
					// 8xy3 - XOR Vx, Vy - Faz a opera��o XOR entre Vx e Vy. O resultado � armazenado em Vx
					case (byte)3:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Faz Vx = Vy XOR Vx
						V[aux1] = (byte) (V[aux2] ^ V[aux1]);
						
						PC = PC + 2;
						
					break;
					}
					
					// 8xy4 - ADD Vx, Vy - Soma Vx com Vy, o resultado � armazenado em Vx Carry em VF
					case (byte)4:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Faz Vx = Vy + Vx						
						V[aux1] = (byte) (V[aux2] + V[aux1]);
						
						// Se Vx + Vy for maior que Vx+Vy>=255 ent�o houve carry
						if(V[aux2] + V[aux1]>=255)
						{
							V[0x0F] = 1;
						}
						else
						{
							V[0x0F] = 0;
						}
						
						PC = PC + 2;
						
					break;
					}
					
					// 8xy5 - SUB Vx, Vy - Subtrai Vx de Vy, o resultado � armazenado em Vx se Vx>Vy VF=1
					case (byte)5:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Se Vx > Vy, VF=1
						if(V[aux1] > V[aux2])
						{							
							V[0x0F] = 1;
						}
						else
						{							
							V[0x0F] = 0;
						}
						
						// Faz Vx = Vx - Vy						
						V[aux1] = (byte) (V[aux1] - V[aux2]);
						
						PC = PC + 2;
						
					break;
					}
					
					// 8xy6 - SHR Vx - Deslocamento � direita , o bit menos significativo � transformado em VF
					case (byte)6:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Verifica o bit que ser� deslocado e seta VF
						if((V[aux1] & 0x01) == 1)
						{
							V[0x0F] = 1;
						}
						else
						{
							V[0x0F] = 0;
						}
												
						// Desloca para a direita e armazena em Vx
						V[aux1] = (byte) (V[aux1] >> 1);
						
						PC = PC + 2;
						
					break;
					}
					
					case (byte)7:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Pega o �ndice y do vetor V
						inst_low = (byte) (inst_low >> 4);				
						aux2 = (byte) (inst_low & 0x0F);
						
						// Se Vy > Vx, VF=1
						if(V[aux2] > V[aux1])
						{							
							V[0x0F] = 1;
						}
						else
						{							
							V[0x0F] = 0;
						}
						
						// Faz Vx = Vy - Vx						
						V[aux1] = (byte) (V[aux2] - V[aux1]);
						
						PC = PC + 2;
					break;
					}
					
					// 8xyE - SHL Vx - Faz o deslocamento � esquerda e armazena o resultado em Vx
					case (byte)0x0E:
					{						
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Verifica o bit que ser� deslocado e seta VF
						if((V[aux1] & 0x80) == 1)
						{
							V[0x0F] = 1;
						}
						else
						{
							V[0x0F] = 0;
						}
												
						// Desloca para a esquerda e armazena em Vx
						V[aux1] = (byte) (V[aux1] << 1);
						
						PC = PC + 2;
					break;
					}
					
				}
				
				break;
			}
			
			
			// 9xy0 - SEN - Pula a pr�xima instrucao se Vx != Vy
			case 9:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
							
				// Pega o �ndice y do vetor V
				inst_low = (byte) (inst_low >> 4);				
				aux2 = (byte) (inst_low & 0x0F);
											
				// Pula a pr�xima instru��o se Vx == kk
				if(V[aux1]!=V[aux2])
				{
					PC = PC + 4;
				}
				else
				{
					PC = PC + 2;
				}
											
							
				break;
			}
			
			
			// Annn - LD I, addr - Carrega o registrador I com nnn
			case 10:
			{
				// Carrega I com a posi��o indicada
				aux1 = (byte) (inst_hi & 0x0F);
				I = (int)((int)aux1 << 8) | (int)((int)inst_low & 0x00FF);
					
				PC = PC + 2;
				
				break;
			}
			
			
			// Bnnn - JP V0, addr - Desloca o contador de programa para a posi��o mmm + V0
			case 11:
			{
				// Desloca o contador de programa para a posi��o indicada
				aux1 = (byte) (inst_hi & 0x0F);
				PC = (int)((int)aux1 << 8) | (int)((int)inst_low & 0x00FF);
				PC = PC + V[0];
				
				break;
			}
			
			
			// Cxkk - RND Vx, byte - Cria um numero aleatorio, faz a sua AND com kk e armazena em Vx
			case 12:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
											
				// Cria um n�mero aleat�rio entre 0 e 255
				Random r = new Random();
				byte randomnumber = (byte) (r.nextInt(255));
				
				V[aux1] = (byte) (inst_low & randomnumber);
				
				PC = PC + 2;
								
				break;
			}
			
			// Dxyn - DRW Vx, Vy, nibble - Mostra n bytes do Sprite na posi��o Vx
			case 13:
			{
				// Pega o �ndice x do vetor V
				aux1 = (byte) (inst_hi & 0x0F);
				
				// Pega o n
				aux3 = (byte) (inst_low & 0x0F);
								
				// Pega o �ndice y do vetor V
				inst_low = (byte) (inst_low >> 4);				
				aux2 = (byte) (inst_low & 0x0F);
								
				// Copia o Sprite que ser� desenhado				
				for(i=0; i<aux3;i++)
				{
					// Testa o bit 0
					if((Program[i+I] & 0x01) == 0x01)
					{
						Sprite[7][i] = 1;
					}
					else
					{
						Sprite[7][i] = 0;
					}
										
					// Testa o bit 1
					if((Program[i+I] & 0x02) == 0x02)
					{
						Sprite[6][i] = 1;
					}
					else
					{
						Sprite[6][i] = 0;
					}
										
					// Testa o bit 2
					if((Program[i+I] & 0x04) == 0x04)
					{
						Sprite[5][i] = 1;
					}
					else
					{
						Sprite[5][i] = 0;
					}
										
					// Testa o bit 3
					if((Program[i+I] & 0x08) == 0x08)
					{
						Sprite[4][i] = 1;
					}
					else
					{
						Sprite[4][i] = 0;
					}
										
					// Testa o bit 4
					if((Program[i+I] & 0x10) == 0x10)
					{
						Sprite[3][i] = 1;
					}
					else
					{
						Sprite[3][i] = 0;
					}
										
					// Testa o bit 5
					if((Program[i+I] & 0x20) == 0x20)
					{
						Sprite[2][i] = 1;
					}
					else
					{
						Sprite[2][i] = 0;
					}
										
					// Testa o bit 6
					if((Program[i+I] & 0x40) == 0x40)
					{
						Sprite[1][i] = 1;
					}
					else
					{
						Sprite[1][i] = 0;
					}
										
					// Testa o bit 7
					if((Program[i+I] & 0x80) == 0x80)
					{
						Sprite[0][i] = 1;
					}
					else
					{
						Sprite[0][i] = 0;
					}
						
				}
				
				// Dispara o desenho do sprite
				V[0x0F] = VideoThread1.DrawSprite(Sprite, V[aux1], V[aux2], aux3);
				
				
				
				PC = PC + 2;
								
				break;
			}
			
			case 14:
			{
				switch(inst_low)
				{
					// Ex9E - SKP Vx - Pula a pr�xima instru��o se a tecla Vx estiver pressionada
					case (byte) 0x9E:
					{	
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Verifica se a tecla est� pressionada
						if(VideoThread1.VerifiyKeyPressed(V[aux1])==1)
						{
							PC = PC + 4;
						}
						else
						{
							PC = PC + 2;
						}
				
						
						break;
					}
					
					// ExA1 - SKNP Vx - Pula a pr�xima instru��o se a tecla Vx n�o estiver pressionada
					case (byte) 0xA1:
					{	
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Verifica se a tecla est� pressionada
						if(VideoThread1.VerifiyKeyPressed(V[aux1])==0)
						{
							PC = PC + 4;
						}
						else
						{
							PC = PC + 2;
						}
						
						break;						
					}
				
				}
				
			//	VerifiyKeyPressed
				
				break;
			}
			
			case 15:
			{
				switch(inst_low)
				{
				
					//Fx07 - LD Vx, DT - Carrega o valor de DT em VX
					case (byte)0x07:
					{
						
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Carrega o timer DT em Vx
						V[aux1] = TimerThread1.GetDelayTimer();
						
						PC = PC + 2;
						
						break;
					}
					
					// Fx0A - LD Vx, K - Espera uma tecla ser pressionada, grava o valor da tecla em Vx
					case (byte) 0x0A:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Verifica se alguma tecla foi pressionada, caso contr�rio, se mantem processando
						// Caso contr�rio o contador de programa mantem o mesmo valor travando o programa nessa posicao
						if(VideoThread1.VerifyKeyboard() == 1)
						{
							for(aux3=0;aux3<16;aux3++)
							{
								// Caso tenha encontrado a tecla, a armazena em Vx
								if(VideoThread1.VerifiyKeyPressed(aux3) == 1)
								{
									V[aux1] = aux3;
								}
							}
						}
						
						break;
					}
					
					// Fx15 - LD DT, Vx - Carrega o delay timer com Vx
					case (byte) 0x15:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Seta o delay timer com Vx
						TimerThread1.SetDelayTimer(V[aux1]);	
						
						PC = PC + 2;
						
					break;
					}
					
					 
					// Fx18 - LD ST, Vx - Seta o timer de som com Vx
					case (byte) 0x18:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Seta o timer de som com Vx
						AudioThread1.SetSoundTimer(V[aux1]);
						
						PC = PC + 2;
						
						break;
					}
					
					
					// Fx1E - ADD I, Vx - Soma Vx com I, e armazena o resultado em I
					case (byte) 0x1E:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Incrementa I com Vx
						I = I + V[aux1];
						
						PC = PC + 2;
						
						break;
					}
					
					
					// Fx29 - LD F, Vx - Carrega I com o endere�o referente ao Sprite do d�gito de 0 a F, conforme o valor de Vx
					case (byte) 0x29:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Carrega o endere�o do Sprite do d�gito de 0 a F conforme o valor de Vx
						I = V[aux1] * 5;	
						
						PC = PC + 2;
						
						break;
					}
					
					// Fx33 - LD B, Vx - Salva o correspondente BCD do valor em Vx, na posi��o de mem�ria I, I+1 e I+2
					case (byte) 0x33:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Salva a centena
						aux2 = (byte) (V[aux1] / 100);
						
						// Grava o valor BCD na mem�ria
						Program[I] = aux2;
						
						
						// Salva a dezena
						aux2 = (byte) (aux2*100); 
						aux3 = (byte) ((V[aux1] - aux2) / 10);
						
						// Grava o valor BCD na mem�ria
						Program[I+1] = aux3;
						
						
						// Salva a unidade
						aux3 = (byte) (aux3*10);
						aux2 = (byte) (Program[I]*100);
						aux3 = (byte) (V[aux1] - aux2 - aux3);
												
						// Grava o valor BCD na mem�ria
						Program[I+2] = aux3;
						
						PC = PC + 2;
														
						break;
					}
					
					
					// Fx55 - LD [I], Vx - Grava os valores de V0 a Vx come�ando no endere�o I
					case (byte) 0x55:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Copia 
						for(i=0;i<aux1;i++)
						{
							Program[I+i] = V[i];
						}
						
						PC = PC + 2;
						
						break;
					}
					
					// Fx65 - LD Vx, [I] - Grava os valores da me�ria a partir da posi��o I em V0 a Vx
					case (byte) 0x65:
					{
						// Pega o �ndice x do vetor V
						aux1 = (byte) (inst_hi & 0x0F);
						
						// Copia 
						for(i=0;i<aux1;i++)
						{
							V[i] = Program[I+i];
						}
						
						PC = PC + 2;
					}
					
				}
				
				
				break;
			}
		}
		
		
	
		
		/*
		 byte[][] Sprite = new byte[8][16]; 
		
		
		
        Sprite[0][1] = 1; 
        Sprite[0][2] = 1; 
        Sprite[0][3] = 1; 
        Sprite[0][4] = 1; 
        Sprite[1][0] = 1; 
        Sprite[1][2] = 1; 
        Sprite[2][0] = 1; 
        Sprite[2][2] = 1; 
        Sprite[3][1] = 1; 
        Sprite[3][2] = 1; 
        Sprite[3][3] = 1; 
        Sprite[3][4] = 1; 
        
        
        if(x<63)
        {
        	x++;
        }
        else
        {
        	x=0;
        	if(y<31)
        	{
        		y++;
        	}
        	else
        	{
        		y=0;
        	}        	
        }
        VideoThread1.ClearScreen();
        if(VideoThread1.DrawSprite(Sprite, x, y, (byte)5)==1)
        {
        //	AudioThread1.SetSoundTimer((byte)30);
        }
        
	}
	*/
	}
	
}
