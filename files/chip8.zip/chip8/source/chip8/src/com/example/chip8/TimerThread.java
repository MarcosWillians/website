package com.example.chip8;

public class TimerThread extends Thread {
	
	  private byte DT;
	
	  // Construtor
	  TimerThread()
	  {
		  
	  }
	  
	  public void SetDelayTimer(byte dt)
	  {
		  DT = dt;
	  }
	
	  public byte GetDelayTimer()
	  {
		  return(DT);
	  }
	  
	  
	  // Execu��o da Thread run() � uma funcao nativa
	  public void run() {
		  
		  try {
			
			  while(true)
			  {
			  
				  if(DT>0)
				  {
					  DT--;
				  }
				  sleep(16);
			  }
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		  
		  
	  }
}
