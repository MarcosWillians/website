package com.example.chip8;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.os.Build;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Path.Direction;
import android.view.View.OnTouchListener;

public class Chi8Activity extends ActionBarActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {        
        super.onCreate(savedInstanceState);
        
        // Determina o conte�do da view como uma SurfaceView
        setContentView(new SurfaceView1(this));
        
        
        /*
          
        //Get the text file
        File file = new File("/storage/extSdCard","file.txt");

        //Read text from file
        StringBuilder text = new StringBuilder();
        
        BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(file));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
        String line;   
        try {
			while ((line = br.readLine()) != null) {
			            text.append(line);
			            Log.i("Test", "text : "+text+" : end");
			            text.append('\n');
			            }
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
		*/
        
        
        String path = Environment.getExternalStorageDirectory().toString()+"/chip8";
        Log.d("Files", "Path: " + path);
        File directory = new File(path);
        File[] files = directory.listFiles();
        Log.d("Files", "Size: "+ files.length);
        for (int i = 0; i < files.length; i++)
        {
            Log.d("Files", "FileName:" + files[i].getName());
        }
        
        
        
    }
    
    
    
    
    ///////////////////////////////////////////////////////////////////////////////////
    // Classe da SurfaceView - View para o desenho dos gr�ficos                      //
    ///////////////////////////////////////////////////////////////////////////////////
    public class SurfaceView1 extends SurfaceView   
	implements SurfaceHolder.Callback{
	
	    private SurfaceHolder sh;
		
		Chip8ProcessorThread Chip8ProcessorThread1;
		
		float x,y;
		
		// Construtor
		public SurfaceView1(Context context) {
		super(context);
		
			// Retorna a surface holder, dando acesso e controle a SurfaceView
			sh = getHolder();
			
			// Adiciona uma interface de callback para essa holder
			sh.addCallback(this);	
			
			// Habilita o click longo para permitir que o evento de touch up ocorra
			this.setLongClickable(true);
			
		}
		
		@Override
		public boolean onTouchEvent(MotionEvent event) {
			// TODO Auto-generated method stub
			
		    int action = event.getActionMasked();
		    
		  		    
		    switch (action) {
		 
		        case MotionEvent.ACTION_DOWN:
		            x = event.getX();
		            y = event.getY();
		            Chip8ProcessorThread1.SetTouchPos(x,y);
		           
		            break;  
		        
		        case MotionEvent.ACTION_POINTER_UP:
		        case MotionEvent.ACTION_UP:
		        case MotionEvent.ACTION_CANCEL:
		        	Chip8ProcessorThread1.SetTouchUp();
		        	break;
		    }
		    
		 		    	
		    return super.onTouchEvent(event);					
		}
		
		
		// Chamado imediatamente ap�s a surface ser criada a primeira vez
		public void surfaceCreated(SurfaceHolder holder) {
				
			// Instancia a maquina chip8
			Chip8ProcessorThread1 = new Chip8ProcessorThread(sh);
			
			// Inicializa  a m�quina
			Chip8ProcessorThread1.start();		
		}
		
		// Chamado se a tela sofre mudan�as de formato ou tamanho
		public void surfaceChanged(SurfaceHolder holder, int format, int width,
		int height) {
						
			if(width>height)
			{				
				Chip8ProcessorThread1.setSurfaceSize(width, height);
			}
			else
			{
				finish();
			}
				
		}
		
		// Chamado quando a surface � fechada
		public void surfaceDestroyed(SurfaceHolder holder) {
		// boolean retry = true;
	
		
		// P�ra a thread (novo testar)
		Chip8ProcessorThread1.interrupt();
		
		/*
		while (retry) 
		{
			try {
			
				Chip8ProcessorThread1.join();
					
				    retry = false;
			 	} catch (InterruptedException e) {
			 	}
			 }
			 */		}
		
	
    }

}
