package com.example.chip8;

import java.io.File;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Typeface;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Environment;
import android.os.Handler;
import android.util.Log;
import android.view.SurfaceHolder;

public class VideoThread extends Thread{
	

			  private int canvasWidth = 200;
			 
			  private int canvasHeight = 400;
			 			  
			  private SurfaceHolder sh1;
			  
			  private final Paint paint1 = new Paint(Paint.ANTI_ALIAS_FLAG);
			  
			  private final Paint paintbuttons = new Paint(Paint.ANTI_ALIAS_FLAG);
			  
			  private final Paint paintpixelon = new Paint();
			  
			  private final Paint paintpixeloff = new Paint();
			  
			  private File[] files;
			  
			  private char buttonpressed;
			  
			  private int pointerselectfile = 0;
			  
			  public String FileRom;
			  
			  public boolean FileSelected = false;
			 					 
			  private int contdrawscreen = 80;
			  
			  private byte[][] Screen = new byte[64][32];
			  
			  // Construtor
			  public VideoThread(SurfaceHolder surfaceHolder) {
				// Recebe o surfaceholder para a manipula��o da surface pela thread  
			    sh1 = surfaceHolder;
			    
			    // Monta o caminho para o diret�rio das ROMs
			    String path = Environment.getExternalStorageDirectory().toString()+"/chip8";
		    
			    // Acessa o diret�rio chip8 na raiz
		        File directory = new File(path);
		        
		        // Captura a lista de arquivos
		        files = directory.listFiles();
		      	      	      
		        // Inicializa limpando a tela
		        ClearScreen();
		        
		        /*
		      
		        byte[][] Sprite = new byte[8][16]; 
		        		
		        		
		        		
		        Sprite[0][1] = 1; 
		        Sprite[0][2] = 1; 
		        Sprite[0][3] = 1; 
		        Sprite[0][4] = 1; 
		        Sprite[1][0] = 1; 
		        Sprite[1][2] = 1; 
		        Sprite[2][0] = 1; 
		        Sprite[2][2] = 1; 
		        Sprite[3][1] = 1; 
		        Sprite[3][2] = 1; 
		        Sprite[3][3] = 1; 
		        Sprite[3][4] = 1; 
		        */
		        
		       // DrawSprite(Sprite, (byte)61, (byte)17, (byte)15);
		       
		       
		      //  DrawSprite(Sprite, (byte)15, (byte)6, (byte)5);
		        
		        
		      //  DrawSprite(Sprite, (byte)15, (byte)14, (byte)5);
		        
		       
			  }
			 
			  
			  // Execu��o da Thread run() � uma funcao nativa
			  public void run() {
				  
				  // Loop principal da thread
				  while (true) {
			      Canvas c = null;
			      try {		    	  
			    	  	// Retorna o canvas usado nessa surface
			    	  	c = sh1.lockCanvas(null);
			    	  	
			    	  	// Se a vari�vel sh que � o surfaceholder estiver liberada utiliza
			    	  	synchronized (sh1) {		    	  		
			    	  		// Dispara o desenho
			    	  		doDraw(c);
			    	  		try {
								sleep(10);
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			    	  	}
			      } finally {
			        if (c != null) {
			          sh1.unlockCanvasAndPost(c);
			        }
			      }
			    }
			  }
			  
			  // Indica que o bot�o foi liberado
			  public void SetTouchUp()
			  {
				  buttonpressed = 'n';
				  contdrawscreen = 4;
			  }
			  
			  
			  
			  // Limpa a tela para desenhar novamente
			  public void ClearScreen()
			  {
				  int x,y;
				  byte tog = 0;
				  
				  for(x=0;x<64;x++)
				  {
					  for(y=0;y<32;y++)
					  {
						  
						Screen[x][y] = 0;
						 
					  }				  
					 
				  }	
				  
				  contdrawscreen = 4;
			  }
			  
			  
			  // Desenha um sprite na tela e retorna 1 se houver colis�o
			  byte DrawSprite(byte [][]Sprite, byte Xpos, byte Ypos, byte N)
			  {
				  int x,y;
				  
				  // Indica que por enquanto n�o houve nenhuma sobreposi��o de pixel em '1' 
				  // do sprite com outro pixel em '1' da pr�pria tela
				  byte VF = 0;
				  
				  
				  if(Xpos<0 || Ypos<0)
				  {
					  return 0;
				  }
				  
				  for(x=0;x<8;x++)
				  {
					  for(y=0;y<N;y++)
					  {
						  // Verifica se o pixel est� em '1' para ser desenhado
						  if (Sprite[x][y] == 1) 
						  {
							  if((x+Xpos<64) && (y+Ypos<32))
							  {							  
								  // Se o referido pixel da tela tamb�m est� em '1' houve uma colis�o
								  // e VF � setado. Nesse caso, uma opera��o XOR � feita e o pixel �
								  // setado para o valor '0'
								  if(Screen[x+Xpos][y+Ypos]==1)
								  {
									  // Colis�o de pixel em '1' do sprite com o pixel em '1' da tela
									  VF = 1;
								  
									  // Limpa o pixel da tela em que ocorreu a colis�o
									  Screen[x+Xpos][y+Ypos] = 0;
								  }
								  else
								  {
									  // Se o pixel da tela est� apagado ent�o liga o pixel
									  Screen[x+Xpos][y+Ypos] = 1;
								  }
							  }
						  }						  
					  }
				  }
				  
				  contdrawscreen = 4;
				  
				  return VF;
			  }
			  
			  // Recebe a posi��o do toque na tela e verifica
			  public void SetTouchPos(float x,float y)
			  {
				  float xverify;
				  float yverify;
				  
				  int columm = 5;
				  int row = 5;
				  
				  contdrawscreen = 4;
				 				  
				  buttonpressed = 'n';
				  
				  xverify = canvasWidth*0.6f;
				  
				  // Verifica se o teclado numerico foi pressionado
				  if(x>xverify)
				  {
					  xverify = xverify + canvasWidth * 0.095f;
					  if(x<xverify)
					  {
						  columm = 0;
					  }
					  
					  xverify = xverify + canvasWidth * 0.095f;
					  if((x<xverify) && (columm==5))
					  {
						  columm = 1;
					  }
					  
					  xverify = xverify + canvasWidth * 0.095f;
					  if((x<xverify) && (columm==5))
					  {
						  columm = 2;
					  }
					  
					  xverify = xverify + canvasWidth * 0.095f;
					  if((x<xverify) && (columm==5))
					  {
						  columm = 3;
					  }
					  
					  yverify = canvasHeight*0.275f;
					  if(y<yverify)
					  {
						  row = 0;
						  
						  switch(columm)
						  {
							  case 0:
							  {
								  buttonpressed = '1';
								  break;
							  }
							  
							  case 1:
							  {
								  buttonpressed = '2';
								  break;
							  }
							  
							  case 2:
							  {
								  buttonpressed = '3';
								  break;
							  }
							  
							  case 3:
							  {
								  buttonpressed = 'C';
								  break;
							  }
							  
						  }
						  
					  }
					  
					  yverify = yverify + canvasHeight * 0.225f;
					  if((y<yverify)&&(row==5))
					  {
						  row = 1;
						  
						  switch(columm)
						  {
							  case 0:
							  {
								  buttonpressed = '4';
								  break;
							  }
							  
							  case 1:
							  {
								  buttonpressed = '5';
								  break;
							  }
							  
							  case 2:
							  {
								  buttonpressed = '6';
								  break;
							  }
							  
							  case 3:
							  {
								  buttonpressed = 'D';
								  break;
							  }
							  
						  }
					  }
					  					  
					  yverify = yverify + canvasHeight * 0.225f;
					  if((y<yverify)&&(row==5))
					  {
						  row = 2;
						  
						  switch(columm)
						  {
							  case 0:
							  {
								  buttonpressed = '7';
								  break;
							  }
							  
							  case 1:
							  {
								  buttonpressed = '8';
								  break;
							  }
							  
							  case 2:
							  {
								  buttonpressed = '9';
								  break;
							  }
							  
							  case 3:
							  {
								  buttonpressed = 'E';
								  break;
							  }
							  
						  }
					  }
					  
					  yverify = yverify + canvasHeight * 0.225f;
					  if((y<yverify)&&(row==5))
					  {
						  row = 3;
						  
						  switch(columm)
						  {
							  case 0:
							  {
								  buttonpressed = 'A';
								  break;
							  }
							  
							  case 1:
							  {
								  buttonpressed = '0';
								  break;
							  }
							  
							  case 2:
							  {
								  buttonpressed = 'B';
								  break;
							  }
							  
							  case 3:
							  {
								  buttonpressed = 'F';
								  break;
							  }							  
						  }
					  }
				  }
				  else
				  {
					  xverify = canvasWidth*0.315f; 
					  columm = 3;
					  
					  // Verifica se o teclado de op��es de carregamento de roms foi pressionado
					  if(x>xverify && y>canvasHeight*0.70f )
					  {
						  xverify = xverify + canvasWidth * 0.095f;
						  if(x<xverify)
						  {
							  columm = 0;
							  buttonpressed = 'L';
						  }
						  
						  xverify = xverify + canvasWidth * 0.095f;
						  if((x<xverify) && (columm==3))
						  {
							  columm = 1;
							  buttonpressed = 'U';
						  }
						  
						  xverify = xverify + canvasWidth * 0.095f;
						  if((x<xverify) && (columm==3))
						  {
							  columm = 2;
							  buttonpressed = 'O';
						  }					 
						  
					  }
				  }
			  }
			 
			  
			  // Desenha o frame
			  private void doDraw(Canvas canvas) 
			  {
				float incxbuttons=0;
				float incybuttons=0;
				int x;
				int y;
				
				if(--contdrawscreen == 0)
				{
					contdrawscreen = 1;
					return;
				}
				
				
			    // Preenche o fundo da tela 
				canvas.restore();
			    canvas.drawColor(Color.BLACK);
			    
			    // Desenha as linhas de limite
			    paint1.setStrokeWidth(2);
			    canvas.drawLine(canvasWidth*0.98f, canvasHeight*0.05f, canvasWidth*0.02f, canvasHeight*0.05f, paint1);			    
			    canvas.drawLine(canvasWidth*0.6f, canvasHeight*0.05f, canvasWidth*0.6f, canvasHeight*0.95f, paint1);			    
			    canvas.drawLine(canvasWidth*0.02f, canvasHeight*0.95f, canvasWidth*0.98f, canvasHeight*0.95f, paint1);			    
			    canvas.drawLine(canvasWidth*0.98f, canvasHeight*0.95f, canvasWidth*0.98f, canvasHeight*0.05f, paint1);			    			    
			    canvas.drawLine(canvasWidth*0.02f, canvasHeight*0.05f, canvasWidth*0.02f, canvasHeight*0.95f, paint1);
			    canvas.drawLine(canvasWidth*0.6f, canvasHeight*0.725f, canvasWidth*0.02f, canvasHeight*0.725f, paint1);			    
			    
			    
			    // Bot�o 1
			    if(buttonpressed == '1')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }			    
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("1", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    // Bot�o 2
			    if(buttonpressed == '2')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f; 
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("2", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    // Bot�o 3
			    if(buttonpressed == '3')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("3", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    // Bot�o C
			    if(buttonpressed == 'C')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("C", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   	
			    
			    
			    
			    
			    // Bot�o 4
			    if(buttonpressed == '4')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = 0;			      
			    incybuttons = incybuttons + canvasHeight * 0.225f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("4", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   			    
			    // Bot�o 5
			    if(buttonpressed == '5')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("5", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   			    
			    // Bot�o 6
			    if(buttonpressed == '6')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("6", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    // Bot�o D
			    if(buttonpressed == 'D')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("D", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    
			    // Bot�o 7
			    if(buttonpressed == '7')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = 0;			      
			    incybuttons = incybuttons + canvasHeight * 0.225f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("7", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   			    
			    // Bot�o 8
			    if(buttonpressed == '8')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("8", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   			    
			    // Bot�o 9
			    if(buttonpressed == '9')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("9", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    // Bot�o E
			    if(buttonpressed == 'E')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("E", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    
			    // Bot�o A
			    if(buttonpressed == 'A')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = 0;			      
			    incybuttons = incybuttons + canvasHeight * 0.225f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("A", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   			    
			    // Bot�o 0
			    if(buttonpressed == '0')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("0", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   			    
			    // Bot�o B
			    if(buttonpressed == 'B')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("B", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    // Bot�o F
			    if(buttonpressed == 'F')
			    {
			    	paintbuttons.setStrokeWidth(4); 
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.6f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.695f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("F", incxbuttons + canvasWidth*0.64f, incybuttons + canvasHeight*0.18f, paintbuttons);
			   
			    
			    
			  
			    //Bot�o Load
			    if(buttonpressed == 'L')
			    {
			    	paintbuttons.setStrokeWidth(3); 
			    	
			    	if((files != null)&&(files.length>0)&&(pointerselectfile<files.length))
			    	{			    			
			    		FileRom = files[pointerselectfile].getName();
			    		FileSelected = true;			    					    		
			    	}
			    	
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = 0;
			    canvas.drawRect(incxbuttons + canvasWidth*0.315f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.41f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("Load", incxbuttons + canvasWidth*0.340f, incybuttons + canvasHeight*0.18f, paintbuttons);
				 
			    // Bot�o UP
			    if(buttonpressed == 'U')
			    {
			    	paintbuttons.setStrokeWidth(3); 
			    	if(pointerselectfile>0)
			    	{
			    		pointerselectfile--;
			    	}
			    	buttonpressed = 'n';
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.315f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.41f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("Up", incxbuttons + canvasWidth*0.346f, incybuttons + canvasHeight*0.18f, paintbuttons);
				
			    // Bot�o Down
			    if(buttonpressed == 'O')
			    {
			    	paintbuttons.setStrokeWidth(3); 
			    	pointerselectfile++;
			    	buttonpressed = 'n';
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    }	
			    incxbuttons = incxbuttons + canvasWidth * 0.095f;
			    canvas.drawRect(incxbuttons + canvasWidth*0.315f, incybuttons + canvasHeight*0.05f, incxbuttons + canvasWidth*0.41f,incybuttons + canvasHeight*0.275f, paintbuttons);
			    canvas.drawText("Down", incxbuttons + canvasWidth*0.340f, incybuttons + canvasHeight*0.18f, paintbuttons);
				
			    
			    if(files != null)
			    {
			    	if(files.length>0)
			    	{
			    		if(pointerselectfile>=files.length)
			    		{
			    			pointerselectfile = files.length - 1;
			    		}
			    		
			    		paintbuttons.setStrokeWidth(2);
		    			canvas.drawText(files[pointerselectfile].getName(), canvasWidth*0.05f,  canvasHeight*0.8f, paintbuttons);	
		    			paintbuttons.setTextSize(17f);
				    	canvas.drawText("Use Up and Down buttons", canvasWidth*0.05f,  canvasHeight*0.85f, paintbuttons);
				    	canvas.drawText("to choose another ROM", canvasWidth*0.05f,  canvasHeight*0.89f, paintbuttons);
				    	paintbuttons.setTextSize(20f);
			    		
			    		
			    	}
			    	else
			    	{
			    		paintbuttons.setStrokeWidth(2);
			    		paintbuttons.setTextSize(17f);
				    	canvas.drawText("No *.ch8 files found.", canvasWidth*0.05f,  canvasHeight*0.81f, paintbuttons);
				    	canvas.drawText("Copy *.ch8 files to", canvasWidth*0.05f,  canvasHeight*0.85f, paintbuttons);
				    	canvas.drawText("'/chip8' directory", canvasWidth*0.05f,  canvasHeight*0.89f, paintbuttons);
				    	paintbuttons.setTextSize(20f);
			    	}
			    }
			    else
			    {
			    	paintbuttons.setStrokeWidth(2);
			    	paintbuttons.setTextSize(17f);
			    	canvas.drawText("No found directory '/chip8'.", canvasWidth*0.05f,  canvasHeight*0.81f, paintbuttons);
			    	canvas.drawText("Create it in the root and put the", canvasWidth*0.05f,  canvasHeight*0.85f, paintbuttons);
			    	canvas.drawText("*.ch8 files inside", canvasWidth*0.05f,  canvasHeight*0.89f, paintbuttons);
			    	paintbuttons.setTextSize(20f);
			    }
			    
			    
			    float xbase = canvasWidth*0.04f;
			    float ybase = canvasHeight*0.13f;
			    float addbase = canvasHeight*0.017f;
			    
			    for(x=0;x<64;x++)
				{
			    	for(y=0;y<32;y++)
					{
			    		if(Screen[x][y]==1)
						{						  
			    			//canvas.drawRect(x*canvasHeight*0.005f + xbase, y*canvasHeight*0.005f + ybase, x*canvasHeight*0.01f + xbase , y*canvasHeight*0.01f + ybase, paintpixelon);
						
			    			canvas.drawPoint(x*addbase + xbase, y*addbase + ybase, paintpixelon);
						
						}	
			    		else
			    		{
			    			//canvas.drawRect(x*canvasHeight*0.005f + xbase, y*canvasHeight*0.005f + ybase, x*canvasHeight*0.01f + xbase , y*canvasHeight*0.01f + ybase, paintpixeloff);
			    			canvas.drawPoint(x*addbase + xbase, y*addbase + ybase, paintpixeloff);
			    		
			    		}
					}
				}
			    
			  }

			  public byte VerifyKeyboard()
			  {
				  if(buttonpressed!='n')
				  {
					  return(1);
				  }
				  
				  return(0);
			  }
			  
			  
			  public byte VerifiyKeyPressed(byte key)
			  {
				  switch(buttonpressed)
				  {
				  	case '0':
				  	{
				  		if(key == 0x00)
				  		{
				  			return 1;
				  		}	
				  		break;
				  	}
				  	
				  	case '1':
				  	{
				  		if(key == 0x01)
				  		{
				  			return 1;
				  		}	
				  		break;
				  	}
				  	
				  	case '2':
				  	{
				  		if(key == 0x02)
				  		{
				  			return 1;
				  		}	
				  		break;
				  	}
				  	
				  	case '3':
				  	{
				  		if(key == 0x03)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case '4':
				  	{
				  		if(key == 0x04)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	
				  	case '5':
				  	{
				  		if(key == 0x05)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case '6':
				  	{
				  		if(key == 0x06)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case '7':
				  	{
				  		if(key == 0x07)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case '8':
				  	{
				  		if(key == 0x08)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case '9':
				  	{
				  		if(key == 0x09)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case 'A':
				  	{
				  		if(key == 0x0A)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case 'B':
				  	{
				  		if(key == 0x0B)
				  		{
				  			return 1;
				  		}	
				  		break;
				  	}
				  	
				  	case 'C':
				  	{
				  		if(key == 0x0C)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case 'D':
				  	{
				  		if(key == 0x0D)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case 'E':
				  	{
				  		if(key == 0x0E)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}
				  	
				  	case 'F':
				  	{
				  		if(key == 0x0F)
				  		{
				  			return 1;
				  		}
				  		break;
				  	}			  	
				  	
				  }
				  
				  return 0;
			  }
			  
			  
			  
				
			 // Recebe o tamanho da surface utilizada		  
			  public void setSurfaceSize(int width, int height) {
			    synchronized (sh1) {
			      canvasWidth = width;
			      canvasHeight = height;
			      
			      paint1.setColor(Color.GREEN);
				  paint1.setStyle(Style.FILL);
				  
				  
				  paintbuttons.setColor(Color.GREEN);
				  paintbuttons.setStyle(Style.STROKE);
				  paintbuttons.setTextSize(20f);
				  
				  
				  paintpixelon.setColor(Color.GREEN);
				  paintpixelon.setStrokeWidth(canvasHeight*0.017f);
				  
				  paintpixeloff.setColor(Color.BLACK);
				  paintpixeloff.setStrokeWidth(canvasHeight*0.017f);
				  
			    }
			  }
			  
			  
			  
			  
				
				
			  
			  
			  
			  
			  
			  
		
			
}
