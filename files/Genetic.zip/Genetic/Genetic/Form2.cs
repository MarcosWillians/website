﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Genetic
{
    public partial class Form2 : Form
    {
        GenAlg gen1 = new GenAlg();

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            gen1.CreatePopulation(20, 130);

            gen1.Process(15, 0, (float)0.4, (float)0.05, FitCalculate);
        }

        public float FitCalculate(byte[] Gen)
        {
            return 0;
        }

    }
}
