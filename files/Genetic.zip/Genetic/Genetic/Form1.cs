﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Genetic
{
    public partial class Form1 : Form
    {
        GenAlg gen1 = new GenAlg();
        int xf = 310;
        int yf = 230;

     

        public Form1()
        {
            InitializeComponent();

            Form2 f2 = new Form2();

            f2.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DrawScreen();
        }



        public float FitCalculate(byte[] Gen)
        {
            int x,y;
            int xp,yp;
            int i;
            byte b;
            float distance;
            x = 0;
            xp = 0;
            yp = 0;
            y = 0;
            
            for (i = 0; i < Gen.Count(); i++)
            {
                b = Gen[i];

                if ((byte)(b & 0x0F) > 7)
                {
                    xp = x + (int)(b & 0x0F) - 8;
                }
                else
                {
                    xp = x - (int)(b & 0x0F);
                }

                b = (byte)(b >> 4);

                if ((byte)(b & 0x0F) > 7)
                {
                    yp = y + (int)(b & 0x0F) - 8;
                }
                else
                {
                    yp = y - (int)(b & 0x0F);
                }

                // Verifica se alguma condição de parada em relação ao retangulo da tela foi atingida
                if ((xp > 320) || (xp < 0) || (yp > 240) || (yp < 0))
                {
                    break;
                }

                // Verifica a condicao de parada em relação a primeira parede superior
                if ((xp > 100) && (xp < 120) && (yp < 120))
                {
                    break;
                }

                // Verifica a condicao de parada em relação a primeira parede superior
                if ((xp > 200) && (xp < 220) && (yp > 180))
                {
                    break;
                }

                // Verifica a condição de parada em relação ao ponto de chegada
                if ((xp > 310) && (yp > 230))
                {
                    return 100000;                  
                }

                x = xp;
                y = yp;
            }

            // ponto 1
            int dx = (xp - xf);
            int dy = (yp - yf);

            // ponto 2
           // int dx = (xp - 310);
           // int dy = (yp - 10);


            // Calcula a distância do ponto de parada ao ponto de chegada
            distance = dx * dx + dy * dy;//(float)Math.Sqrt(dx*dx+dy*dy);

            return (1000 / distance);
        }


        void DrawScreen()
        {
            int i,j;
            int x, y, xp, yp;
            byte b;

            // Apaga a tela
            Bitmap bitmap = new Bitmap(pictureBox1.Width, pictureBox1.Height);//Cria um novo bitmap com as dimensões de um pictureBox que existe no form, obeserver que pode ser qualquer controle, inclusive o próprio form
            Graphics graphics = Graphics.FromImage(bitmap);//Cria um objeto Graphics, esse objeto é usado para desenhar e pintar no bitmap
            graphics.FillRectangle(Brushes.White, 0, 0, bitmap.Width, bitmap.Height);
            pictureBox1.Image = bitmap;//faz com que o bitmap seja desenhado no pictureBox, se fosse outro controle a propriedade seria BackgroundImage.

            graphics.FillRectangle(Brushes.Blue, 5, 5, 20, 20);

            graphics.FillRectangle(Brushes.Red, xf , yf, 20, 20);

            graphics.FillRectangle(Brushes.Black, 100, 0, 20, 120);

            graphics.FillRectangle(Brushes.Black, 200, 180, 20, bitmap.Height-20);

            SolidBrush myBrush = new SolidBrush(Color.Green);
            Pen myPen = new Pen(myBrush);


            // Desenha as linhas de caminho
            int sizepop = gen1.GetPopulationSize();



            // Varre a lista de genótipos e plota a linha
            for(i=0;i<sizepop;i++)
            {
                byte[] genotype = gen1.GetGenAtpos(i);

                x = 0;
                y = 0;
                xp = 0;
                yp = 0;

                for (j = 0; j < genotype.Count(); j++)
                {
                    b = genotype[j];

                    if ((byte)(b & 0x0F) > 7)
                    {
                        xp = x + (int)(b & 0x0F) - 8;
                    }
                    else
                    {
                        xp = x - (int)(b & 0x0F);
                    }

                    b = (byte)(b >> 4);

                    if ((byte)(b & 0x0F) > 7)
                    {
                        yp = y + (int)(b & 0x0F) - 8;
                    }
                    else
                    {
                        yp = y - (int)(b & 0x0F);
                    }

                    // Verifica se alguma condição de parada em relação ao retangulo da tela foi atingida
                    if ((xp > 320) || (xp < 0) || (yp > 240) || (yp < 0))
                    {
                        break;
                    }

                    // Verifica a condicao de parada em relação a primeira parede superior
                    if ((xp > 100) && (xp < 120) && (yp < 120))
                    {
                        break;
                    }

                    // Verifica a condicao de parada em relação a primeira parede superior
                    if ((xp > 200) && (xp < 220) && (yp > 180))
                    {
                        break;
                    }

                    // Verifica a condição de parada em relação ao ponto de chegada
                    if ((xp > 310) && (yp > 230))
                    {
                        break; 
                    }

                    graphics.DrawLine(myPen, x, y, xp, yp);

                    x = xp;
                    y = yp;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {            
            gen1.CreatePopulation(20, 130);             
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
           
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            gen1.Process(15, 0, (float)0.4, (float)0.05, FitCalculate);

            label1.Text = "Maxfitness=" + gen1.GetMaxFitnessValue();

            DrawScreen();
          




            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Enabled = false;
        }


        


        public float FitnessCalculate(byte[] Gen)
        {
            int a, b, c;
            float ytest, yfunc, sumerro;
            int x;

            a = (int)Gen[0];
            b = (int)Gen[1];
            c = (int)Gen[2];

            sumerro = 0;

            // Para o máximo fitness o suposto programa deseja que b seja 50
            // Então b=49 tem um fitness mais baixo e o 51 também;

            int maxpointsfunc = 10;
            for (x = 0; x < maxpointsfunc; x++)
            {
                yfunc = 2 * x * x + 4 * x + 7;

                ytest = a * x * x + b * x + c;

                if (yfunc < ytest)
                {
                    sumerro = sumerro + (ytest - yfunc);
                }
                else
                {
                    sumerro = sumerro + (yfunc - ytest);
                }
            }

            sumerro = sumerro / maxpointsfunc;

            return ((float)1 / sumerro);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            xf = Int32.Parse(textBox1.Text);
            yf = Int32.Parse(textBox2.Text); 
        }
    }



  

    


}
