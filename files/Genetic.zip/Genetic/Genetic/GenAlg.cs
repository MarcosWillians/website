﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Genetic
{
    class GenAlg
    {
        List<Genotype> Population = new List<Genotype>();
        
        public class Genotype
        {
            public byte[] Gen;     // Genótipo
            public float Fitness;  // Aptidão para resolver o problema
            static private Random randNum = new Random();

            public Genotype(int SizeGen)
            {
                // Cria o gen com o tamanho definido
                Gen = new byte[SizeGen];

                // Atualiza o gen com valores aleatórios

                randNum.NextBytes(Gen);

                // Inicializa a aptidão
                Fitness = 0;
            }
        }

        // Ponteiro para a função do usuário a ser chamada para o cálculo da aptidão de cada indivíduo
        // A função chamada recebe o Gen do indivíduo e deve retornar o fitness
        public delegate float GenFitnessCalculate(byte[] Gen);
        
        // Cria uma população de genótipos. Recebe o tamanho da população, o tamanho do genótipo de cada indivíduo e
        public void CreatePopulation(int SizePopulation, int SizeGen)
        {            
            while (SizePopulation-- != 0)
            {
                // Cria a lista de genótipos
                Genotype g = new Genotype(SizeGen);
                Population.Add(g);
            }
        }

        // Dispara o processamento do algoritmo genético por um número determinado de gerações ou até atingir um alvo de fitness
        // Recebe o ponteiro para a chamada da função do usuário, para o cálculo do fitness
        public void ProcessAlg1(int NumGenerations, float FitnessTarget, float RenovationRate, float MutationRate, GenFitnessCalculate GenFitnessCalculateFnc)
        {
            Random rand = new Random();

            // Processa o algoritmo pela quantidade de gerações solicitadas
            while (NumGenerations-- != 0)
            {
                // Calcula o fitness de todos os genótipos da população
                foreach (Genotype element in Population)
                {
                    // Dispara a função do usuário para o cálculo da aptidão dos genótipos
                    element.Fitness = GenFitnessCalculateFnc(element.Gen);

                    // Se a aptidão alvo foi atingida, encerra o processamento. Se o fitnesstarget=0 ignora
                    if ((element.Fitness >= FitnessTarget) && (FitnessTarget != 0))
                    {
                        return;
                    }
                }

                // Organiza a população em função do fitness
                List<Genotype> PopulationSorted = Population.OrderByDescending(e => e.Fitness).ToList();
                Population = PopulationSorted;

                // Calcula a quantidade de elementos que serão eliminados e subtituídos por outros
                // novos, produtos de cruzamentos e mutações
                int RenovationElements = (int)(Population.Count * RenovationRate);
                if (RenovationElements == 0)
                {
                    RenovationElements = 1;
                }

                // Mata os indivíduos menos aptos 
                int deleteelements = RenovationElements;
                while (deleteelements-- != 0)
                {
                    Population.RemoveAt(Population.Count - 1);
                }

                // Faz o cruzamento entre os mais aptos e faz a mutação dos filhos, incluindo-os na população
                int insertelements = RenovationElements;
                int gen1index = 0;
                int gen2index;
                int lastelementindex = Population.Count;

                while (insertelements-- != 0)
                {
                    // Escolhe aleatoriamente o segundo indivíduo para o cruzamento
                    gen2index = rand.Next(gen1index + 1, lastelementindex + 1);

                    // Cria um novo elemento filho para ser adicionado à população 
                    Genotype gchild = new Genotype(Population[0].Gen.Count());
                    Population.Add(gchild);

                    // Processa o cruzamento e mutação, adicionando o gen do elemento filho criado 
                    Population[Population.Count - 1].Gen = CrossAndMutationAlg1(Population[gen1index].Gen, Population[gen2index].Gen, MutationRate);

                    // Passa para o próximo indivíduo mais habilitado para o cruzamento
                    gen1index++;
                }
            }
        }


        // Faz o cruzamento entre dois indivíduos e efetua a mutação à partir da taxa 
        public byte[] CrossAndMutationAlg1(byte[] Gen1, byte[] Gen2, float MutationRate)
        {
            int i;
            byte[] CrossRand = new byte[Gen1.Count()];
            byte[] ret = new byte[Gen1.Count()];
            int mutationprob = (int)(1 / (MutationRate * 8));
            Random rand = new Random();

            // Atualiza o gen com valores aleatórios
            Random randNum = new Random();
            randNum.NextBytes(CrossRand);

            // Faz o cruzamento dos pares indicados
            for (i = 0; i < Gen1.Count(); i++)
            {
                ret[i] = 0;

                if ((byte)(CrossRand[i] & 0x01) != 0)
                {
                    if ((byte)(Gen1[i] & 0x01) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x01);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x01) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x01);
                    }
                }

                if ((byte)(CrossRand[i] & 0x02) != 0)
                {
                    if ((byte)(Gen1[i] & 0x02) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x02);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x02) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x02);
                    }
                }

                if ((byte)(CrossRand[i] & 0x04) != 0)
                {
                    if ((byte)(Gen1[i] & 0x04) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x04);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x04) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x04);
                    }
                }

                if ((byte)(CrossRand[i] & 0x08) != 0)
                {
                    if ((byte)(Gen1[i] & 0x08) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x08);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x08) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x08);
                    }
                }

                if ((byte)(CrossRand[i] & 0x10) != 0)
                {
                    if ((byte)(Gen1[i] & 0x10) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x10);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x10) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x10);
                    }
                }

                if ((byte)(CrossRand[i] & 0x20) != 0)
                {
                    if ((byte)(Gen1[i] & 0x20) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x20);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x20) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x20);
                    }
                }

                if ((byte)(CrossRand[i] & 0x40) != 0)
                {
                    if ((byte)(Gen1[i] & 0x40) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x40);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x40) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x40);
                    }
                }

                if ((byte)(CrossRand[i] & 0x80) != 0)
                {
                    if ((byte)(Gen1[i] & 0x80) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x80);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x80) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x80);
                    }
                }
            }


            // Faz a mutação do filho
            for (i = 0; i < Gen1.Count(); i++)
            {
                // Verifica se vai ocorrer uma mutação no byte
                if (rand.Next(0, mutationprob) == rand.Next(0, mutationprob))
                {
                    int bitchange = rand.Next(0, 8);

                    switch (bitchange)
                    {
                        case 0:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x01) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xFE); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x01); // set
                                }

                                break;
                            }

                        case 1:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x02) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xFD); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x02); // set
                                }

                                break;
                            }
                        case 2:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x04) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xFB); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x04); // set
                                }

                                break;
                            }
                        case 3:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x08) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xF7); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x08); // set
                                }

                                break;
                            }
                        case 4:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x10) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xEF); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x10); // set
                                }

                                break;
                            }
                        case 5:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x20) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xDF); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x20); // set
                                }

                                break;
                            }
                        case 6:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x40) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0xBF); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x40); // set
                                }

                                break;
                            }

                        case 7:
                            {
                                // Se o bit é 1
                                if ((byte)(ret[i] & 0x80) != 0)
                                {
                                    ret[i] = (byte)(ret[i] & 0x7F); // clear
                                }
                                else
                                {
                                    ret[i] = (byte)(ret[i] | 0x80); // set
                                }

                                break;
                            }
                    }
                }
            }

            return ret;
        }

        // Dispara o processamento do algoritmo genético por um número determinado de gerações ou até atingir um alvo de fitness
        // Recebe o ponteiro para a chamada da função do usuário, para o cálculo do fitness
        public void Process(int NumGenerations, float FitnessTarget,float RenovationRate,float MutationRate,GenFitnessCalculate GenFitnessCalculateFnc)
        {
            Random rand = new Random();

            // Processa o algoritmo pela quantidade de gerações solicitadas
            while (NumGenerations-- != 0)
            {
                // Calcula o fitness de todos os genótipos da população
                foreach (Genotype element in Population)
                {
                    // Dispara a função do usuário para o cálculo da aptidão dos genótipos
                    element.Fitness = GenFitnessCalculateFnc(element.Gen);

                    // Se a aptidão alvo foi atingida, encerra o processamento. Se o fitnesstarget=0 ignora
                    if ((element.Fitness >= FitnessTarget) && (FitnessTarget!=0))
                    {
                        return;
                    }
                }
                
                // Calcula a quantidade de elementos que serão eliminados e subtituídos por outros
                // novos, produtos de cruzamentos e mutações
                int RenovationElements = (int)(Population.Count * RenovationRate);
                if (RenovationElements == 0)
                {
                    RenovationElements = 1;
                }
                
                // Faz o cruzamento entre os mais aptos e faz a mutação dos filhos, incluindo-os na população
                int insertelements = RenovationElements;
                int gen1index=0;
                int gen2index=0;
                int populationinitsize = Population.Count;

                while (insertelements-- != 0)
                {
                    while (gen1index == gen2index)
                    {
                        gen1index = rand.Next(0, populationinitsize);
                        gen2index = rand.Next(0, populationinitsize);
                    }
                    
                    // Cria um novo elemento filho para ser adicionado à população 
                    Genotype gchild = new Genotype(Population[0].Gen.Count());
                    Population.Add(gchild);

                    // Processa o cruzamento e mutação, adicionando o gen do elemento filho criado 
                    Population[Population.Count - 1].Gen = CrossAndMutation(Population[gen1index].Gen, Population[gen2index].Gen, MutationRate);

                    gen1index = 0;
                    gen2index = 0;
                }

                // Organiza a população em função do fitness
                List<Genotype> PopulationSorted = Population.OrderByDescending(e => e.Fitness).ToList();
                Population = PopulationSorted;

                // Mata os indivíduos menos aptos 
                int deleteelements = RenovationElements;
                while (deleteelements-- != 0)
                {
                    Population.RemoveAt(populationinitsize - 1);
                }
            }            
        }



        // Faz o cruzamento entre dois indivíduos e efetua a mutação à partir da taxa 
        public byte[] CrossAndMutation(byte[] Gen1,byte[] Gen2,float MutationRate)
        {
            int i;
            byte[] CrossRand = new byte[Gen1.Count()];
            byte[] ret = new byte[Gen1.Count()];
            int mutationprob = (int)(1/(MutationRate*8));
            Random rand = new Random();
           
            // Atualiza o gen com valores aleatórios
            Random randNum = new Random();
            randNum.NextBytes(CrossRand);

            // Define o ponto de cruzamento
            int crosspoint = rand.Next(0, Gen1.Count());

            Array.Copy(Gen2, ret, Gen1.Count());
            Array.Copy(Gen1, ret, crosspoint);


            // Faz o cruzamento dos pares indicados
            for (i = 0; i < Gen1.Count(); i++)
            {
                ret[i] = 0;
               
                if ((byte)(CrossRand[i] & 0x01) != 0)
                {
                    if ((byte)(Gen1[i] & 0x01) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x01);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x01) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x01);
                    }
                }

                if ((byte)(CrossRand[i] & 0x02) != 0)
                {
                    if ((byte)(Gen1[i] & 0x02) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x02);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x02) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x02);
                    }
                }

                if ((byte)(CrossRand[i] & 0x04) != 0)
                {
                    if ((byte)(Gen1[i] & 0x04) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x04);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x04) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x04);
                    }
                }

                if ((byte)(CrossRand[i] & 0x08) != 0)
                {
                    if ((byte)(Gen1[i] & 0x08) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x08);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x08) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x08);
                    }
                }

                if ((byte)(CrossRand[i] & 0x10) != 0)
                {
                    if ((byte)(Gen1[i] & 0x10) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x10);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x10) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x10);
                    }
                }

                if ((byte)(CrossRand[i] & 0x20) != 0)
                {
                    if ((byte)(Gen1[i] & 0x20) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x20);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x20) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x20);
                    }
                }

                if ((byte)(CrossRand[i] & 0x40) != 0)
                {
                    if ((byte)(Gen1[i] & 0x40) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x40);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x40) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x40);
                    }
                }

                if ((byte)(CrossRand[i] & 0x80) != 0)
                {
                    if ((byte)(Gen1[i] & 0x80) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x80);
                    }
                }
                else
                {
                    if ((byte)(Gen2[i] & 0x80) != 0)
                    {
                        ret[i] = (byte)(ret[i] | 0x80);
                    }
                }
            }


            // Faz a mutação do filho
            for (i = 0; i < Gen1.Count(); i++)
            {                
                    // Verifica se vai ocorrer uma mutação no byte
                    if (rand.Next(0, mutationprob) == rand.Next(0, mutationprob))
                    {
                        int bitchange = rand.Next(0, 8);

                        switch (bitchange)
                        {
                            case 0:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x01) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xFE); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x01); // set
                                    }
                                       
                                    break;
                                }
                           
                            case 1:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x02) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xFD); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x02); // set
                                    }

                                    break;
                                }
                            case 2:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x04) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xFB); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x04); // set
                                    }

                                    break;
                                }
                            case 3:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x08) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xF7); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x08); // set
                                    }

                                    break;
                                }
                            case 4:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x10) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xEF); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x10); // set
                                    }

                                    break;
                                }
                            case 5:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x20) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xDF); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x20); // set
                                    }

                                    break;
                                }
                            case 6:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x40) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0xBF); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x40); // set
                                    }

                                    break;
                                }

                            case 7:
                                {
                                    // Se o bit é 1
                                    if ((byte)(ret[i] & 0x80) != 0)
                                    {
                                        ret[i] = (byte)(ret[i] & 0x7F); // clear
                                    }
                                    else
                                    {
                                        ret[i] = (byte)(ret[i] | 0x80); // set
                                    }

                                    break;
                                }   
                        }
                    }                
            }

            return ret;
        }


        // Recebe o valor do máximo fitness da população
        public float GetMaxFitnessValue()
        {
            // Organiza a população em função do fitness
            List<Genotype> PopulationSorted = Population.OrderByDescending(e => e.Fitness).ToList();
            
            return PopulationSorted[0].Fitness;
        }

        // Recebe o genótipo com o maior valor de fitness
        public byte[] GetGenotypeMaxFitnessValue()
        {
            // Organiza a população em função do fitness
            List<Genotype> PopulationSorted = Population.OrderByDescending(e => e.Fitness).ToList();

            return PopulationSorted[0].Gen;
        }

        // Pega o tamanho da população
        public int GetPopulationSize()
        {
            return Population.Count();
        }

        // Retorna o gen em uma certa posicao
        public byte[] GetGenAtpos(int position)
        {
            return (Population[position].Gen);
        }

    }
    
}
